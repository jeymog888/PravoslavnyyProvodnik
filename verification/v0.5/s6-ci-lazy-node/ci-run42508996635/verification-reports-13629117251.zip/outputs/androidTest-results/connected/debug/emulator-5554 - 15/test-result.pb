
x�
�
ArrivalFlowTestru.liturgyguide.uiBforeignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-foreignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiDanInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark2�����ۍ�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiFexplicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-explicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
ArrivalFlowTestru.liturgyguide.ui8watchingRecalculatesTheStageAtTheClickAndOpensTextPaused2�����Ϡ�:�����ҏZ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-watchingRecalculatesTheStageAtTheClickAndOpensTextPaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
ArrivalFlowTestru.liturgyguide.ui8aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal2������ف:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHresumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase2�������1:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-resumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
ArrivalFlowTestru.liturgyguide.ui2anExpiredClickDoesNotReplaceOrClearTheSavedReading2�����ə�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anExpiredClickDoesNotReplaceOrClearTheSavedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiJaNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence2������Э:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHrestorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection2������A:�����ʺ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-restorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiBtomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration2������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-tomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui4timeoutEmptyResultsAndOldCachedResultsRemainDistinct2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-timeoutEmptyResultsAndOldCachedResultsRemainDistinct.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui9longMapNamesAndAddressesReachTheFormAndStorageUnshortened2������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-longMapNamesAndAddressesReachTheFormAndStorageUnshortened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiMsearchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-searchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui=leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHcancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable2��������:�����ܷ��
�java.lang.AssertionError: Action performScrollTo() failed.
Reason: Expected exactly '1' node but could not find any node that satisfies: (TestTag = 'discovery_city_osm:relation:1')

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:178)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.ActionsKt.performScrollTo(Actions.kt:76)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.scrollTo(ChurchDiscoveryScreenTest.kt:237)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable(ChurchDiscoveryScreenTest.kt:88)
java.lang.AssertionError�java.lang.AssertionError: Action performScrollTo() failed.
Reason: Expected exactly '1' node but could not find any node that satisfies: (TestTag = 'discovery_city_osm:relation:1')

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:178)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.ActionsKt.performScrollTo(Actions.kt:76)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.scrollTo(ChurchDiscoveryScreenTest.kt:237)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable(ChurchDiscoveryScreenTest.kt:88)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHfilteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch2������ά:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-filteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle2�������!:�������m"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiJacceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid2�������q:�����ǫK"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-acceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui>readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause2�������X:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui:staleDetailsActionCannotPauseOrDescribeAReplacementReading2������ĸ:�����߸�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-staleDetailsActionCannotPauseOrDescribeAReplacementReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement2��������:������
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiMallEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice2������:�����ɇ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiFlongTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiAallEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace2��������:�������y"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiBcompactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized2�������z:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-compactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DailyReadingSearchTestru.liturgyguide.ui7bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
x
DailyReadingSearchTestru.liturgyguide.ui.aReadingFromAnotherDayIsNotOfferedAsTodaysText2�����Ł�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aReadingFromAnotherDayIsNotOfferedAsTodaysText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DailyReadingSearchTestru.liturgyguide.ui8aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery2�����؃�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
DailyReadingSearchTestru.liturgyguide.ui3aMissingDailyReadingIsExplainedInBothTextAndMeaning2������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aMissingDailyReadingIsExplainedInBothTextAndMeaning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
j
DateRolloverTestru.liturgyguide.ui&mainDateUpdatesWhileTheScreenStaysOpen2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-mainDateUpdatesWhileTheScreenStaysOpen.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

DateRolloverTestru.liturgyguide.ui;scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DiscoveryNavigationTestru.liturgyguide.ui=aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates2�������:������
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DiscoveryNavigationTestru.liturgyguide.uiAdiscoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish2�������6:�����Ī""�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-discoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
v
FirstVisitFlowTestru.liturgyguide.ui1corruptModernMetadataNeverAssignsTheLegacyDefault2�����֞$:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-corruptModernMetadataNeverAssignsTheLegacyDefault.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiIfirstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore2������Ȕ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-firstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiFconfirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-confirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiAnewTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService2�����Ʀ�:�����Ư�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
t
FirstVisitFlowTestru.liturgyguide.ui.aFailedChoiceKeepsThePickerOpenAndCanBeRetried2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-aFailedChoiceKeepsThePickerOpenAndCanBeRetried.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.ui<retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord2��������:�����ɐ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

GuideNavigationTestru.liturgyguide.ui9churchHasTodayAndTomorrowAndChangingItStartsAFreshContext2������ǳ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-churchHasTodayAndTomorrowAndChangingItStartsAFreshContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui;unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt2������Ռ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui?startingANewServiceClearsPositionsButKeepsTheLanguagePreference2�����ے�:�������/"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-startingANewServiceClearsPositionsButKeepsTheLanguagePreference.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
GuideNavigationTestru.liturgyguide.ui7trackPhraseAndLanguageSurviveRecreationAndReturningHome2�����Ɣ0:�����ʺ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-trackPhraseAndLanguageSurviveRecreationAndReturningHome.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
l
GuideNavigationTestru.liturgyguide.ui'orderOpensAtDismissalWithLargestAppText2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtDismissalWithLargestAppText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
GuideNavigationTestru.liturgyguide.ui8choosingManualReadingFromTempoOptionsStopsAnActiveScroll2�������,:�������="�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingManualReadingFromTempoOptionsStopsAnActiveScroll.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.uiBsearchingAfterFinishingDoesNotReusePositionsFromThePreviousService2�������b:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingAfterFinishingDoesNotReusePositionsFromThePreviousService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
GuideNavigationTestru.liturgyguide.ui/readingCanAdvanceAndReturnWithoutLosingTheStage2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-readingCanAdvanceAndReturnWithoutLosingTheStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui=selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable2��������:�����Ʀ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
GuideNavigationTestru.liturgyguide.ui8onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer2��������:�������["�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
GuideNavigationTestru.liturgyguide.ui4serviceOrderIsSeparateFromSearchAndOptionalListening2�����ܠv:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-serviceOrderIsSeparateFromSearchAndOptionalListening.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
GuideNavigationTestru.liturgyguide.ui5largeTextAndDarkModePersistAndNavigationRemainsUsable2��������:�������-"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-largeTextAndDarkModePersistAndNavigationRemainsUsable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
k
GuideNavigationTestru.liturgyguide.ui%explanationChangesWithTheSelectedText2�������::��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-explanationChangesWithTheSelectedText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui?landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible2�����բ�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
GuideNavigationTestru.liturgyguide.ui7findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase2�������:�����"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
GuideNavigationTestru.liturgyguide.ui5backgroundingAndRecreationKeepTheAcceptedPhrasePaused2�����ꗢ:�����ߪ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-backgroundingAndRecreationKeepTheAcceptedPhrasePaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
GuideNavigationTestru.liturgyguide.ui5spellingVariantsOpenTheSamePairedPhraseFromMainSearch2�������:�����ٿ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-spellingVariantsOpenTheSamePairedPhraseFromMainSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
s
GuideNavigationTestru.liturgyguide.ui,anUnknownPhraseCanBeClearedToRestoreTheGuide2������Ȕ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-anUnknownPhraseCanBeClearedToRestoreTheGuide.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui=showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui>meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
s
GuideNavigationTestru.liturgyguide.ui,choosingAnotherPhraseStopsAutomaticScrolling2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingAnotherPhraseStopsAutomaticScrolling.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
y
GuideNavigationTestru.liturgyguide.ui2switchingToMeaningPausesScrollingAndKeepsThePhrase2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-switchingToMeaningPausesScrollingAndKeepsThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
l
GuideNavigationTestru.liturgyguide.ui%orderOpensAtTheBeginningFromThePlayer2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtTheBeginningFromThePlayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui;orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase2������ж:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui>searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional2��������:������ջ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

GuideNavigationTestru.liturgyguide.ui9searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard2��������:�������t"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
l
GuideNavigationTestru.liturgyguide.ui&heardWordsLeadToTheRelevantExplanation2�������v:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-heardWordsLeadToTheRelevantExplanation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
MainContextTestru.liturgyguide.ui<anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainContextTest-anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
MainScheduleOverviewTestru.liturgyguide.ui/publishedFractionalSecondsAreNotSilentlyRounded2�������:�����Ư�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-publishedFractionalSecondsAreNotSilentlyRounded.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui5evenARecentSavedReadingNeverMasksCurrentOrNextService2������ض:�������^"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-evenARecentSavedReadingNeverMasksCurrentOrNextService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
MainScheduleOverviewTestru.liturgyguide.ui*eachServiceButtonRetainsItsExactOccurrence2�������j:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-eachServiceButtonRetainsItsExactOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui<unknownScheduleKeepsManualReadingAndTempleSelectionAvailable2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-unknownScheduleKeepsManualReadingAndTempleSelectionAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui4aFuturePersonalStartShowsItsYearAndTheParishTimeZone2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-aFuturePersonalStartShowsItsYearAndTheParishTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui9informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiBcorrectionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks2������ɽ:������Ռ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiMallFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification2������ύ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-allFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiDacceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-acceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiQactivePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-activePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiHcorrectionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens2�������+:������ɤ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

ManualMomentFlowTestru.liturgyguide.ui7choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiAsavedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot2��������:�����ғ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-savedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiCaFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem2������Э:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-aFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.ui;correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
PersonalServiceTimeTestru.liturgyguide.ui2failedStorageKeepsTheDraftAndCancelDoesNotTryAgain2��������:������ޖ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-failedStorageKeepsTheDraftAndCancelDoesNotTryAgain.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.ui:impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
PersonalServiceTimeTestru.liturgyguide.ui2removalTargetsOnlyTheSelectedDateAndReportsFailure2��������:�������Q"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-removalTargetsOnlyTheSelectedDateAndReportsFailure.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.uiCanAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext2�������R:�����־�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-anAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
t
PersonalServiceTimeTestru.liturgyguide.ui*changingTheDateLoadsOnlyThatDatesSavedTime2�����Ю�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-changingTheDateLoadsOnlyThatDatesSavedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.ui7daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.uiNpublishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState2��������:�������R"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-publishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui7aSingleTextRetainsItsFullTitleAndTheClarificationAction2�������S:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aSingleTextRetainsItsFullTitleAndTheClarificationAction.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAscriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable2��������:�����ֵ?"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAaTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize2������N:������B"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBlandscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize2�������O:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-landscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiLlargeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent2������ܴ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-largeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBnarrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

SavedChurchFlowTestru.liturgyguide.ui8cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
SavedChurchFlowTestru.liturgyguide.ui3aTempleInAnotherCityAndItsTimeZoneSurviveRecreation2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-aTempleInAnotherCityAndItsTimeZoneSurviveRecreation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
SavedChurchFlowTestru.liturgyguide.ui6favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.ui?legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.uiAanOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-anOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.ui<aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.uiLaLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime2��������:�����蛠"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
StageSelectorTestru.liturgyguide.ui5updatingTheCurrentStageDoesNotInterruptManualBrowsing2������ؠ:������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-updatingTheCurrentStageDoesNotInterruptManualBrowsing.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
v
StageSelectorTestru.liturgyguide.ui1searchStartsAtTheTopEvenWhenTheCurrentStageIsLate2������Σ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-searchStartsAtTheTopEvenWhenTheCurrentStageIsLate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
StageSelectorTestru.liturgyguide.ui9restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
StageSelectorTestru.liturgyguide.ui7editingAndClearingAQueryShowTheBeginningOfTheNewResults2�������F:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-editingAndClearingAQueryShowTheBeginningOfTheNewResults.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiBlanguageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-languageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
UnifiedPlayerFlowTestru.liturgyguide.ui5endStopsThePlayerAndFinishingClearsTheAcceptedReading2��������:�����أ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-endStopsThePlayerAndFinishingClearsTheAcceptedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui>oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiMshortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase2��������:�������n"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-shortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiEmissingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation2�������|:�����"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-missingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
UnifiedPlayerFlowTestru.liturgyguide.ui2onePlayMovesThroughTextsAUsefulWaitAndTheNextStage2��������:������N"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-onePlayMovesThroughTextsAUsefulWaitAndTheNextStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiAchangingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase2������P:�������G"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-changingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiQexplicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical2�������T:�����ٟM"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-explicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui<losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning2�������q:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui@losingTopResumedPausesSynchronouslyEvenWhenLifecycleStaysResumed2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-losingTopResumedPausesSynchronouslyEvenWhenLifecycleStaysResumed.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiJscriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer2��������:�������Q"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-scriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/testlog/test-results.log 2
text/plain