
x�
�
ArrivalFlowTestru.liturgyguide.uiBforeignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice2����ӽ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-foreignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiDanInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiFexplicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate2����ޅ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-explicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
ArrivalFlowTestru.liturgyguide.ui8watchingRecalculatesTheStageAtTheClickAndOpensTextPaused2�����߯:�����Ӧu"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-watchingRecalculatesTheStageAtTheClickAndOpensTextPaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
ArrivalFlowTestru.liturgyguide.ui8aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHresumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase2������&:�������n"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-resumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
t
ArrivalFlowTestru.liturgyguide.ui2anExpiredClickDoesNotReplaceOrClearTheSavedReading2�������{:������ݥ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anExpiredClickDoesNotReplaceOrClearTheSavedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiJaNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence2�����Ҋ�:������Ռ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHrestorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-restorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiBtomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration2�����ꗢ:�������w"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-tomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui4timeoutEmptyResultsAndOldCachedResultsRemainDistinct2�����蛠:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-timeoutEmptyResultsAndOldCachedResultsRemainDistinct.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui9longMapNamesAndAddressesReachTheFormAndStorageUnshortened2��������:�����Ɔ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-longMapNamesAndAddressesReachTheFormAndStorageUnshortened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiMsearchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-searchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui=leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt2�����ϩ�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHcancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHfilteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch2��������:�������_"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-filteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle2�������c:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiJacceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-acceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui>readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui:staleDetailsActionCannotPauseOrDescribeAReplacementReading2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-staleDetailsActionCannotPauseOrDescribeAReplacementReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement2��������:�����ҁ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiMallEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice2��������:�������]"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiFlongTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale2�������^:�������V"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiAallEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace2�������V:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiBcompactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-compactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

DailyReadingSearchTestru.liturgyguide.ui7bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery2�����ʺ:�������b"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
w
DailyReadingSearchTestru.liturgyguide.ui.aReadingFromAnotherDayIsNotOfferedAsTodaysText2�������c:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aReadingFromAnotherDayIsNotOfferedAsTodaysText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DailyReadingSearchTestru.liturgyguide.ui8aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery2��������:è������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
DailyReadingSearchTestru.liturgyguide.ui3aMissingDailyReadingIsExplainedInBothTextAndMeaning2è������:Ũ���ይ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aMissingDailyReadingIsExplainedInBothTextAndMeaning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
j
DateRolloverTestru.liturgyguide.ui&mainDateUpdatesWhileTheScreenStaysOpen2Ũ���ꅮ:ƨ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-mainDateUpdatesWhileTheScreenStaysOpen.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

DateRolloverTestru.liturgyguide.ui;scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary2ƨ������:Ȩ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DiscoveryNavigationTestru.liturgyguide.ui=aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates2Ȩ������:ɨ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DiscoveryNavigationTestru.liturgyguide.uiAdiscoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish2ɨ���×�:ͨ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-discoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
w
FirstVisitFlowTestru.liturgyguide.ui1corruptModernMetadataNeverAssignsTheLegacyDefault2ͨ�����:Ψ���Ϳ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-corruptModernMetadataNeverAssignsTheLegacyDefault.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiIfirstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore2Ψ���߳�:Ѩ�����>"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-firstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiFconfirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice2Ѩ�����?:Ө����A"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-confirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiAnewTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService2Ө�����D:٨�����"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
s
FirstVisitFlowTestru.liturgyguide.ui.aFailedChoiceKeepsThePickerOpenAndCanBeRetried2٨�����:ڨ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-aFailedChoiceKeepsThePickerOpenAndCanBeRetried.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.ui<retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord2ڨ����҈:������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
GuideNavigationTestru.liturgyguide.ui9churchHasTodayAndTomorrowAndChangingItStartsAFreshContext2������:�����'"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-churchHasTodayAndTomorrowAndChangingItStartsAFreshContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui;unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt2������5:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui?startingANewServiceClearsPositionsButKeepsTheLanguagePreference2�������:����ꅮ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-startingANewServiceClearsPositionsButKeepsTheLanguagePreference.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
GuideNavigationTestru.liturgyguide.ui7trackPhraseAndLanguageSurviveRecreationAndReturningHome2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-trackPhraseAndLanguageSurviveRecreationAndReturningHome.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
n
GuideNavigationTestru.liturgyguide.ui'orderOpensAtDismissalWithLargestAppText2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtDismissalWithLargestAppText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

GuideNavigationTestru.liturgyguide.ui8choosingManualReadingFromTempoOptionsStopsAnActiveScroll2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingManualReadingFromTempoOptionsStopsAnActiveScroll.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.uiBsearchingAfterFinishingDoesNotReusePositionsFromThePreviousService2�������:�������0"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingAfterFinishingDoesNotReusePositionsFromThePreviousService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
GuideNavigationTestru.liturgyguide.ui/readingCanAdvanceAndReturnWithoutLosingTheStage2�������2:�����Ϳ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-readingCanAdvanceAndReturnWithoutLosingTheStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui=selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
GuideNavigationTestru.liturgyguide.ui8onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer2�������:�������A"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
y
GuideNavigationTestru.liturgyguide.ui4serviceOrderIsSeparateFromSearchAndOptionalListening2�������B:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-serviceOrderIsSeparateFromSearchAndOptionalListening.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
GuideNavigationTestru.liturgyguide.ui5largeTextAndDarkModePersistAndNavigationRemainsUsable2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-largeTextAndDarkModePersistAndNavigationRemainsUsable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
l
GuideNavigationTestru.liturgyguide.ui%explanationChangesWithTheSelectedText2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-explanationChangesWithTheSelectedText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui?landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible2��������:������ʷ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
GuideNavigationTestru.liturgyguide.ui7findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase2�����ɇ�:�������p"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
GuideNavigationTestru.liturgyguide.ui5backgroundingAndRecreationKeepTheAcceptedPhrasePaused2�������p:������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-backgroundingAndRecreationKeepTheAcceptedPhrasePaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
GuideNavigationTestru.liturgyguide.ui5spellingVariantsOpenTheSamePairedPhraseFromMainSearch2�������:�������&"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-spellingVariantsOpenTheSamePairedPhraseFromMainSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
r
GuideNavigationTestru.liturgyguide.ui,anUnknownPhraseCanBeClearedToRestoreTheGuide2�������(:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-anUnknownPhraseCanBeClearedToRestoreTheGuide.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui=showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus2�����ይ:������ݕ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui>meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
r
GuideNavigationTestru.liturgyguide.ui,choosingAnotherPhraseStopsAutomaticScrolling2�������:�������S"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingAnotherPhraseStopsAutomaticScrolling.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
x
GuideNavigationTestru.liturgyguide.ui2switchingToMeaningPausesScrollingAndKeepsThePhrase2�������T:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-switchingToMeaningPausesScrollingAndKeepsThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
k
GuideNavigationTestru.liturgyguide.ui%orderOpensAtTheBeginningFromThePlayer2�����ļ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtTheBeginningFromThePlayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui;orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui>searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional2�����ܮ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

GuideNavigationTestru.liturgyguide.ui9searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard2��������:�������4"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
l
GuideNavigationTestru.liturgyguide.ui&heardWordsLeadToTheRelevantExplanation2�������5:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-heardWordsLeadToTheRelevantExplanation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

MainContextTestru.liturgyguide.ui<anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainContextTest-anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
MainScheduleOverviewTestru.liturgyguide.ui/publishedFractionalSecondsAreNotSilentlyRounded2��������:�������`"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-publishedFractionalSecondsAreNotSilentlyRounded.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui5evenARecentSavedReadingNeverMasksCurrentOrNextService2�������n:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-evenARecentSavedReadingNeverMasksCurrentOrNextService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
v
MainScheduleOverviewTestru.liturgyguide.ui*eachServiceButtonRetainsItsExactOccurrence2������׍:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-eachServiceButtonRetainsItsExactOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui<unknownScheduleKeepsManualReadingAndTempleSelectionAvailable2�����Ք�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-unknownScheduleKeepsManualReadingAndTempleSelectionAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui4aFuturePersonalStartShowsItsYearAndTheParishTimeZone2�����Ҋ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-aFuturePersonalStartShowsItsYearAndTheParishTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui9informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiBcorrectionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks2��������:�����Ư�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiMallFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification2�����ϩ�:é����� "�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-allFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiDacceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks2é�����,:ĩ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-acceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiQactivePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime2ĩ������:Ʃ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-activePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiHcorrectionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens2Ʃ�����:ɩ���ܩ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

ManualMomentFlowTestru.liturgyguide.ui7choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation2ɩ������:ʩ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiAsavedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot2ʩ������:̩������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-savedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiCaFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem2̩�����:ϩ���ᝡ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-aFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.ui;correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase2ϩ����Э:ҩ�����S"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
PersonalServiceTimeTestru.liturgyguide.ui2failedStorageKeepsTheDraftAndCancelDoesNotTryAgain2ҩ�����T:ԩ������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-failedStorageKeepsTheDraftAndCancelDoesNotTryAgain.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.ui:impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving2ԩ�����:ک�����@"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
PersonalServiceTimeTestru.liturgyguide.ui2removalTargetsOnlyTheSelectedDateAndReportsFailure2ک����A:ݩ����ά"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-removalTargetsOnlyTheSelectedDateAndReportsFailure.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.uiCanAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext2ݩ����ȭ:������?"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-anAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
s
PersonalServiceTimeTestru.liturgyguide.ui*changingTheDateLoadsOnlyThatDatesSavedTime2�����A:������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-changingTheDateLoadsOnlyThatDatesSavedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.ui7daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected2����̍:����̈�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
PersonalServiceTimeTestru.liturgyguide.uiNpublishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-publishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui7aSingleTextRetainsItsFullTitleAndTheClarificationAction2�������:�����Ï"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aSingleTextRetainsItsFullTitleAndTheClarificationAction.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAscriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu2����ӽ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable2�������:����ļ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAaTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize2����ְ�:����큰"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBlandscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize2����ⴼ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-landscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiLlargeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent2�������:�����ҏZ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-largeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea2�������~:������ю"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBnarrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed2�������:�����Ɣ0"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
SavedChurchFlowTestru.liturgyguide.ui8cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish2�������0:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
SavedChurchFlowTestru.liturgyguide.ui3aTempleInAnotherCityAndItsTimeZoneSurviveRecreation2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-aTempleInAnotherCityAndItsTimeZoneSurviveRecreation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
}
SavedChurchFlowTestru.liturgyguide.ui6favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage2��������:�����ְ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.ui?legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.uiAanOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-anOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.ui<aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.uiLaLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
StageSelectorTestru.liturgyguide.ui5updatingTheCurrentStageDoesNotInterruptManualBrowsing2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-updatingTheCurrentStageDoesNotInterruptManualBrowsing.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
v
StageSelectorTestru.liturgyguide.ui1searchStartsAtTheTopEvenWhenTheCurrentStageIsLate2��������:�����ϒ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-searchStartsAtTheTopEvenWhenTheCurrentStageIsLate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
StageSelectorTestru.liturgyguide.ui9restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition2�������:�����ߪ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
StageSelectorTestru.liturgyguide.ui7editingAndClearingAQueryShowTheBeginningOfTheNewResults2������ѧ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-editingAndClearingAQueryShowTheBeginningOfTheNewResults.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiBlanguageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-languageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
UnifiedPlayerFlowTestru.liturgyguide.ui5endStopsThePlayerAndFinishingClearsTheAcceptedReading2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-endStopsThePlayerAndFinishingClearsTheAcceptedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui>oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader2�����ϒ�:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiMshortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase2�����ށ
:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-shortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiEmissingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation2�����Ӵ:�����ܠv"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-missingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
UnifiedPlayerFlowTestru.liturgyguide.ui2onePlayMovesThroughTextsAUsefulWaitAndTheNextStage2�������v:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-onePlayMovesThroughTextsAUsefulWaitAndTheNextStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiAchangingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-changingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiQexplicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-explicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui<losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning2��������:�����ՙ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui@losingTopResumedPausesSynchronouslyEvenWhenLifecycleStaysResumed2��������:������׍"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-losingTopResumedPausesSynchronouslyEvenWhenLifecycleStaysResumed.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiJscriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer2��������:�������K"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-scriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/testlog/test-results.log 2
text/plain