
w�
�
ArrivalFlowTestru.liturgyguide.uiBforeignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-foreignOrCorruptContextRestoredInServiceRequiresANewExplicitChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiDanInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark2�������:�������{"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anInvalidLegacySessionCannotSupplyTheDateForAnOtherwiseValidBookmark.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiFexplicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate2������ї:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-explicitlyStartingAgainUsesTodayInsteadOfThePreviouslyOpenedFutureDate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
ArrivalFlowTestru.liturgyguide.ui8watchingRecalculatesTheStageAtTheClickAndOpensTextPaused2��������:�������R"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-watchingRecalculatesTheStageAtTheClickAndOpensTextPaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
y
ArrivalFlowTestru.liturgyguide.ui8aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal2�������T:�������K"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aPersonalStartOpensItsOwnEstimateAndIsRecordedAsPersonal.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHresumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase2�������L:�����֞$"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-resumingALegacyBookmarkPinsItsOriginalAnchorDateWithoutClearingThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
t
ArrivalFlowTestru.liturgyguide.ui2anExpiredClickDoesNotReplaceOrClearTheSavedReading2������&:������Ʌ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-anExpiredClickDoesNotReplaceOrClearTheSavedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiJaNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-aNextServiceBecomesCurrentBetweenDisplayAndClickWithoutSwitchingOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiHrestorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection2��������:�������7"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-restorationStraightIntoLegacyServicePinsTheAnchorDateBeforeAnyCorrection.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ArrivalFlowTestru.liturgyguide.uiBtomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration2�������P:�����Ó"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ArrivalFlowTest-tomorrowsReadingKeepsItsDateAcrossCorrectionMidnightAndRestoration.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

ChurchDiscoveryScreenTestru.liturgyguide.ui4timeoutEmptyResultsAndOldCachedResultsRemainDistinct2�����̍:�������V�
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.timeoutEmptyResultsAndOldCachedResultsRemainDistinct(ChurchDiscoveryScreenTest.kt:131)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.timeoutEmptyResultsAndOldCachedResultsRemainDistinct(ChurchDiscoveryScreenTest.kt:131)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-timeoutEmptyResultsAndOldCachedResultsRemainDistinct.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui9longMapNamesAndAddressesReachTheFormAndStorageUnshortened2�������q:�����焅�
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.longMapNamesAndAddressesReachTheFormAndStorageUnshortened(ChurchDiscoveryScreenTest.kt:106)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.longMapNamesAndAddressesReachTheFormAndStorageUnshortened(ChurchDiscoveryScreenTest.kt:106)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-longMapNamesAndAddressesReachTheFormAndStorageUnshortened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiMsearchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone2��������:�����ҏZ�	
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone(ChurchDiscoveryScreenTest.kt:43)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone(ChurchDiscoveryScreenTest.kt:43)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-searchesOnlyAfterAnActionAndSavesOnlyAfterReviewingTheSelectedCityAndTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.ui=leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt2�����ۉ[:���������

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt(ChurchDiscoveryScreenTest.kt:154)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt(ChurchDiscoveryScreenTest.kt:154)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-leavingTheForegroundCancelsSearchAndReturningDoesNotRestartIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHcancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable2�����ꎨ:�������p�

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable(ChurchDiscoveryScreenTest.kt:83)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable(ChurchDiscoveryScreenTest.kt:83)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-cancellingARequestIgnoresItsLateResultAndLeavesManualNavigationAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ChurchDiscoveryScreenTestru.liturgyguide.uiHfilteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch2�������t:���������
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.filteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch(ChurchDiscoveryScreenTest.kt:170)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.waitForVisibleKeyboard(ChurchDiscoveryScreenTest.kt:210)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.search(ChurchDiscoveryScreenTest.kt:189)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.searchAndChooseKazan(ChurchDiscoveryScreenTest.kt:194)
at ru.liturgyguide.ui.ChurchDiscoveryScreenTest.filteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch(ChurchDiscoveryScreenTest.kt:170)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-filteringAndCancellingImportDoNotSaveAnythingOrStartAnotherNetworkSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle2�����ՙ�:�������J"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiJacceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid2�������d:������ҡ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-acceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui>readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui:staleDetailsActionCannotPauseOrDescribeAReplacementReading2�������C:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-staleDetailsActionCannotPauseOrDescribeAReplacementReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement2������� :�������?"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiMallEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice2�������X:�������z"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiFlongTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale2�������:�������<"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiAallEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace2�������=:��������	
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.CompactReaderMatrixTest.orient(CompactReaderMatrixTest.kt:293)
at ru.liturgyguide.ui.CompactReaderMatrixTest.allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace(CompactReaderMatrixTest.kt:83)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.CompactReaderMatrixTest.orient(CompactReaderMatrixTest.kt:293)
at ru.liturgyguide.ui.CompactReaderMatrixTest.allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace(CompactReaderMatrixTest.kt:83)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiBcompactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized2������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-compactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
DailyReadingSearchTestru.liturgyguide.ui7bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery2��������:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@9123efe, window-token=android.view.ViewRootImpl$W@9123efe, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery(DailyReadingSearchTest.kt:37)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@9123efe, window-token=android.view.ViewRootImpl$W@9123efe, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery(DailyReadingSearchTest.kt:37)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-bothSpellingsFindTheSameStageAndPreserveTheEnteredQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
x
DailyReadingSearchTestru.liturgyguide.ui.aReadingFromAnotherDayIsNotOfferedAsTodaysText2������ݥ:���������'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@fe86462, window-token=android.view.ViewRootImpl$W@fe86462, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.aReadingFromAnotherDayIsNotOfferedAsTodaysText(DailyReadingSearchTest.kt:75)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@fe86462, window-token=android.view.ViewRootImpl$W@fe86462, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.aReadingFromAnotherDayIsNotOfferedAsTodaysText(DailyReadingSearchTest.kt:75)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aReadingFromAnotherDayIsNotOfferedAsTodaysText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
DailyReadingSearchTestru.liturgyguide.ui8aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery2�������:������ҡ�(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3aad237, window-token=android.view.ViewRootImpl$W@3aad237, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery(DailyReadingSearchTest.kt:59)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3aad237, window-token=android.view.ViewRootImpl$W@3aad237, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.DailyReadingSearchTest.aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery(DailyReadingSearchTest.kt:59)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aWordFromTheDailyGospelFindsItsStageAndPreservesTheQuery.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
|
DailyReadingSearchTestru.liturgyguide.ui3aMissingDailyReadingIsExplainedInBothTextAndMeaning2������®:�����Åf"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DailyReadingSearchTest-aMissingDailyReadingIsExplainedInBothTextAndMeaning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
i
DateRolloverTestru.liturgyguide.ui&mainDateUpdatesWhileTheScreenStaysOpen2�������f:�����Ͷ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-mainDateUpdatesWhileTheScreenStaysOpen.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

DateRolloverTestru.liturgyguide.ui;scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary2������ݥ:������ջ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DateRolloverTest-scheduleKeepsTodayAndTomorrowRelativeAcrossTheMonthBoundary.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
DiscoveryNavigationTestru.liturgyguide.ui=aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates2������þ:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-aMappedTempleWithoutACityTagCanBeSavedWithItsKnownCoordinates.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
DiscoveryNavigationTestru.liturgyguide.uiAdiscoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish2������ϼ:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7314337, window-token=android.view.ViewRootImpl$W@7314337, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.DiscoveryNavigationTest.discoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish(DiscoveryNavigationTest.kt:80)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7314337, window-token=android.view.ViewRootImpl$W@7314337, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.DiscoveryNavigationTest.discoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish(DiscoveryNavigationTest.kt:80)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.DiscoveryNavigationTest-discoveryReturnsToSavedPickerAndOnlyConfirmationReplacesTheParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
w
FirstVisitFlowTestru.liturgyguide.ui1corruptModernMetadataNeverAssignsTheLegacyDefault2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-corruptModernMetadataNeverAssignsTheLegacyDefault.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
FirstVisitFlowTestru.liturgyguide.uiIfirstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore2������ؠ:�����Ɲ��(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@fe873a2, window-token=android.view.ViewRootImpl$W@fe873a2, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.firstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore(FirstVisitFlowTest.kt:44)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@fe873a2, window-token=android.view.ViewRootImpl$W@fe873a2, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.firstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore(FirstVisitFlowTest.kt:44)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-firstVisitOpensThePickerDirectlyAndManualReadingKeepsNoParishAfterRestore.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
FirstVisitFlowTestru.liturgyguide.uiFconfirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-confirmingRecoveredLegacyParishPreservesTheReadingAndPersistsTheChoice.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
FirstVisitFlowTestru.liturgyguide.uiAnewTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService2��������:�������q�(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b482217, window-token=android.view.ViewRootImpl$W@b482217, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.replace(FirstVisitFlowTest.kt:186)
at ru.liturgyguide.ui.FirstVisitFlowTest.newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService(FirstVisitFlowTest.kt:64)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b482217, window-token=android.view.ViewRootImpl$W@b482217, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.replace(FirstVisitFlowTest.kt:186)
at ru.liturgyguide.ui.FirstVisitFlowTest.newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService(FirstVisitFlowTest.kt:64)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
s
FirstVisitFlowTestru.liturgyguide.ui.aFailedChoiceKeepsThePickerOpenAndCanBeRetried2�����Ӧu:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-aFailedChoiceKeepsThePickerOpenAndCanBeRetried.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
FirstVisitFlowTestru.liturgyguide.ui<retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7fc3d4e, window-token=android.view.ViewRootImpl$W@7fc3d4e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.replace(FirstVisitFlowTest.kt:186)
at ru.liturgyguide.ui.FirstVisitFlowTest.retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord(FirstVisitFlowTest.kt:151)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7fc3d4e, window-token=android.view.ViewRootImpl$W@7fc3d4e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.FirstVisitFlowTest.replace(FirstVisitFlowTest.kt:186)
at ru.liturgyguide.ui.FirstVisitFlowTest.retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord(FirstVisitFlowTest.kt:151)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.FirstVisitFlowTest-retryAfterDirectorySaveAndFailedSelectionReusesTheSameRecord.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
~
GuideNavigationTestru.liturgyguide.ui9churchHasTodayAndTomorrowAndChangingItStartsAFreshContext2�������$:�������8�*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a3c7cf5, window-token=android.view.ViewRootImpl$W@a3c7cf5, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.churchHasTodayAndTomorrowAndChangingItStartsAFreshContext(GuideNavigationTest.kt:482)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a3c7cf5, window-token=android.view.ViewRootImpl$W@a3c7cf5, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.churchHasTodayAndTomorrowAndChangingItStartsAFreshContext(GuideNavigationTest.kt:482)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-churchHasTodayAndTomorrowAndChangingItStartsAFreshContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
GuideNavigationTestru.liturgyguide.ui;unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt2�������;:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a336aa3, window-token=android.view.ViewRootImpl$W@a336aa3, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt(GuideNavigationTest.kt:320)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a336aa3, window-token=android.view.ViewRootImpl$W@a336aa3, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt(GuideNavigationTest.kt:320)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-unifiedPlaybackHasNoSeparateStageTimerAndManualSeekPausesIt.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
GuideNavigationTestru.liturgyguide.ui?startingANewServiceClearsPositionsButKeepsTheLanguagePreference2��������:�����ٺ��)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@e1867e6, window-token=android.view.ViewRootImpl$W@e1867e6, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.startingANewServiceClearsPositionsButKeepsTheLanguagePreference(GuideNavigationTest.kt:302)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@e1867e6, window-token=android.view.ViewRootImpl$W@e1867e6, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.startingANewServiceClearsPositionsButKeepsTheLanguagePreference(GuideNavigationTest.kt:302)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-startingANewServiceClearsPositionsButKeepsTheLanguagePreference.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
~
GuideNavigationTestru.liturgyguide.ui7trackPhraseAndLanguageSurviveRecreationAndReturningHome2�������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@9f3e2ba, window-token=android.view.ViewRootImpl$W@9f3e2ba, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.trackPhraseAndLanguageSurviveRecreationAndReturningHome(GuideNavigationTest.kt:185)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@9f3e2ba, window-token=android.view.ViewRootImpl$W@9f3e2ba, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.trackPhraseAndLanguageSurviveRecreationAndReturningHome(GuideNavigationTest.kt:185)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-trackPhraseAndLanguageSurviveRecreationAndReturningHome.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�.
n
GuideNavigationTestru.liturgyguide.ui'orderOpensAtDismissalWithLargestAppText2�����ʵ�:������ӱ�'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@843dbe8, window-token=android.view.ViewRootImpl$W@843dbe8, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.orderOpensAtDismissalWithLargestAppText(GuideNavigationTest.kt:143)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@843dbe8, window-token=android.view.ViewRootImpl$W@843dbe8, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.orderOpensAtDismissalWithLargestAppText(GuideNavigationTest.kt:143)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtDismissalWithLargestAppText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1

GuideNavigationTestru.liturgyguide.ui8choosingManualReadingFromTempoOptionsStopsAnActiveScroll2�����Ҋ�:���������*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b1e751b, window-token=android.view.ViewRootImpl$W@b1e751b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.choosingManualReadingFromTempoOptionsStopsAnActiveScroll(GuideNavigationTest.kt:239)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b1e751b, window-token=android.view.ViewRootImpl$W@b1e751b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.choosingManualReadingFromTempoOptionsStopsAnActiveScroll(GuideNavigationTest.kt:239)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingManualReadingFromTempoOptionsStopsAnActiveScroll.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
GuideNavigationTestru.liturgyguide.uiBsearchingAfterFinishingDoesNotReusePositionsFromThePreviousService2��������:��������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a5ebfbe, window-token=android.view.ViewRootImpl$W@a5ebfbe, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.searchingAfterFinishingDoesNotReusePositionsFromThePreviousService(GuideNavigationTest.kt:551)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a5ebfbe, window-token=android.view.ViewRootImpl$W@a5ebfbe, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.searchingAfterFinishingDoesNotReusePositionsFromThePreviousService(GuideNavigationTest.kt:551)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingAfterFinishingDoesNotReusePositionsFromThePreviousService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
GuideNavigationTestru.liturgyguide.ui/readingCanAdvanceAndReturnWithoutLosingTheStage2�������,:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-readingCanAdvanceAndReturnWithoutLosingTheStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
GuideNavigationTestru.liturgyguide.ui=selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable2�����Ջ�:������Σ�)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7f80a7e, window-token=android.view.ViewRootImpl$W@7f80a7e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable(GuideNavigationTest.kt:342)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@7f80a7e, window-token=android.view.ViewRootImpl$W@7f80a7e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable(GuideNavigationTest.kt:342)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-selectedParishUsesItsLocalDateAndManualChoiceRemainsAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

GuideNavigationTestru.liturgyguide.ui8onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�.
{
GuideNavigationTestru.liturgyguide.ui4serviceOrderIsSeparateFromSearchAndOptionalListening2��������:���������'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3a3667, window-token=android.view.ViewRootImpl$W@3a3667, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.serviceOrderIsSeparateFromSearchAndOptionalListening(GuideNavigationTest.kt:123)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3a3667, window-token=android.view.ViewRootImpl$W@3a3667, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.serviceOrderIsSeparateFromSearchAndOptionalListening(GuideNavigationTest.kt:123)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-serviceOrderIsSeparateFromSearchAndOptionalListening.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�-
|
GuideNavigationTestru.liturgyguide.ui5largeTextAndDarkModePersistAndNavigationRemainsUsable2��������:��������&
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@ab0b187, window-token=android.view.ViewRootImpl$W@ab0b187, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=3}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.largeTextAndDarkModePersistAndNavigationRemainsUsable(GuideNavigationTest.kt:215)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@ab0b187, window-token=android.view.ViewRootImpl$W@ab0b187, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=3}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.largeTextAndDarkModePersistAndNavigationRemainsUsable(GuideNavigationTest.kt:215)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-largeTextAndDarkModePersistAndNavigationRemainsUsable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
k
GuideNavigationTestru.liturgyguide.ui%explanationChangesWithTheSelectedText2������Н:�������O�*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@ec0da31, window-token=android.view.ViewRootImpl$W@ec0da31, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.explanationChangesWithTheSelectedText(GuideNavigationTest.kt:270)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@ec0da31, window-token=android.view.ViewRootImpl$W@ec0da31, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.explanationChangesWithTheSelectedText(GuideNavigationTest.kt:270)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-explanationChangesWithTheSelectedText.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
GuideNavigationTestru.liturgyguide.ui?landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible2�������^:��������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@2e771f8, window-token=android.view.ViewRootImpl$W@2e771f8, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible(GuideNavigationTest.kt:352)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@2e771f8, window-token=android.view.ViewRootImpl$W@2e771f8, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible(GuideNavigationTest.kt:352)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-landscapeWithLargestAppTextKeepsCurrentPhraseAndControlsVisible.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
~
GuideNavigationTestru.liturgyguide.ui7findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase2��������:���������*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@578256b, window-token=android.view.ViewRootImpl$W@578256b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase(GuideNavigationTest.kt:534)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@578256b, window-token=android.view.ViewRootImpl$W@578256b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase(GuideNavigationTest.kt:534)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-findingAPrayerFromMeaningOpensItsTextAtTheMatchedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
|
GuideNavigationTestru.liturgyguide.ui5backgroundingAndRecreationKeepTheAcceptedPhrasePaused2��������:���������*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a6dde4e, window-token=android.view.ViewRootImpl$W@a6dde4e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.backgroundingAndRecreationKeepTheAcceptedPhrasePaused(GuideNavigationTest.kt:286)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a6dde4e, window-token=android.view.ViewRootImpl$W@a6dde4e, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.backgroundingAndRecreationKeepTheAcceptedPhrasePaused(GuideNavigationTest.kt:286)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-backgroundingAndRecreationKeepTheAcceptedPhrasePaused.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
|
GuideNavigationTestru.liturgyguide.ui5spellingVariantsOpenTheSamePairedPhraseFromMainSearch2������ۺ:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@14c826d, window-token=android.view.ViewRootImpl$W@14c826d, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.spellingVariantsOpenTheSamePairedPhraseFromMainSearch(GuideNavigationTest.kt:401)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@14c826d, window-token=android.view.ViewRootImpl$W@14c826d, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.spellingVariantsOpenTheSamePairedPhraseFromMainSearch(GuideNavigationTest.kt:401)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-spellingVariantsOpenTheSamePairedPhraseFromMainSearch.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
s
GuideNavigationTestru.liturgyguide.ui,anUnknownPhraseCanBeClearedToRestoreTheGuide2��������:��������'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a3ee265, window-token=android.view.ViewRootImpl$W@a3ee265, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.anUnknownPhraseCanBeClearedToRestoreTheGuide(GuideNavigationTest.kt:79)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a3ee265, window-token=android.view.ViewRootImpl$W@a3ee265, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.anUnknownPhraseCanBeClearedToRestoreTheGuide(GuideNavigationTest.kt:79)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-anUnknownPhraseCanBeClearedToRestoreTheGuide.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui=showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus2������̢:�����뮽�	
�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.GuideNavigationTest.showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus$waitForKeyboard(GuideNavigationTest.kt:93)
at ru.liturgyguide.ui.GuideNavigationTest.showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus(GuideNavigationTest.kt:104)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.GuideNavigationTest.showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus$waitForKeyboard(GuideNavigationTest.kt:93)
at ru.liturgyguide.ui.GuideNavigationTest.showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus(GuideNavigationTest.kt:104)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-showingAllStagesAfterUnknownWordsDismissesTheKeyboardAndFocus.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
GuideNavigationTestru.liturgyguide.ui>meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@cd6e82f, window-token=android.view.ViewRootImpl$W@cd6e82f, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation(GuideNavigationTest.kt:512)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@cd6e82f, window-token=android.view.ViewRootImpl$W@cd6e82f, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation(GuideNavigationTest.kt:512)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-meaningAndReadingPositionSurviveOrderHomeAndSettingsNavigation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
r
GuideNavigationTestru.liturgyguide.ui,choosingAnotherPhraseStopsAutomaticScrolling2�����ۛ�:�������9�)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3989a62, window-token=android.view.ViewRootImpl$W@3989a62, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.choosingAnotherPhraseStopsAutomaticScrolling(GuideNavigationTest.kt:249)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3989a62, window-token=android.view.ViewRootImpl$W@3989a62, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.choosingAnotherPhraseStopsAutomaticScrolling(GuideNavigationTest.kt:249)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingAnotherPhraseStopsAutomaticScrolling.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
x
GuideNavigationTestru.liturgyguide.ui2switchingToMeaningPausesScrollingAndKeepsThePhrase2�������G:���������*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@d22da11, window-token=android.view.ViewRootImpl$W@d22da11, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.switchingToMeaningPausesScrollingAndKeepsThePhrase(GuideNavigationTest.kt:258)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@d22da11, window-token=android.view.ViewRootImpl$W@d22da11, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.switchingToMeaningPausesScrollingAndKeepsThePhrase(GuideNavigationTest.kt:258)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-switchingToMeaningPausesScrollingAndKeepsThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
k
GuideNavigationTestru.liturgyguide.ui%orderOpensAtTheBeginningFromThePlayer2������ڡ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtTheBeginningFromThePlayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�2
�
GuideNavigationTestru.liturgyguide.ui;orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase2�������:���������*
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@be7adce, window-token=android.view.ViewRootImpl$W@be7adce, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase(GuideNavigationTest.kt:152)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@be7adce, window-token=android.view.ViewRootImpl$W@be7adce, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.openCreed(GuideNavigationTest.kt:587)
at ru.liturgyguide.ui.GuideNavigationTest.orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase(GuideNavigationTest.kt:152)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-orderOpensAtCreedAndManualBrowsingReturnsToTheCurrentPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
GuideNavigationTestru.liturgyguide.ui>searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a8647ed, window-token=android.view.ViewRootImpl$W@a8647ed, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional(GuideNavigationTest.kt:466)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@a8647ed, window-token=android.view.ViewRootImpl$W@a8647ed, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional(GuideNavigationTest.kt:466)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForADailyReadingUsesTodaysTextAndKeepsItsNoteOptional.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
GuideNavigationTestru.liturgyguide.ui9searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-searchingForCreedOpensTheMatchingTextAndClosesTheKeyboard.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
m
GuideNavigationTestru.liturgyguide.ui&heardWordsLeadToTheRelevantExplanation2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b393277, window-token=android.view.ViewRootImpl$W@b393277, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.heardWordsLeadToTheRelevantExplanation(GuideNavigationTest.kt:68)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b393277, window-token=android.view.ViewRootImpl$W@b393277, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.GuideNavigationTest.openStage(GuideNavigationTest.kt:581)
at ru.liturgyguide.ui.GuideNavigationTest.heardWordsLeadToTheRelevantExplanation(GuideNavigationTest.kt:68)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-heardWordsLeadToTheRelevantExplanation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

MainContextTestru.liturgyguide.ui<anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainContextTest-anOldReadingKeepsTheCurrentServicePrimaryAndCanStillBeOpened.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
MainScheduleOverviewTestru.liturgyguide.ui/publishedFractionalSecondsAreNotSilentlyRounded2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-publishedFractionalSecondsAreNotSilentlyRounded.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui5evenARecentSavedReadingNeverMasksCurrentOrNextService2�������:�����ܠv"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-evenARecentSavedReadingNeverMasksCurrentOrNextService.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
u
MainScheduleOverviewTestru.liturgyguide.ui*eachServiceButtonRetainsItsExactOccurrence2������w:�����أ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-eachServiceButtonRetainsItsExactOccurrence.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui<unknownScheduleKeepsManualReadingAndTempleSelectionAvailable2�������:������ǚ"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-unknownScheduleKeepsManualReadingAndTempleSelectionAvailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui4aFuturePersonalStartShowsItsYearAndTheParishTimeZone2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-aFuturePersonalStartShowsItsYearAndTheParishTimeZone.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
MainScheduleOverviewTestru.liturgyguide.ui9informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable2��������:�����ʾ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-informationOnlyCardsRemainVisibleWhenOpeningIsUnavailable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
ManualMomentFlowTestru.liturgyguide.uiBcorrectionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@6c63705, window-token=android.view.ViewRootImpl$W@6c63705, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.correctionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks(ManualMomentFlowTest.kt:165)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@6c63705, window-token=android.view.ViewRootImpl$W@6c63705, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.correctionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks(ManualMomentFlowTest.kt:165)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionSearchAcceptsTheMatchingPhraseAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiMallFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification2��������:�����뮽"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-allFiveLandmarksWithoutAScheduleOpenTheExpectedTextAndPhraseAfterVerification.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiDacceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks2��������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-acceptingACorrectionOpensTextAtTheLandmarkAndPreservesOtherBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiQactivePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime2�����أ�:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-activePlayerPausesBeforeThePhraseBoundaryAndCorrectionNeverConsumesBackgroundTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
ManualMomentFlowTestru.liturgyguide.uiHcorrectionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@309225b, window-token=android.view.ViewRootImpl$W@309225b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.correctionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens(ManualMomentFlowTest.kt:125)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@309225b, window-token=android.view.ViewRootImpl$W@309225b, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.correctionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens(ManualMomentFlowTest.kt:125)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionCancelRestoresMeaningAndANonInitialPhraseAcrossAllThreeScreens.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
ManualMomentFlowTestru.liturgyguide.ui7choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation2��������:�������b"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.uiAsavedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot2�������q:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-savedReadingNoticeUsesCorrectionAndKeepsTheAcceptedPausedSnapshot.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
ManualMomentFlowTestru.liturgyguide.uiCaFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem2������҈:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@c01f07a, window-token=android.view.ViewRootImpl$W@c01f07a, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.aFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem(ManualMomentFlowTest.kt:271)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@c01f07a, window-token=android.view.ViewRootImpl$W@c01f07a, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.ManualMomentFlowTest.typeSearch(ManualMomentFlowTest.kt:345)
at ru.liturgyguide.ui.ManualMomentFlowTest.aFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem(ManualMomentFlowTest.kt:271)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-aFreshManualEntryResetsSearchListeningAndScrollButBackPreservesThem.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ManualMomentFlowTestru.liturgyguide.ui;correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase2�����ɞ�:�������6"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
|
PersonalServiceTimeTestru.liturgyguide.ui2failedStorageKeepsTheDraftAndCancelDoesNotTryAgain2�������7:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@44c62a9, window-token=android.view.ViewRootImpl$W@44c62a9, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.replace(PersonalServiceTimeTest.kt:156)
at ru.liturgyguide.ui.PersonalServiceTimeTest.failedStorageKeepsTheDraftAndCancelDoesNotTryAgain(PersonalServiceTimeTest.kt:92)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@44c62a9, window-token=android.view.ViewRootImpl$W@44c62a9, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.replace(PersonalServiceTimeTest.kt:156)
at ru.liturgyguide.ui.PersonalServiceTimeTest.failedStorageKeepsTheDraftAndCancelDoesNotTryAgain(PersonalServiceTimeTest.kt:92)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-failedStorageKeepsTheDraftAndCancelDoesNotTryAgain.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
PersonalServiceTimeTestru.liturgyguide.ui:impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving2��������:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@322e644, window-token=android.view.ViewRootImpl$W@322e644, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving(PersonalServiceTimeTest.kt:50)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@322e644, window-token=android.view.ViewRootImpl$W@322e644, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving(PersonalServiceTimeTest.kt:50)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-impossibleDateAndOutOfRangeTimeRemainEditableWithoutSaving.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
}
PersonalServiceTimeTestru.liturgyguide.ui2removalTargetsOnlyTheSelectedDateAndReportsFailure2��������:��������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@68db23a, window-token=android.view.ViewRootImpl$W@68db23a, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.removalTargetsOnlyTheSelectedDateAndReportsFailure(PersonalServiceTimeTest.kt:123)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@68db23a, window-token=android.view.ViewRootImpl$W@68db23a, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.removalTargetsOnlyTheSelectedDateAndReportsFailure(PersonalServiceTimeTest.kt:123)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-removalTargetsOnlyTheSelectedDateAndReportsFailure.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
PersonalServiceTimeTestru.liturgyguide.uiCanAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext2��������:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@acf22dc, window-token=android.view.ViewRootImpl$W@acf22dc, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.anAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext(PersonalServiceTimeTest.kt:105)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@acf22dc, window-token=android.view.ViewRootImpl$W@acf22dc, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.anAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext(PersonalServiceTimeTest.kt:105)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-anAbsoluteDateAndDraftSurviveRestorationAndSaveWithTheParishContext.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
t
PersonalServiceTimeTestru.liturgyguide.ui*changingTheDateLoadsOnlyThatDatesSavedTime2��������:�����ʬt�)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3a1d9e2, window-token=android.view.ViewRootImpl$W@3a1d9e2, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.changingTheDateLoadsOnlyThatDatesSavedTime(PersonalServiceTimeTest.kt:35)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@3a1d9e2, window-token=android.view.ViewRootImpl$W@3a1d9e2, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.changingTheDateLoadsOnlyThatDatesSavedTime(PersonalServiceTimeTest.kt:35)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-changingTheDateLoadsOnlyThatDatesSavedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�0
�
PersonalServiceTimeTestru.liturgyguide.ui7daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected2�������t:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@86e1ed6, window-token=android.view.ViewRootImpl$W@86e1ed6, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected(PersonalServiceTimeTest.kt:73)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@86e1ed6, window-token=android.view.ViewRootImpl$W@86e1ed6, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected(PersonalServiceTimeTest.kt:73)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-daylightSavingGapAndRepeatedHourAreNotSilentlyCorrected.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�1
�
PersonalServiceTimeTestru.liturgyguide.uiNpublishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState2��������:���������)
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@db2b872, window-token=android.view.ViewRootImpl$W@db2b872, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.publishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState(PersonalServiceTimeTest.kt:145)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@db2b872, window-token=android.view.ViewRootImpl$W@db2b872, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.PersonalServiceTimeTest.click(PersonalServiceTimeTest.kt:153)
at ru.liturgyguide.ui.PersonalServiceTimeTest.publishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState(PersonalServiceTimeTest.kt:145)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.PersonalServiceTimeTest-publishedAndPersonalStartsStaySeparateAndRemovingPersonalRestoresTheEmptyState.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui7aSingleTextRetainsItsFullTitleAndTheClarificationAction2��������:�����Ю��

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aSingleTextRetainsItsFullTitleAndTheClarificationAction(ReaderAccessibilityTest.kt:128)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aSingleTextRetainsItsFullTitleAndTheClarificationAction(ReaderAccessibilityTest.kt:128)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aSingleTextRetainsItsFullTitleAndTheClarificationAction.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAscriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu2��������:���������

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu(ReaderAccessibilityTest.kt:141)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu(ReaderAccessibilityTest.kt:141)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable2�������:�������o"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAaTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize2�������p:������ȭ�

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize(ReaderAccessibilityTest.kt:109)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize(ReaderAccessibilityTest.kt:109)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBlandscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize2��������:�������n�

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.orient(ReaderAccessibilityTest.kt:334)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:103)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.orient(ReaderAccessibilityTest.kt:334)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:103)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-landscapeKeepsTabsOnOneLineAndLeavesSpaceForTheRequestedPrayerSize.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiLlargeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent2������ά:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-largeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea2��������:�������=�

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea(ReaderAccessibilityTest.kt:118)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea(ReaderAccessibilityTest.kt:118)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiBnarrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase2�����ͻ>:�����蛠�

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase(ReaderAccessibilityTest.kt:67)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase(ReaderAccessibilityTest.kt:67)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiAordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed2������ؠ:���������

�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed(ReaderAccessibilityTest.kt:49)
0androidx.compose.ui.test.ComposeTimeoutException�androidx.compose.ui.test.ComposeTimeoutException: Condition still not satisfied after 10000 ms
at androidx.compose.ui.test.AndroidComposeUiTestEnvironment$AndroidComposeUiTestImpl.waitUntil(ComposeUiTest.android.kt:441)
at androidx.compose.ui.test.junit4.AndroidComposeTestRule.waitUntil(AndroidComposeTestRule.android.kt:306)
at ru.liturgyguide.ui.ReaderAccessibilityTest.awaitPlatformReady(ReaderAccessibilityTest.kt:338)
at ru.liturgyguide.ui.ReaderAccessibilityTest.launchReader(ReaderAccessibilityTest.kt:224)
at ru.liturgyguide.ui.ReaderAccessibilityTest.ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed(ReaderAccessibilityTest.kt:49)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/

SavedChurchFlowTestru.liturgyguide.ui8cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish2��������:���������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@aae91d1, window-token=android.view.ViewRootImpl$W@aae91d1, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish(SavedChurchFlowTest.kt:59)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@aae91d1, window-token=android.view.ViewRootImpl$W@aae91d1, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish(SavedChurchFlowTest.kt:59)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-cancellingANewTempleAndAnEmptySearchKeepTheCurrentParish.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
z
SavedChurchFlowTestru.liturgyguide.ui3aTempleInAnotherCityAndItsTimeZoneSurviveRecreation2�������:���������'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@83ac945, window-token=android.view.ViewRootImpl$W@83ac945, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.aTempleInAnotherCityAndItsTimeZoneSurviveRecreation(SavedChurchFlowTest.kt:36)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@83ac945, window-token=android.view.ViewRootImpl$W@83ac945, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.aTempleInAnotherCityAndItsTimeZoneSurviveRecreation(SavedChurchFlowTest.kt:36)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-aTempleInAnotherCityAndItsTimeZoneSurviveRecreation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
}
SavedChurchFlowTestru.liturgyguide.ui6favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage2��������:��������(
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@1a8c286, window-token=android.view.ViewRootImpl$W@1a8c286, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage(SavedChurchFlowTest.kt:79)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@1a8c286, window-token=android.view.ViewRootImpl$W@1a8c286, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.SavedChurchFlowTest.favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage(SavedChurchFlowTest.kt:79)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedChurchFlowTest-favoriteDoesNotChooseAnotherParishOrEraseTheSavedStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.ui?legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-legacyTrackBookmarksKeepTheirPhraseButDiscardTheOldTimerOffsets.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
�
SavedReadingTestru.liturgyguide.uiAanOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions2��������:�����ᝡ�'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b066786, window-token=android.view.ViewRootImpl$W@b066786, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.SavedReadingTest.anOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions(SavedReadingTest.kt:79)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@b066786, window-token=android.view.ViewRootImpl$W@b066786, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=false, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.pressBack(Espresso.java:2)
at ru.liturgyguide.ui.SavedReadingTest.anOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions(SavedReadingTest.kt:79)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-anOldSavedReadingIsLabelledPausedAndANewServiceClearsItsPositions.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�

SavedReadingTestru.liturgyguide.ui<aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks2�������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aPresentCorruptSnapshotCannotSilentlyReimportLegacyBookmarks.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
SavedReadingTestru.liturgyguide.uiLaLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.SavedReadingTest-aLegacyFinishedTextRestoresItsLastPhrasePausedWithoutInventingNewElapsedTime.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
z
StageSelectorTestru.liturgyguide.ui5updatingTheCurrentStageDoesNotInterruptManualBrowsing2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-updatingTheCurrentStageDoesNotInterruptManualBrowsing.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
v
StageSelectorTestru.liturgyguide.ui1searchStartsAtTheTopEvenWhenTheCurrentStageIsLate2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-searchStartsAtTheTopEvenWhenTheCurrentStageIsLate.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�.
~
StageSelectorTestru.liturgyguide.ui9restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition2������Ԣ:��������'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@daa7a3d, window-token=android.view.ViewRootImpl$W@daa7a3d, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.StageSelectorTest.restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition(StageSelectorTest.kt:89)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@daa7a3d, window-token=android.view.ViewRootImpl$W@daa7a3d, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.StageSelectorTest.restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition(StageSelectorTest.kt:89)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-restoringSearchKeepsTheQueryAndTheManuallyBrowsedPosition.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�/
{
StageSelectorTestru.liturgyguide.ui7editingAndClearingAQueryShowTheBeginningOfTheNewResults2��������:�������`�'
�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@6dec308, window-token=android.view.ViewRootImpl$W@6dec308, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.StageSelectorTest.editingAndClearingAQueryShowTheBeginningOfTheNewResults(StageSelectorTest.kt:66)
Handroidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException�androidx.test.espresso.base.RootViewPicker$RootViewWithoutFocusException: Waited for the root of the view hierarchy to have window focus and not request layout for 10 seconds. If you specified a non default root matcher, it may be picking a root that never takes focus. Root:
Root{application-window-token=android.view.ViewRootImpl$W@6dec308, window-token=android.view.ViewRootImpl$W@6dec308, has-window-focus=false, layout-params-type=1, layout-params-string={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, decor-view-string=DecorView{id=-1, visibility=VISIBLE, width=1080, height=2400, has-focus=true, has-focusable=true, has-window-focus=false, is-clickable=false, is-enabled=true, is-focused=false, is-focusable=false, is-layout-requested=false, is-selected=false, layout-params={(0,0)(fillxfill) sim={forwardNavigation} ty=BASE_APPLICATION wanim=0x1030309
fl=LAYOUT_IN_SCREEN LAYOUT_INSET_DECOR SPLIT_TOUCH HARDWARE_ACCELERATED DRAWS_SYSTEM_BAR_BACKGROUNDS
pfl=NO_MOVE_ANIMATION EDGE_TO_EDGE_ENFORCED FORCE_DRAW_STATUS_BAR_BACKGROUND FIT_INSETS_CONTROLLED
bhv=DEFAULT
fitSides=
frameRateBoostOnTouch=true
dvrrWindowFrameRateHint=true}, tag=null, root-is-layout-requested=false, has-input-connection=false, x=0.0, y=0.0, child-count=1}}
at dalvik.system.VMStack.getThreadStackTrace(Native Method)
at java.lang.Thread.getStackTrace(Thread.java:1841)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:2)
at androidx.test.espresso.base.EspressoExceptionHandler.handleSafely(EspressoExceptionHandler.java:1)
at androidx.test.espresso.base.DefaultFailureHandler$TypedFailureHandler.handle(DefaultFailureHandler.java:4)
at androidx.test.espresso.base.DefaultFailureHandler.handle(DefaultFailureHandler.java:5)
at androidx.test.espresso.ViewInteraction.waitForAndHandleInteractionResults(ViewInteraction.java:8)
at androidx.test.espresso.ViewInteraction.desugaredPerform(ViewInteraction.java:11)
at androidx.test.espresso.ViewInteraction.perform(ViewInteraction.java:8)
at androidx.test.espresso.Espresso.closeSoftKeyboard(Espresso.java:2)
at ru.liturgyguide.ui.StageSelectorTest.editingAndClearingAQueryShowTheBeginningOfTheNewResults(StageSelectorTest.kt:66)
"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.StageSelectorTest-editingAndClearingAQueryShowTheBeginningOfTheNewResults.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiBlanguageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause2�������a:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-languageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
~
UnifiedPlayerFlowTestru.liturgyguide.ui5endStopsThePlayerAndFinishingClearsTheAcceptedReading2�����أ�:������߀"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-endStopsThePlayerAndFinishingClearsTheAcceptedReading.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui>oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader2��������:��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-oldRunningSessionAndWallClockChangesCannotMoveTheUnifiedReader.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiMshortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase2�������:������֬"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-shortenedDuplicateTitleKeepsBothTextsDiscoverableAndRestoresTheSelectedPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiEmissingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation2�����ғ�:�����ҡ�"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-missingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
{
UnifiedPlayerFlowTestru.liturgyguide.ui2onePlayMovesThroughTextsAUsefulWaitAndTheNextStage2�����ۛ�:������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-onePlayMovesThroughTextsAUsefulWaitAndTheNextStage.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiAchangingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase2������ƹ:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-changingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiQexplicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-explicitRestartReplacesOnlyTheCorruptSnapshotEvenWhenContextAndMarkerAreIdentical.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.ui<losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning2�������:�������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo�
�
UnifiedPlayerFlowTestru.liturgyguide.uiJscriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer2������':��������"�

logcatandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.UnifiedPlayerFlowTest-scriptureCannotMasqueradeAsOriginalAndThePreferredLanguageReturnsForPrayer.txt"�

device-infoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/PravoslavnyyProvodnik/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/emulator-5554 - 15/testlog/test-results.log 2
text/plain