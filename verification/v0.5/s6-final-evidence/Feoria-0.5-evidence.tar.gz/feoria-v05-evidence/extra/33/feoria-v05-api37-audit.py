from pathlib import Path
import hashlib,importlib.util,json,re,sys,xml.etree.ElementTree as ET,zipfile
sys.dont_write_bytecode=True
R=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik');B=R/'app/build/verification/v0.5/s6-api37-smoke'
load=lambda p:json.loads(p.read_text())
def streamhash(f,algo='sha256'):
 h=hashlib.new(algo)
 while chunk:=f.read(4*1024*1024):h.update(chunk)
 return h.hexdigest()
def sha(p,algo='sha256'):
 with p.open('rb') as f:return streamhash(f,algo)
spec=importlib.util.spec_from_file_location('h',R/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
allowed=[{'package':'com.android.launcher3','title':'Taskbar'}]
helperhashes=load(B/'support/hashes.json');checked=[]
for name,value in helperhashes.items():assert sha(B/'support'/name)==value;checked.append(str(B/'support'/name))
s1=(B/'support/feoria-api37-ui-v1.py').read_text();s2=(B/'support/feoria-api37-ui.py').read_text();assert s1.replace('allowed=[]',"allowed=[{'package':'com.android.launcher3','title':'Taskbar'}]")==s2
views={};captures=[];errors=[];taps=[];records={}
for f in sorted(B.glob('ui/*/record.json')):
 j=load(f);records[j['label']]=j;assert j['apk_sha256']=='06001192794dc7ddfaf7bcf950265e761e8a9d06758eb2f280d0b1a70be3b592';assert j['helper_sha256'] in helperhashes.values()
 for a in j['artifacts']:
  p=f.parent/a['path'];assert sha(p)==a['sha256'] and p.stat().st_size==a['bytes'];checked.append(str(p))
 for prefix in ['before','after']:
  p=f.parent/(prefix+'.xml')
  if p.exists():views[(j['label'],prefix)]=h.View(p.read_bytes(),(f.parent/(prefix+'-windows.txt')).read_text(),(f.parent/(prefix+'-displays.txt')).read_text(),'ru.liturgyguide',allowed)
 if j['status']=='ERROR':errors.append({'label':j['label'],'error':j['error']});continue
 assert j['status']=='OBSERVED'
 if j['action']=='capture':
  assert views[(j['label'],'before')].canonical==views[(j['label'],'after')].canonical
  captures.append({'label':j['label'],'png_sha256':sha(f.parent/'screen.png'),'started_ns':j['started_ns'],'finished_ns':j['finished_ns']})
 if j['action']=='tap':
  assert list(views[(j['label'],'before')].target(j['selector']))==j['coordinates'];views[(j['label'],'after')].expect(j['expected']);taps.append(j['label'])
assert len(captures)==4 and len(errors)==1 and errors[0]['error']=="unexpected visible overlay: ('com.android.launcher3', 'Taskbar')"
# Exact allowance controls, no parser change or hidden broad window permission
v=views[('fresh-main-taskbar','before')];assert ('com.android.launcher3','Taskbar') in v.visible_windows
try:h.parse_windows(v.windows,v.displays,'ru.liturgyguide');raise AssertionError('unexpected unallowed pass')
except h.GateError as e:assert "('com.android.launcher3', 'Taskbar')" in str(e)
blocks=re.split(r'(?=^  Window #\d+ Window\{)',v.windows,flags=re.M);indices=[i for i,b in enumerate(blocks) if re.search(r'^  Window #\d+ Window\{\S+ u\d+ Taskbar\}:',b)];assert len(indices)==1;i=indices[0]
for name,newblock in [('foreign-owner',blocks[i].replace('package=com.android.launcher3','package=foreign.overlay')),('other-title',blocks[i].replace(' Taskbar}', ' OtherPanel}'))]:
 changed=blocks.copy();changed[i]=newblock
 try:h.parse_windows(''.join(changed),v.displays,'ru.liturgyguide',allowed);raise AssertionError(name+' accepted')
 except h.GateError:pass
# Actual observed checked lyrics and pause controls
for label,prefix,number,button in [('play','before',1,'Включить плеер'),('play','after',1,'Остановить плеер'),('meaning-pauses','before',6,'Остановить плеер'),('original-paused','after',7,'Включить плеер'),('original-reader','before',7,'Включить плеер'),('original-reader','after',7,'Включить плеер'),('next-phrase','before',7,'Включить плеер'),('next-phrase','after',8,'Включить плеер'),('cold-saved-reader','after',8,'Включить плеер')]:
 views[(label,prefix)].expect([{'text':f'Фраза {number}/20'},{'content-desc':button}])
lyrics={}
for key in [('play','before'),('meaning-pauses','before'),('original-paused','after'),('original-reader','after'),('next-phrase','before'),('next-phrase','after'),('cold-saved-reader','after')]:
 selected=[n.get('text') for n in views[key].nodes if n.get('checked')=='true' and n.get('text')];assert len(selected)==1;lyrics['/'.join(key)]=selected[0]
assert lyrics['original-paused/after']==lyrics['original-reader/after']==lyrics['next-phrase/before']
assert lyrics['next-phrase/after']==lyrics['cold-saved-reader/after']
for label in ['original-paused','original-reader','cold-saved-reader']:views[(label,'after')].expect([{'text':'Оригинал','ancestor':{'class':'android.view.View','selected':True}}])
setup={}
for f in sorted(B.glob('root-setup/*/record.json')):
 j=load(f)
 for name in ['stdout','stderr']:assert sha(f.parent/name)==j[name+'_sha256'];checked.append(str(f.parent/name))
 setup[j['reason']]={'record':j,'stdout':(f.parent/'stdout').read_text(),'stderr':(f.parent/'stderr').read_text()}
assert setup['actual-sdk']['stdout'].strip()=='37';assert setup['own-avd']['stdout'].splitlines()[0]=='Feoria_QA_API_37'
assert setup['pid-before-cold']['stdout'].strip()=='2605' and setup['pid-after-cold']['stdout'].strip()=='3522'
assert setup['cold-absent']['record']['exit_code']==1 and setup['cold-absent']['stdout']==setup['cold-absent']['stderr']==''
assert setup['pid-before-cold']['record']['finished_ns']<setup['cold-stop']['record']['started_ns']<setup['cold-absent']['record']['started_ns']<setup['cold-launch']['record']['started_ns']<setup['pid-after-cold']['record']['started_ns']<records['reopen-saved']['started_ns']
assert sha(Path(setup['install-signed']['record']['command'][-1]))==records['play']['apk_sha256']
assert setup['final-crash']['stdout']==''
events=[]
for line in setup['final-events']['stdout'].splitlines():
 m=re.match(r'\s*(\d+\.\d+)\s',line)
 if m:events.append((float(m[1]),line))
crashes=[line for t,line in events if 'ru.liturgyguide' in line and re.search(r'\b(am_crash|am_anr):',line)];assert not crashes
assert setup['final-events']['record']['started_ns']>max(x['finished_ns'] for x in captures)
mainreasons=re.findall(r'^\s*process=ru\.liturgyguide reason=([^\n]+)',setup['final-exit-info']['stdout'],re.M);assert len(mainreasons)==1 and mainreasons[0].startswith('10 (USER REQUESTED) subreason=21 (FORCE STOP)')
# Verify Google catalog identity and every unchanged archive payload file, entirely on host
identity=load(B/'support/image-identity.json');zpath=Path('/private/tmp/feoria-api37-official.zip');assert zpath.stat().st_size==identity['bytes'];assert sha(zpath,'sha1')==identity['sha1_checked']
rt=ET.parse(B/'support/feoria-api37-official-catalog.xml').getroot();remote=next(n for n in rt if n.tag.rsplit('}',1)[-1]=='remotePackage' and n.get('path')=='system-images;android-37.0;default;arm64-v8a')
assert int(remote.findtext('./archives/archive/complete/size'))==identity['bytes'];assert remote.findtext('./archives/archive/complete/checksum')==identity['sha1_checked'];assert identity['source']=='https://dl.google.com/android/repository/sys-img/android/'+remote.findtext('./archives/archive/complete/url')
local=next(n for n in ET.parse(B/'support/package.xml').getroot() if n.tag.rsplit('}',1)[-1]=='localPackage');assert local.get('path')==remote.get('path')
def tree(n):return (n.tag,sorted(n.attrib.items()),(n.text or '').strip(),[tree(c) for c in n])
assert [tree(n) for n in local]==[tree(n) for n in remote if n.tag not in ['archives','channelRef']]
imgroot=Path('/private/tmp/liturgy-android-toolchain/sdk/system-images/android-37.0/default');payload=[]
with zipfile.ZipFile(zpath) as z:
 for item in z.infolist():
  if item.is_dir():continue
  p=imgroot/item.filename;assert p.stat().st_size==item.file_size
  with z.open(item) as f:expected=streamhash(f)
  actual=sha(p);assert actual==expected,item.filename
  payload.append({'path':item.filename,'bytes':item.file_size,'sha256':actual})
assert sha(imgroot/'arm64-v8a/package.xml')==sha(B/'support/package.xml')
assert sha(imgroot/'arm64-v8a/source.properties')==sha(B/'support/source.properties')
assert 'Android emulator version 37.2.13.0' in (B/'support/emulator.log').read_text()
out={'verdict':'ACCEPT bounded API37 compatibility smoke, no complete release gate claim','source_apk':records['play']['apk_sha256'],'artifact_hashes':len(checked),'reparsed_views':len(views),'captures':captures,'successful_taps':taps,'preserved_errors':errors,'checked_lyrics':lyrics,'cold_pid':['2605','3522'],'crash':{'events_min':min(t for t,l in events),'events_max':max(t for t,l in events),'capture_started_ns':setup['final-events']['record']['started_ns'],'target_crash_anr':crashes,'buffer_empty':True,'main_exit_reasons':mainreasons},'official_image':identity,'package_metadata_matches_catalog':True,'payload':payload,'setup':setup}
Path('/private/tmp/feoria-v05-api37-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['setup','payload']},ensure_ascii=False,indent=2));print('Unchanged payload entries:',len(payload))
