# coding: utf-8
from pathlib import Path
import subprocess,time,json,hashlib,uuid,sys
ROOT=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/verification/v0.5/s6-api37-smoke')
assert ROOT.is_dir()
assert len(sys.argv)>2 and sys.argv[1].strip()
command=['/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb','-s','emulator-5554',*sys.argv[2:]]
d=ROOT/'root-setup'/(str(time.time_ns())+'-'+uuid.uuid4().hex[:6]);d.mkdir(parents=True)
r={'command':command,'reason':sys.argv[1],'started_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),'status':'STARTED','verdict':'NOT_REVIEWED','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(d/'record.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
try:
 p=subprocess.run(command,capture_output=True,timeout=60)
 (d/'stdout').write_bytes(p.stdout);(d/'stderr').write_bytes(p.stderr)
 r.update(exit_code=p.returncode,status='EXECUTED' if p.returncode==0 else 'ERROR',finished_ns=time.time_ns(),finished_monotonic_ns=time.monotonic_ns(),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest())
 print(p.stdout.decode(errors='replace')[:3000]);print(p.stderr.decode(errors='replace')[:1000]);print(str(d))
except Exception as e:
 r.update(status='ERROR',error=str(e));raise
finally:(d/'record.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
raise SystemExit(p.returncode)
