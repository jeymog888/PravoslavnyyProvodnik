# coding: utf-8
"""Root-directed API37 compatibility observations/actions only; no setup/install/data injection."""
from pathlib import Path
import importlib.util,json,sys,time,uuid,argparse
p=argparse.ArgumentParser();p.add_argument('action',choices=['show','tap','capture']);p.add_argument('--selector');p.add_argument('--expect',default='[]');p.add_argument('--label',required=True);a=p.parse_args()
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
spec=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
adb=h.Adb('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb','emulator-5554');pkg='ru.liturgyguide';allowed=[]
assert adb.shell('getprop','ro.kernel.qemu')=='1' and adb.shell('getprop','ro.build.version.sdk')=='37'
assert a.label.replace('-','').isalnum()
out=repo/'app/build/verification/v0.5/s6-api37-smoke/ui'/(str(time.time_ns())+'-'+a.label);out.mkdir(parents=True)
r={'action':a.action,'label':a.label,'started_ns':time.time_ns(),'status':'STARTED','visual':'NOT_REVIEWED','helper_sha256':h.sha(__file__)}
h.write_json(out/'started.json',r)
def save(v,name):
 (out/(name+'.xml')).write_bytes(v.xml);(out/(name+'-windows.txt')).write_text(v.windows);(out/(name+'-displays.txt')).write_text(v.displays)
try:
 r['apk_sha256']=adb.installed_hash(pkg);assert r['apk_sha256']=='06001192794dc7ddfaf7bcf950265e761e8a9d06758eb2f280d0b1a70be3b592'
 expected=json.loads(a.expect)
 if a.action=='capture':
  before,png,after=h.static_capture(adb,pkg,expected,allowed,timeout=30);save(before,'before');save(after,'after');(out/'screen.png').write_bytes(png)
 else:
  before=adb.view(pkg,allowed);save(before,'before');after=before
  if a.action=='tap':
   h.validate_expected(expected)
   r['selector']=json.loads(a.selector);r['expected']=expected;x,y=before.target(r['selector']);r['coordinates']=[x,y]
   adb.shell('input','tap',str(x),str(y));after=h.wait_for(adb,pkg,expected,allowed,timeout=30);save(after,'after')
  else:
   for n in before.nodes:
    if n.get('text') or n.get('content-desc'):
     print({k:n.get(k) for k in ('text','content-desc','bounds','checked','selected','clickable')},'parent',{k:before.parents[n].get(k) for k in ('checked','selected','clickable','bounds')})
 assert adb.installed_hash(pkg)==r['apk_sha256'];r['status']='OBSERVED'
except Exception as e:r['status']='ERROR';r['error']=str(e);raise
finally:
 r['finished_ns']=time.time_ns();r['artifacts']=[h.artifact(f,out) for f in sorted(out.iterdir()) if f.is_file()];h.write_json(out/'record.json',r);print(str(out))
