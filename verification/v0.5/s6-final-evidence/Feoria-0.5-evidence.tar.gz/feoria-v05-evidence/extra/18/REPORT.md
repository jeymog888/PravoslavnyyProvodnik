# CI 42511850558, attempt 1 - FAIL

Проверен точный run head `7900494e5f2320f5669927acea8b14465816d1dd`, GitHub conclusion `failure`

- Unit: 336/336 PASS, 0 failures/errors/skips, 25 JUnit XML, 336 уникальных случаев
- UI: 60/120 PASS, 60 FAIL, 0 errors/skips, 120 уникальных случаев
- Lint: 0 errors/fatal, 14 warnings
- Artifact `verification-reports`, ID `13630915355`, 2015969 bytes
- SHA256 `056755e1415d4368c119cd709043cd859dfa051ae23db6c17b75c76fbb65e275` совпадает с digest GitHub API

## Установленные факты

До начала suite и после него присутствует одно и то же системное ANR-окно Pixel Launcher. Обе реальные PNG просмотрены независимо: `artifact/ci-diagnostics/preflight-screen.png` и `after-suite-screen.png` показывают "Pixel Launcher isn't responding"

В обоих `*-displays.stdout:9` current focus равен `Window{3a12cf0 u0 Application Not Responding: com.google.android.apps.nexuslauncher}`. Exact window inventory в `*-windows.stdout:280-305` связывает этот token с `mOwnerUid=1000`, `package=android`, `isOnScreen=true`. Это установленное препятствие готовности окружения. Поле focusedApp само по себе не заменяет фактический focused window

Оба замера power: Awake, Changing=false, HalInteractive=true. Keyguard showing=false, occluded=false. Screen timeout2147483647, stay-on1, show-IME1. Нет оснований объяснять этот run таймаутом экрана или блокировкой

Первый failed test: `ChurchDiscoveryScreenTest.timeoutEmptyResultsAndOldCachedResultsRemainDistinct`, ожидание видимости IME, timeout10000ms. Его logcat содержит `PHASE_CLIENT_REQUEST_IME_SHOW` failure в18:56:22.522. Всего45 failures содержат RootViewWithoutFocusException; остальные15 относятся к IME/readiness/orientation ожиданиям. Все полные traces сохранены в `ui-failures.json`

## Пробел диагностики

Первый per-test packet реально записан по сообщению `FeoriaCiDiagnostics` в18:56:33.303, строка272 файла `artifact/outputs/androidTest-results/connected/debug/emulator-5554 - 15/logcat-ru.liturgyguide.ui.ChurchDiscoveryScreenTest-timeoutEmptyResultsAndOldCachedResultsRemainDistinct.txt`

После suite host pull каталога `/sdcard/Android/data/ru.liturgyguide/files/ci-diagnostics/42511850558-1` вернул exit1 и "No such file or directory". Поэтому packet до teardown в артефакте отсутствует. Причина исчезновения каталога не установлена; нельзя утверждать, что это конкретный uninstall или test cleanup без отдельного доказательства. Raw preflight/after-suite сохранились успешно, все24 диагностические команды завершились0

## Границы и минимальный следующий шаг

Этот run не является release PASS. До запуска UI suite требуется проверяемая готовность AVD без ANR/чужого блокирующего окна; наличие этого окна должно останавливать suite с сохранением диагностики. Любое восстановление launcher требует отдельного явного действия и повторного наблюдения, а не ослабления assertions, таймаутов или скрытого повтора теста

Нужно обеспечить доставку первого packet до исчезновения app-external каталога. Сейчас отсутствие packet не маскирует Gradle failure, но ограничивает точное объяснение каждой отдельной ошибки

В успешном run42507137388 такого focused ANR в preflight/after-suite не было. Это сравнение не доказывает причину каждого прежнего сбоя. По текущим данным нельзя приписывать все60 failures единственной причине или объявлять изменения приложения дефектными/исправными по этому заблокированному прогону

Reviewer не запускал adb, Gradle, новые workflow, retries/cancel и не менял repository. Архив скачан точный, SHA проверен; manifest локальных доказательств сохранен отдельно
