from pathlib import Path
import ast,hashlib,importlib.util,json,re,sys
sys.dont_write_bytecode=True
R=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik');B=R/'app/build/verification/v0.5/s6-api26-smoke'
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('h',R/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
baseparse=h.parse_windows
code=B/'support/feoria-api26-ui.py';func=next(n for n in ast.parse(code.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parse26');ns={'re':re,'parse35':baseparse};exec(compile(ast.Module(body=[func],type_ignores=[]),str(code),'exec'),ns);h.parse_windows=ns['parse26']
helperhashes=load(B/'support/hashes.json')
for name,value in helperhashes.items():assert sha(B/'support'/name)==value
checked=[];views={};captures=[];errors=[];taps=[]
for f in sorted(B.glob('ui/*/record.json')):
 j=load(f);assert j['apk_sha256']=='06001192794dc7ddfaf7bcf950265e761e8a9d06758eb2f280d0b1a70be3b592';assert j['helper_sha256'] in helperhashes.values()
 for a in j['artifacts']:
  p=f.parent/a['path'];assert sha(p)==a['sha256'] and p.stat().st_size==a['bytes'];checked.append(str(p))
 for prefix in ['before','after']:
  p=f.parent/(prefix+'.xml')
  if p.exists():views[(j['label'],prefix)]=h.View(p.read_bytes(),(f.parent/(prefix+'-windows.txt')).read_text(),(f.parent/(prefix+'-displays.txt')).read_text(),'ru.liturgyguide')
 if j['status']=='ERROR':errors.append({'label':j['label'],'error':j['error']});continue
 assert j['status']=='OBSERVED'
 if j['action']=='capture':
  assert views[(j['label'],'before')].canonical==views[(j['label'],'after')].canonical
  captures.append({'label':j['label'],'png_sha256':sha(f.parent/'screen.png'),'started_ns':j['started_ns'],'finished_ns':j['finished_ns']})
 if j['action']=='tap':
  assert list(views[(j['label'],'before')].target(j['selector']))==j['coordinates']
  views[(j['label'],'after')].expect(j['expected']);taps.append(j['label'])
assert len(captures)==6 and len(errors)==2
# Recheck v2 against actual known-format baseline plus seven rejecting controls
fixture=B/'ui/1794166562318090000-fresh-main';w=(fixture/'before-windows.txt').read_text();d=(fixture/'before-displays.txt').read_text()
start=w.index('  Window #4 ');end=w.index('  Window #5 ',start);block=w[start:end];line=next(x for x in block.splitlines() if x.strip().startswith('mHasSurface='))
mut=lambda changed:w[:start]+changed+w[end:]
cases=[('actual',w,d,True),('duplicate-valid',mut(block.replace(line,line+'\n'+line)),d,False),('duplicate-invalid',mut(block.replace(line,line+'\n    mHasSurface=unknown')),d,False),('invalid-tail',mut(block.replace(line,line+' isReadyForDisplay()=false')),d,False),('unknown-owner',mut(block.replace('mOwnerUid=','unknownOwner=')),d,False),('unknown-visibility',mut(block.replace('isReadyForDisplay()=true','isReadyForDisplay()=unknown')),d,False),('unknown-focus',w.replace('mCurrentFocus=Window{75953b2','mCurrentFocus=Window{unknown'),d,False),('unknown-size',w,re.sub(r'\bcur=\d+x\d+','cur=unknown',d),False)]
controls=[]
for name,raw,disp,expected in cases:
 try:ns['parse26'](raw,disp,'ru.liturgyguide');accepted=True;error=None
 except Exception as e:accepted=False;error=str(e)
 assert accepted==expected,(name,accepted);controls.append({'case':name,'accepted':accepted,'error':error})
def require(label,prefix,expected):views[(label,prefix)].expect(expected)
ru1='Верю в единого Бога Отца, Который держит весь мир в Своей власти.';ru4='Он рожден от Отца прежде всех времен.';or4='Иже от Отца рожденнаго прежде всех век.'
require('play','before',[{'text':ru1,'checked':True},{'content-desc':'Включить плеер'}]);require('play','after',[{'text':ru1,'checked':True},{'content-desc':'Остановить плеер'}])
require('meaning-pauses','before',[{'text':ru4,'checked':True},{'content-desc':'Остановить плеер'}]);require('meaning','after',[{'text':'Смысл','ancestor':{'class':'android.view.View','selected':True}}])
for label in ['original-paused','original-after-play']:
 require(label,'after' if label=='original-paused' else 'before',[{'text':or4,'checked':True},{'content-desc':'Включить плеер'},{'text':'Фраза 4/20'}])
for label in ['russian-reader','cold-saved-reader']:
 require(label,'after',[{'text':ru4,'checked':True},{'content-desc':'Включить плеер'},{'text':'По-русски','ancestor':{'class':'android.view.View','selected':True}},{'text':'Фраза 4/20'}])
require('cold-actual','before',[{'text':'Сохраненное чтение'}])
require('unavailable-asr','after',[{'text':'На телефоне нет локального распознавания. Выберите этап по подсказкам'}])
require('manual-reader','after',[{'text':'Подготовка к литургии'},{'text':'1 из 18 · Порядок'},{'content-desc':'Включить плеер'}])
setup={}
for f in sorted(B.glob('root-setup/*/record.json')):
 j=load(f)
 for name in ['stdout','stderr']:assert sha(f.parent/name)==j[name+'_sha256'];checked.append(str(f.parent/name))
 setup[j['reason']]={'record':j,'stdout':(f.parent/'stdout').read_text(),'stderr':(f.parent/'stderr').read_text()}
assert setup['pid-before-cold']['stdout'].strip()=='2763';assert setup['pid-after-cold']['stdout'].strip()=='4328'
assert setup['cold-absent']['record']['exit_code']==1 and setup['cold-absent']['stdout']==setup['cold-absent']['stderr']==''
assert setup['pid-before-cold']['record']['finished_ns']<setup['cold-stop']['record']['started_ns']<setup['cold-absent']['record']['started_ns']<setup['cold-launch']['record']['started_ns']<setup['pid-after-cold']['record']['started_ns']
assert setup['disable-wifi']['record']['exit_code']==137
assert setup['network-before']['stdout']==setup['connectivity-after-wifi-command']['stdout'] and 'Active default network: 101' in setup['connectivity-after-wifi-command']['stdout']
crash=setup['final-crash']['stdout'];assert 'com.android.commands.svc.WifiCommand.run' in crash and 'SecurityException: WifiService: Neither user 2000 nor current process has android.permission.CHANGE_WIFI_STATE' in crash and 'ru.liturgyguide' not in crash
assert 'Bad file descriptor' in crash
es=[]
for line in setup['final-events']['stdout'].splitlines():
 m=re.match(r'\s*(\d+\.\d+)\s',line)
 if m:es.append((float(m[1]),line))
crashes=[line for t,line in es if 'ru.liturgyguide' in line and re.search(r'\b(am_crash|am_anr):',line)];assert not crashes
assert min(t for t,_ in es)<min(x['started_ns'] for x in captures)/1e9
assert setup['final-events']['record']['started_ns']>max(x['finished_ns'] for x in captures)
# Sparse events have no new row after the final ordinary UI interaction; record bounds without inventing a later event
out={'verdict':'ACCEPT observed API26 compatibility scope; OFFLINE NOT COMPLETED; no aggregate clean-run PASS','helper_v2':sha(code),'controls':controls,'reparsed_views':len(views),'artifact_hashes':len(checked),'captures':captures,'successful_taps':taps,'preserved_ui_errors':errors,'cold_pid':['2763','4328'],'events_bounds':[min(t for t,_ in es),max(t for t,_ in es)],'target_crash_anr':crashes,'offline':{'exit':137,'network':101,'primary_error':'SecurityException CHANGE_WIFI_STATE denied to uid 2000','secondary_error':'Bad file descriptor while reporting command crash'},'setup':setup}
Path('/private/tmp/feoria-v05-api26-audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='setup'},ensure_ascii=False,indent=2))
