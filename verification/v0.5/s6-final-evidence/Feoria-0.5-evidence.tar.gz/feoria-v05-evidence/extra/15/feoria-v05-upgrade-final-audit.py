from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET,zipfile,subprocess,os
R=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
B=R/'app/build/verification/v0.5'; U=B/'s6-final-upgrade35'; O=B/'s6-upgrade-old-prep'; C=B/'s6-upgrade-checkpoints'; S=B/'s6-upgrade-setup'
load=lambda p:json.loads(p.read_text()); sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def artifact(base,a):
 p=base/a['path'];assert p.is_file(),p;assert sha(p)==a['sha256'],p
 if 'bytes' in a:assert p.stat().st_size==a['bytes'],p
 checks.append(str(p))
def match(n,s):
 return all(n.get(k)==('true' if v is True else 'false' if v is False else str(v)) for k,v in s.items())
def selects(root,s):
 par={ch:n for n in root.iter() for ch in n}; simple={k:v for k,v in s.items() if k!='ancestor'}
 for n in root.iter('node'):
  if not match(n,simple):continue
  if 'ancestor' not in s:return True
  q=par.get(n)
  while q is not None:
   if match(q,s['ancestor']):return True
   q=par.get(q)
 return False
run=load(U/'run.json');build=load(U/'build.json');manifest=load(U/'manifest.json'); before=load(C/'before/result.json');after=load(C/'after/result.json')
assert sha(U/'build.json')==run['build_sha256']==before['pair']['build_sha256']
assert sha(U/'manifest.json')==run['manifest_sha256']
assert sha(U/'build.log')==build['log_sha256']
assert sha(R/'scripts/harness/feoria_harness.py')==run['harness_sha256']
assert before['pair']==after['pair'];assert before['status']==after['status']=='PASS'
oldapk=Path(load(S/'intent.json')['old_apk']);newapk=Path(build['apk']['path'])
assert sha(oldapk)==before['pair']['old_sha256'];assert sha(newapk)==before['pair']['new_sha256']==run['installed_sha256']
cert_results=[]
for apk in [oldapk,newapk]:
 env=dict(os.environ,JAVA_HOME='/private/tmp/liturgy-android-toolchain/jdk-17.0.21+9/Contents/Home')
 cmd=['/private/tmp/liturgy-android-toolchain/sdk/build-tools/34.0.0/apksigner','verify','--print-certs',str(apk)]
 p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=30);assert p.returncode==0,p.stderr
 cert=re.findall(r'^Signer #1 certificate SHA-256 digest: ([0-9a-f]+)$',p.stdout,re.M);assert cert==[before['pair']['certificate_sha256']]
 cert_results.append({'path':str(apk),'sha256':sha(apk),'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
pb=(C/'before/preferences.xml').read_bytes();pa=(C/'after/preferences.xml').read_bytes();assert pb==pa
assert hashlib.sha256(pb).hexdigest()==before['preferences_sha256']==after['preferences_sha256']
values={n.get('name'):(n.text if n.tag=='string' else n.get('value')) for n in ET.fromstring(pb)}
assert not {'service_playback_v1','reading_context_v1'}&values.keys()
assert len(values)==len(list(ET.fromstring(pb)))
for key in ['app_id','first_install_time']:assert before['package'][key]==after['package'][key]
for phase,res in [('before',before),('after',after)]:
 raw=(C/phase/'package.txt').read_text()
 for k,pat in [('app_id',r'^\s*appId=(\d+)'),('first_install_time',r'^\s*firstInstallTime=([^\n]+)'),('version_code',r'^\s*versionCode=(\d+)'),('version_name',r'^\s*versionName=([^\n]+)')]:
  assert re.findall(pat,raw,re.M)==[res['package'][k]]
 assert (C/phase/'pidof.stdout').read_bytes()==(C/phase/'pidof.stderr').read_bytes()==b''
 assert res['no_app_pid']
# Content identity is recomputed from each APK's embedded actual asset, using Kotlin UTF-16 length prefixes
content=[]
def digest(*parts):return hashlib.sha256(''.join(str(len(v.encode('utf-16-le'))//2)+':'+v for v in parts).encode()).hexdigest()[:24]
for apk in [oldapk,newapk]:
 with zipfile.ZipFile(apk) as z:stages=json.loads(z.read('assets/liturgy_stages.json'))
 if isinstance(stages,dict):stages=stages['stages']
 stage=next(s for s in stages if s['id']=='cherubic_hymn');t=stage['texts'][0]
 lines=[x['original'].strip() for x in t['lines']];track='cherubic_hymn:prayer:'+digest(t['type'],'\n'.join(lines));phrase=track+':'+digest(lines[1])
 assert track==before['reading']['track_id'];assert phrase==before['reading']['phrase_id'];assert lines[1]==before['reading']['expected_visible_original']
 content.append({'apk':sha(apk),'track':track,'phrase':phrase,'second':lines[1],'third':lines[2]})
oldcaptures=[]
for f in sorted(O.glob('*/record.json')):
 j=load(f)
 assert j['apk_sha256']==before['pair']['old_sha256']
 for a in j.get('artifacts',[]):artifact(f.parent,a)
 if j['action']=='capture' and j['status']=='OBSERVED':
  assert (f.parent/'before.xml').read_bytes()==(f.parent/'after.xml').read_bytes()
  oldcaptures.append({'path':str(f.parent),'png':sha(f.parent/'screen.png'),'started_ns':j['started_ns'],'finished_ns':j['finished_ns']})
assert len(oldcaptures)==3
oldxml=ET.parse(O/'1794165839363475000-old-second-original/after.xml').getroot()
assert selects(oldxml,{'text':content[0]['second'],'checked':True})
static=[];expectedcount=0
for case in manifest['cases']:
 p=U/'cases'/case['id'];j=load(p/'case.json');v=load(p/'review.json')
 assert j['status']=='PASS' and j['run_id']==run['run_id'] and j['apk_sha256']==run['installed_sha256'] and j['manifest_sha256']==run['manifest_sha256']
 for a in j['artifacts'].values():artifact(U,a)
 assert (p/'before.xml').read_bytes()==(p/'after.xml').read_bytes()
 xml=ET.parse(p/'after.xml').getroot()
 for s in case['expected']:assert selects(xml,s),(case['id'],s);expectedcount+=1
 assert v['run_id']==run['run_id'] and v['screen_sha256']==sha(p/'screen.png') and v['decision']=='ACCEPT'
 static.append({'id':case['id'],'started_ns':j['started_ns'],'finished_ns':j['finished_ns'],'png':sha(p/'screen.png')})
actions=[]
for p in sorted((U/'actions').glob('*/action.json')):
 j=load(p);assert j['status']=='PASS' and j['run_id']==run['run_id'] and j['apk_sha256']==run['installed_sha256']
 for a in j['artifacts']:artifact(U,a)
 for s in j['expected']:assert selects(ET.parse(p.parent/'after.xml').getroot(),s)
 actions.append({'directory':p.parent.name,'selector':j['selector']})
nextaction=U/'actions/1794165994171158000-b3ba4f70'
assert selects(ET.parse(nextaction/'before.xml').getroot(),{'text':content[0]['second'],'checked':True})
assert selects(ET.parse(nextaction/'after.xml').getroot(),{'text':content[0]['third'],'checked':True})
assert (nextaction/'after.xml').read_bytes()==(U/'cases/cold-reader/after.xml').read_bytes()
records=[json.loads(x) for x in (U/'raw-setup-observations.jsonl').read_text().splitlines()]
assert all(x['outcome'] in ['STARTED','RECORDED'] for x in records)
completed=[x for x in records if x['outcome']=='RECORDED']
for j in completed:
 assert j['run_id']==run['run_id'] and j['apk_sha256']==run['installed_sha256']
 for a in j.get('artifacts',[]):artifact(U,a)
launches=[j for j in completed if j['details'].get('action')=='launch']
assert before['finished_ns']<run['started_ns']<after['started_ns']<after['finished_ns']<launches[0]['started_ns']
assert all(j['started_ns']>after['finished_ns'] for j in records)
assert before['installed_sha256']==sha(oldapk) and after['installed_sha256']==sha(newapk)
artifact(U,run['install_log']);assert (U/'install.log').read_text()=='Performing Streamed Install\nSuccess\n'
setup=[]
for f in sorted(S.glob('root-setup/*/record.json')):
 j=load(f)
 for k in ['stdout','stderr']:assert sha(f.parent/k)==j[k+'_sha256'];checks.append(str(f.parent/k))
 setup.append({'started_ns':j['started_ns'],'finished_ns':j['finished_ns'],'command':j['command'][3:],'exit':j['exit_code'],'stdout':(f.parent/'stdout').read_text()})
interval=[j for j in setup if before['finished_ns']<=j['started_ns']<=after['finished_ns']]
assert not interval,interval
assert len([j for j in setup if j['command'][0]=='install'])==1
assert max(x['finished_ns'] for x in oldcaptures)<before['started_ns']
assert next(x for x in setup if x['command'][:3]==['shell','id','-u'])['stdout']=='2000\n'
stop=load(U/'cold-check/stopped.json');newprocess=load(U/'cold-check/new-process.json')
assert stop['exit_code']==1 and (U/'cold-check/stopped-stdout').read_bytes()==(U/'cold-check/stopped-stderr').read_bytes()==b''
assert newprocess['exit_code']==0 and newprocess['pid_before']=='15428' and newprocess['stdout']==newprocess['pid_after']=='16580'
assert int(newprocess['pid_before'])!=int(newprocess['pid_after']) and stop['wall_ns']<launches[1]['started_ns']<newprocess['wall_ns']
for name in ['events','crash','exit-info','shell-user']:
 j=load(U/f'crash-check/{name}.json');assert j['exit_code']==0
 assert sha(U/f'crash-check/{name}.txt')==j['stdout_sha256'];checks.append(str(U/f'crash-check/{name}.txt'))
 assert sha(U/f'crash-check/{name}.stderr')==j['stderr_sha256'];checks.append(str(U/f'crash-check/{name}.stderr'))
events=[]
for line in (U/'crash-check/events.txt').read_text().splitlines():
 m=re.match(r'\s*(\d+\.\d+)\s',line)
 if m:events.append((float(m[1]),line))
assert min(t for t,_ in events)<run['started_ns']/1e9
assert max(t for t,_ in events)>max(x['finished_ns'] for x in static)/1e9
crashes=[x for t,x in events if t>=run['started_ns']/1e9 and re.search(r'\b(am_crash|am_anr):',x) and 'ru.liturgyguide' in x];assert not crashes
processstarts=[x for t,x in events if before['finished_ns']/1e9<=t<after['finished_ns']/1e9 and 'am_proc_start:' in x and 'ru.liturgyguide' in x];assert not processstarts
mainreasons=re.findall(r'^\s*process=ru\.liturgyguide reason=([^\n]+)',(U/'crash-check/exit-info.txt').read_text(),re.M)
assert len(mainreasons)==2 and all(x.startswith('10 (USER REQUESTED) subreason=21 (FORCE STOP)') for x in mainreasons)
assert (U/'crash-check/shell-user.txt').read_text().strip()=='2000'
for name,digest_value in load(U/'support/hashes.json').items():assert sha(U/'support'/name)==digest_value;checks.append(str(U/'support'/name))
gate=load(U/'gate.json');assert gate['status']=='PASS' and gate['required_cases']==gate['passed_cases']==6
output={'status':'ACCEPT for observed upgrade scenario','run_id':run['run_id'],'source':build['source'],'apk_pair':before['pair'],'certificates_independently_reverified':cert_results,'preferences':{'bytes':len(pb),'sha256':before['preferences_sha256'],'same_identity':after['package'],'old_has_no_05_metadata':True},'content_identity':content,'timeline':{'before_started':before['started_ns'],'before_finished':before['finished_ns'],'begin_install':run['started_ns'],'after_started':after['started_ns'],'after_finished':after['finished_ns'],'first_launch_started':launches[0]['started_ns']},'old_pngs':oldcaptures,'new_cases':static,'static_selector_assertions':expectedcount,'actions':actions,'setup':setup,'cold':{'stopped':stop,'new':newprocess},'crash':{'events_min':min(t for t,_ in events),'events_max':max(t for t,_ in events),'target_crashes':crashes,'main_exit_reasons':mainreasons,'uid':'2000'},'artifact_hash_checks':len(checks),'artifacts_checked':checks}
Path('/private/tmp/feoria-v05-upgrade-final-audit.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:output[k] for k in ['status','timeline','artifact_hash_checks','static_selector_assertions','crash']},ensure_ascii=False,indent=2))
