# Astra preflight: launcher ANR до UI suite

Рекомендация: одна небольшая итерация только подготовки CI и доставки диагностики. Приложение, сценарии тестов, assertions и их timeout не менять. Уже принятые локальные 336/120 и native-сценарии signed APK повторять из-за этого CI не требуется

## Что доказано

Run `42511850558`, attempt 1: 336 unit PASS, UI 120 с 60 failures по данным ответственного reviewer. Общий CI остается FAILURE. Это не повтор одиночного lazy-node failure run42508996635

Независимо прочитаны реальные файлы `/private/tmp/feoria-ci-v05-run42511850558-attempt1/artifact/ci-diagnostics/` и просмотрен preflight PNG:

- До запуска Gradle уже открыт "Pixel Launcher isn't responding"
- `preflight-displays.stdout:9` и `after-suite-displays.stdout:9`: тот же focused `Window{3a12cf0 u0 Application Not Responding: com.google.android.apps.nexuslauncher}`
- В обоих power dumps Awake, Changing=false, HAL interactive=true; policy showing=false
- Следовательно, увеличение screen timeout, wake/unlock, изменение IME ожиданий и production не устраняют установленную причину непригодности среды
- Исходный `run_android_ui_tests.py` только делает best_effort snapshot. Он явно не выносит readiness verdict и всегда запускает Gradle после снимка, даже когда на снимке ANR
- В logcat `ChurchDiscoveryScreenTest-timeoutEmptyResultsAndOldCachedResultsRemainDistinct` строка 272: `18:56:33.303 ... First failure evidence: /storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/42511850558-1/first-failure-1794164192758`
- Финальный pull возвращает exit_code=1 и `No such file or directory` для того же run. Пакет был объявлен записанным, но по текущему единственному пути уже недоступен после suite

Конкретная причина удаления или исчезновения app-scoped каталога пока не установлена. Не писать в отчете, что Gradle доказанно удалил его: соответствующей записи в прочитанном job log нет. Но доставка, зависящая только от доступности каталога приложения после завершения Gradle, уже доказанно ненадежна

Наличие launcher ANR до тестов достаточно, чтобы отклонить среду. Оно не доказывает причинность каждого из 60 отдельных failures; безопасная формулировка - "suite выполнен в заранее непригодной среде, нарушения focus/readiness согласуются с наблюденным ANR"

## Маленький patch-plan

Область: `scripts/ci/run_android_ui_tests.py`, при необходимости один явный opt-in параметр в `.github/workflows/build.yml`, и только доставка в androidTest `CiFailureDiagnostics.kt`. Не менять `ChurchDiscoveryScreenTest`, input helpers, assertions, timeout тестов, Gradle retry и runtime

### 1. Сначала доказательства, потом готовность

Сохранить исходный snapshot/PNG и commands journal до любых подготовительных действий. Имена `preflight-original-*` или нынешние preflight не перезаписывать после recovery

В wrapper добавить небольшой разбор текущих raw OS наблюдений с результатом READY / KNOWN_LAUNCHER_ANR / NOT_READY / UNKNOWN. UNKNOWN трактовать как запрет старта, не как успех

Для READY нужны наблюденные boot_completed=1, awake/interactive, keyguard=false, текущий focus нормального Home launcher и отсутствие показанного блокирующего ANR/crash dialog. Проверять действующий focus/window и его видимость, не любую историческую строку ANR из logcat или activity history. Повторное независимое чтение должно подтвердить состояние; несколько чтений в одном ограниченном pre-suite deadline, например 20 секунд, допустимы. Это ожидание готовности среды, не повтор теста

Нельзя выводить READY только из того, что `adb shell am start` вернул 0. Нельзя использовать один grep по всему dumpsys как надежный owner oracle. Android владеет системным ANR окном; пакет отказавшего launcher установлен из точного заголовка, Home component - из resolver/Activity evidence

### 2. Допустим ровно один условный restart собственного launcher

Я предпочитаю этот ограниченный вариант чистому fail-fast, поскольку текущая причина известна и возникла еще до app suite. Но reset разрешен только если одновременно:

- Workflow явно разрешил preparation recovery и устройство - принадлежащий этому job emulator-5554, qemu/emulator property подтверждена
- Разрешенный HOME component фактически разрешается в `com.google.android.apps.nexuslauncher/.NexusLauncherActivity` на этой CI image
- Исходный focus/visible window подтверждает именно его ANR, а не ANR приложения, System UI или неизвестный overlay
- Все первоначальные доказательства уже записаны на host
- Gradle UI suite еще не запущен и счетчик recovery равен 0

Тогда один записанный `am force-stop` только этого launcher и один запуск наблюденного HOME component. Это restart процесса, без `pm clear`, очистки данных, uninstall, изменения screen timeout, закрытия всех dialogs или перезагрузки устройства. Я не предполагаю, что restart гарантированно уберет dialog: это обязан подтвердить следующий readiness snapshot

После этого один ограниченный readiness цикл в том же preparation budget, новый PNG и raw state. Если ANR сохранился/вернулся, появился другой блокирующий owner, команда не прошла или данные UNKNOWN - ENVIRONMENT_FAILED, Gradle не запускать. Не делать второй restart и не переходить к другому способу "починки"

Если root выбирает еще меньший патч, безопасный альтернативный вариант - сразу fail-fast при любом неготовом preflight. Он закрывает ложный старт, но сам по себе не восстанавливает CI. При невозможности надежно классифицировать именно launcher ANR следует выбрать этот вариант

В result сохранить `tests_started`, readiness verdict, original/post-recovery evidence, recovery_count=0/1, команды и результаты. Для подготовки FAIL `test_exit_code=null`, отдельный ненулевой exit status и честное "tests not started". После запуска Gradle его exit code сохранить без замены; никаких recovery, повторов тестов или blanket dismissal после старта suite

### 3. Доставить первый packet до того, как исчезнет app storage

Предпочтительный минимальный механизм - shell-owned mirror вне каталога приложения, например `/data/local/tmp/feoria-ci-diagnostics/<validated-run-id>/`, с выгрузкой этого пути в существующем host finally

Host preparation создает ровно свой уникальный run directory и записывает этот факт. Не удаляет чужие run directories и не продолжает при коллизии. Run id уже ограничен `[A-Za-z0-9_-]{1,100}`

Collector оставляет создание файлов в нынешнем app-scoped каталоге, но до возврата из capture и до rethrow делает одну bounded shell-копию завершенного packet в подготовленный путь. Shell выполняется существующим `uiAutomation.executeShellCommand`, который уже используется collector. Не пытаться писать Java File прямо в `/data/local/tmp` от UID приложения

Для shell-копии использовать только известный путь текущего target package, валидированный run id и собственное числовое имя packet. Не интерполировать Throwable, имя теста или непроверенный произвольный путь в команду. Сохранять stderr/status и явный completion marker только после успешного копирования. Частичную копию не объявлять готовым packet

Сохранить общий diagnostic budget 30 секунд: заранее зарезервировать небольшую часть, например 3 секунды, для экспорта и сократить доступное время предыдущим чтениям на этот резерв. Это изменение бюджета диагностики, не увеличение timeout теста. Если экспорт не удался - записать failure в logcat/доступный metadata, бросить исходный Throwable. Диагностика не должна блокировать исходный результат

В host finally pull shell-owned run path, сохранить результат; нынешний app-scoped pull можно оставить дополнительным best-effort источником. Не заменять сохраненную копию пустым поздним результатом. Директория host диагностики уже включена в Upload verification reports с always()

Не добавлять одновременно live watcher, polling pull, runner plugin, новый persistence framework или принудительно падающий тест в основной suite. Одного mirror + одного финального pull достаточно для этой итерации. Если исполнителю проще и надежнее использовать уже поддержанный Gradle additional-test-output transport, сначала нужно подтвердить его фактическую поддержку текущим AGP и выгрузку до cleanup; непроверенный параметр не заменяет transport

## Проверка патча и предел одной итерации

1. Host-only checks parser на настоящих preflight/after-suite ANR fixtures этого run: готовность запрещена. Нормальный launcher fixture должен разрешать, missing/ambiguous focus и другой ANR должны запрещать
2. Host fake-command checks: при неизвестном ANR нет reset/Gradle; известный launcher дает не более одного reset; второй плохой snapshot не запускает Gradle; READY запускает команду ровно один раз; ее nonzero exit не превращается в PASS; всегда сохраняется журнал
3. Compile androidTest при изменении collector. Полную локальную 336/120 и signed-native ветку не повторять: runtime и сценарии неизменны
4. Один CI запуск нового точного commit. В нем либо подготовка честно останавливается с evidence и без UI, либо запускается ровно один полный suite после записанного READY. Разобрать фактические XML и delivery status
5. Если среда снова неготова, не запускать новый CI автоматически. Если появляется другой отказ теста на READY-среде, использовать сохраненный packet и выбрать следующий конкретный шаг по фактам. Успех recovery не объявлять устранением системной первопричины launcher ANR

Текущий run42511850558 остается FAIL с сохраненным точным artifact. Старый одиночный lazy-node FAIL также не закрывается одним объяснением launcher ANR: это другой run и другой набор фактов

Этот preflight ничего не имплементировал, не запускал adb/Gradle/CI, не менял runtime или репозиторий. Записан только данный отчет
