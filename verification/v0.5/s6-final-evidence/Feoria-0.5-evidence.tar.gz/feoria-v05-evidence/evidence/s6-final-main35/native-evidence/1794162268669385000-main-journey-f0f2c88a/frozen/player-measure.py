#!/usr/bin/env python3
"""Measure real player movement and Meaning pause on an already installed release.

No install, clear, preference access, root, setup injection, or static-case approval.
Optional lifecycle checks prove paused UI on return, NOT exact background position.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys
import time
import traceback
import uuid

sys.dont_write_bytecode = True
PACKAGE = "ru.liturgyguide"
SIGNER = "bb0ea3162b2129b7411ed3a15956c6f2065c685574c1caa24fb260e452ef5247"
PLAY = {"content-desc": "Включить плеер"}
STOP = {"content-desc": "Остановить плеер"}


def mode(label):
    return {"text": label, "ancestor": {"class": "android.view.View", "selected": True}}


def arguments():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "run", "build", "manifest", "adb", "serial", "case"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--api", required=True, type=int)
    p.add_argument("--start-phrase", type=int, default=4, help="One-based noninitial full-Creed phrase")
    p.add_argument("--speed-label", choices=("0,75×", "1×", "1,25×"), default="1×")
    p.add_argument("--play-timeout", type=float, default=30, help="Entire Play-to-change phase, <=30s")
    p.add_argument("--lifecycle", choices=("none", "home", "home-sleep"), default="none")
    return p.parse_args()


class Measurement:
    def __init__(self, args):
        self.a = args
        self.repo, self.run = Path(args.repo).resolve(), Path(args.run).resolve()
        source = self.repo / "scripts/harness/feoria_harness.py"
        spec = importlib.util.spec_from_file_location("feoria_measure_harness", source)
        if spec is None or spec.loader is None:
            raise ValueError("repository harness cannot be loaded")
        self.h = h = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(h)
        h.require(0 < args.play_timeout <= 30 and args.api >= 26, "invalid bounded timeout/API")
        _, self.record, self.manifest = h.load_run(self.run)
        h.require(h.canonical(h.read_json(args.manifest)) == h.canonical(self.manifest),
                  "external manifest differs from fixed run")
        h.require(h.sha(args.build) == self.record["build_sha256"], "build receipt differs from fixed run")
        build = h.read_json(args.build)
        h.validate_build(build, Path(args.build).with_name("build.log"), build["apk"]["path"])
        apk = build["apk"]
        h.require(build["build_type"] == "release" and self.manifest["build_type"] == "release" and
                  self.manifest["package"] == PACKAGE and apk["package"] == PACKAGE and
                  apk.get("debuggable") is False and apk.get("certificate_sha256") == SIGNER and
                  str(apk["version_code"]) == "5" and apk["version_name"] == "0.5.0-guide",
                  "requires the same signed non-debuggable Feoria 0.5 release")
        h.require(self.record["serial"] == args.serial, "explicit serial differs from run")
        self.case = h.case_by_id(self.manifest, args.case)
        h.require(self.case.get("window_package", PACKAGE) == PACKAGE, "case must observe app window")
        h.require(self.case.get("observed_requirements", {}).get("sdk") == str(args.api),
                  "case must explicitly require requested API")
        self.allowed = self.case.get("allowed_windows", [])
        asset = self.repo / "app/src/main/assets/liturgy_stages.json"
        entries = [row for row in build["inputs_after"]["files"] if row["path"] == "app/src/main/assets/liturgy_stages.json"]
        h.require(len(entries) == 1 and h.sha(asset) == entries[0]["sha256"], "Creed asset differs from built input")
        creed = [s for s in h.read_json(asset)["stages"] if s["id"] == "creed"]
        h.require(len(creed) == 1, "Creed stage is ambiguous")
        tracks = [t for t in creed[0]["texts"] if t.get("title") == "Символ веры"]
        h.require(len(tracks) == 1, "full Creed track is ambiguous")
        self.lines = [row["original"].strip() for row in tracks[0]["lines"]]
        h.require(len(self.lines) == len(set(self.lines)) == 20, "requires the observed unique twenty-phrase Creed")
        h.require(2 <= args.start_phrase <= 10, "start with phrase 2..10, leaving room for real movement")
        self.directory = self.run / "native-evidence" / (str(time.time_ns()) + "-player-measure-" + uuid.uuid4().hex[:8])
        self.directory.mkdir(parents=True, exist_ok=False)
        self.phase, self.deadline, self.sequence = "initialization", None, 0
        self.result = {
            "kind": "real-player-measurement", "run_id": self.record["run_id"], "serial": args.serial,
            "sdk": str(args.api), "apk_sha256": apk["sha256"], "harness_sha256": h.sha(source),
            "measurement_sha256": h.sha(__file__), "started_ns": time.time_ns(),
            "started_monotonic_ns": time.monotonic_ns(), "outcome": "STARTED",
            "verdict": "NOT_REVIEWED", "scope": "real phrase movement; Meaning pause; 8s stationary",
            "lifecycle_requested": args.lifecycle, "release_verdict": "NOT_EVALUATED",
            "limits": ["No exact background-position snapshot", "No choir synchronization or rate calibration",
                       "No static visual acceptance, offline/cold/upgrade/Recents/rotation verification"],
            "observations": [], "actions": [], "checks": {},
        }
        h.write_json(self.directory / "started.json", self.result)
        self.append("measurement_started", {"arguments": vars(args)})
        owner = self

        class RecordedAdb(h.Adb):
            def run(self, *argv, timeout=30):
                owner.sequence += 1
                event = owner.directory / "commands" / f"{owner.sequence:05d}"
                event.mkdir(parents=True)
                effective = min(timeout, 30.0)
                if owner.deadline is not None:
                    effective = min(effective, h.remaining(owner.deadline))
                record = {"argv": [str(v) for v in argv], "phase": owner.phase,
                          "started_monotonic_ns": time.monotonic_ns(), "timeout_seconds": effective,
                          "apk_expected_sha256": owner.record["apk"]["sha256"], "outcome": "STARTED"}
                h.write_json(event / "started.json", record)
                try:
                    data = super().run(*argv, timeout=effective)
                    record.update(outcome="RECORDED", bytes=len(data), stdout_sha256=h.digest(data))
                    # Every installed APK read is hashed, without duplicating the same large binary.
                    apk_read = len(argv) == 3 and argv[:2] == ("exec-out", "cat") and str(argv[2]).endswith("/base.apk")
                    if apk_read:
                        record["installed_apk_sha256"] = h.digest(data)
                    else:
                        (event / "stdout.bin").write_bytes(data)
                    if owner.deadline is not None:
                        h.remaining(owner.deadline, reason="phase exceeded its monotonic deadline")
                    return data
                except BaseException as exc:
                    record.update(outcome="ERROR", error=repr(exc))
                    raise
                finally:
                    record["finished_monotonic_ns"] = time.monotonic_ns()
                    h.write_json(event / "record.json", record)
                    owner.append("command", {**record, "directory": str(event.relative_to(owner.directory))})

        self.adb = RecordedAdb(Path(args.adb).resolve(), args.serial)

    def append(self, kind, value):
        with (self.directory / "events.jsonl").open("a") as out:
            out.write(json.dumps({"kind": kind, "host_monotonic_ns": time.monotonic_ns(), **value}, ensure_ascii=False) + "\n")

    def bounded_phase(self, name, seconds=30):
        self.phase, self.deadline = name, time.monotonic() + seconds
        self.append("phase", {"name": name, "budget_seconds": seconds})

    def observe(self, label, expected_mode="Оригинал", playing=False, lyric=True):
        h = self.h
        folder = self.directory / "observations" / f"{len(self.result['observations']):03d}-{label}"
        folder.mkdir(parents=True)
        started = time.monotonic_ns()
        view = self.adb.view(PACKAGE, self.allowed, timeout=h.remaining(self.deadline))
        view_finished = time.monotonic_ns()
        for name, data in (("view.xml", view.xml), ("windows.txt", view.windows.encode()), ("displays.txt", view.displays.encode())):
            (folder / name).write_bytes(data)
        obs = {"label": label, "phase": self.phase, "view_started_monotonic_ns": started,
               "view_finished_monotonic_ns": view_finished, "tree_sha256": h.digest(view.xml),
               "directory": str(folder.relative_to(self.directory)), "mode": expected_mode}
        self.result["observations"].append(obs)
        self.append("view_captured", obs)
        view.expect([{"text": "Символ веры"}, mode(expected_mode), {"text": self.a.speed_label}] if lyric else
                    [{"text": "Символ веры"}, mode(expected_mode), {"text": "Что происходит"}])
        if lyric:
            wanted, opposite = (STOP, PLAY) if playing else (PLAY, STOP)
            view.target(wanted)  # Requires the actual enabled clickable ancestor in this dump.
            h.require(not view.matching(opposite), "ambiguous or wrong Play/Pause state")
            nodes = [n for n in view.nodes if n.get("text") in self.lines and n.get("checked") == "true"]
            h.require(len(nodes) == 1, "exactly one checked full-Creed lyric must be observed")
            line = nodes[0]
            h.bounds(line, view.size)
            h.require(line.get("checkable") == "true" and line.get("enabled") == "true" and line.get("clickable") == "true",
                      "checked lyric is not the observed enabled line control")
            obs.update(phrase=self.lines.index(line.get("text")) + 1, original=line.get("text"), playing=playing)
        facts = self.adb.facts(PACKAGE)
        h.write_json(folder / "facts.json", facts)
        for key in h.REQUIRED_FACTS:
            h.require(h.known(facts.get(key)), "required fact is unknown: " + key)
        h.require(facts["sdk"] == str(self.a.api) and facts["fingerprint"] == self.record["initial_facts"]["fingerprint"],
                  "observed device identity changed")
        h.require(str(facts["version_code"]) == "5" and facts["version_name"] == "0.5.0-guide", "installed version changed")
        for key, value in self.case.get("observed_requirements", {}).items():
            h.require(facts.get(key) == value, "case device condition changed: " + key)
        obs["installed_apk_sha256"] = h.verify_installed(self.adb, PACKAGE, self.record["apk"]["sha256"])
        obs["finished_monotonic_ns"] = time.monotonic_ns()
        h.remaining(self.deadline)
        h.write_json(folder / "observation.json", obs)
        self.append("observation_verified", obs)
        return obs

    def tap(self, selector, expected):
        started = time.monotonic_ns()
        result = self.h.tap(self.run, self.adb, self.a.case, selector, expected,
                            timeout=min(30, self.h.remaining(self.deadline)))
        action = {"selector": selector, "started_monotonic_ns": started,
                  "finished_monotonic_ns": time.monotonic_ns(), "result": result}
        self.result["actions"].append(action)
        self.append("harness_tap", action)

    def stationary(self, baseline, label):
        self.bounded_phase(label, 30)
        began = time.monotonic_ns()
        samples = 0
        while True:
            current = self.observe(label)
            samples += 1
            self.h.require(current["phrase"] == baseline["phrase"], "paused phrase moved during stationary interval")
            span = (current["view_started_monotonic_ns"] - began) / 1e9
            if span >= 8:
                return {"phrase": current["phrase"], "observed_span_seconds": span, "samples": samples,
                        "scope": "same checked phrase and paused controls at every observed sample"}
            time.sleep(min(0.25, self.h.remaining(self.deadline)))

    def lifecycle(self, kind):
        self.bounded_phase(kind + "-departure")
        before = self.observe(kind + "-before")
        self.tap(PLAY, [STOP, mode("Оригинал")])
        key = "KEYCODE_HOME" if kind == "home" else "KEYCODE_SLEEP"
        self.adb.shell("input", "keyevent", key)
        for service in ("power", "window", "activity"):
            self.adb.shell("dumpsys", service)
        # No inaccessible release preferences, root toggles, guessed launcher taps or lock dismissal.
        self.append("background_interval_start", {"kind": kind, "exact_pause_position": "NOT_OBSERVED"})
        time.sleep(1)
        self.bounded_phase(kind + "-return")
        if kind == "sleep":
            self.adb.shell("input", "keyevent", "KEYCODE_WAKEUP")
        self.adb.shell("am", "start", "-W", "-n", PACKAGE + "/.ui.MainActivity")
        returned = self.observe(kind + "-returned")
        stable = self.stationary(returned, kind + "-returned-stationary")
        return {"before_play_phrase": before["phrase"], "returned_phrase": returned["phrase"],
                "paused_on_return": True, "stationary": stable,
                "exact_background_drift_verdict": "NOT_EVALUATED",
                "sleep_or_keyguard_verdict": "RAW_DUMPS_REQUIRE_ROOT_REVIEW" if kind == "sleep" else "NOT_APPLICABLE",
                "return_method": "explicit am start, not Recents UI"}

    def execute(self):
        h = self.h
        self.bounded_phase("initial-paused")
        initial = self.observe("initial")
        h.require(initial["phrase"] == self.a.start_phrase, "start is not the declared nonfirst full-Creed phrase")
        self.bounded_phase("real-play-to-phrase-change", self.a.play_timeout)
        began = time.monotonic_ns()
        self.tap(PLAY, [STOP, mode("Оригинал")])
        while True:
            moving = self.observe("playing", playing=True)
            h.require(moving["phrase"] >= initial["phrase"], "real player moved backwards")
            if moving["phrase"] > initial["phrase"]:
                break
            time.sleep(min(0.25, h.remaining(self.deadline)))
        self.result["checks"]["real_movement"] = {
            "from_phrase": initial["phrase"], "to_phrase": moving["phrase"],
            "elapsed_phase_seconds": (time.monotonic_ns() - began) / 1e9,
            "deadline_seconds": self.a.play_timeout, "clock": "one-process host monotonic",
            "scope": "observed checked lyric advances after real Play; no next/seek/time injection"}
        self.bounded_phase("meaning-pauses")
        self.tap({"text": "Смысл"}, [mode("Смысл"), {"text": "Что происходит"}])
        self.observe("meaning", expected_mode="Смысл", lyric=False)
        self.tap({"text": "Оригинал"}, [mode("Оригинал"), PLAY])
        returned = self.observe("after-meaning")
        h.require(returned["phrase"] >= moving["phrase"], "Meaning return moved backwards")
        self.result["checks"]["meaning_pause"] = self.stationary(returned, "meaning-return-stationary")
        if self.a.lifecycle != "none":
            self.result["checks"]["home_return"] = self.lifecycle("home")
        if self.a.lifecycle == "home-sleep":
            self.result["checks"]["sleep_return"] = self.lifecycle("sleep")
        self.result.update(outcome="RECORDED", verdict="AUTOMATED_DYNAMIC_CHECKS_PASSED_ROOT_REVIEW_REQUIRED")

    def finish(self, error=None):
        self.deadline = None
        if error is not None:
            self.result.update(outcome="ERROR", verdict="FAIL", error=repr(error))
            (self.directory / "error.txt").write_text("".join(traceback.format_exception(type(error), error, error.__traceback__)))
        self.result.update(finished_ns=time.time_ns(), finished_monotonic_ns=time.monotonic_ns())
        self.append("measurement_finished", {"outcome": self.result["outcome"], "verdict": self.result["verdict"]})
        self.result["artifacts"] = [self.h.artifact(p, self.run) for p in sorted(self.directory.rglob("*"))
                                    if p.is_file() and p.stat().st_size > 0 and p.name != "record.json"]
        # Command record.json files also belong to evidence; exclude only this final record.
        self.result["artifacts"] += [self.h.artifact(p, self.run) for p in sorted((self.directory / "commands").glob("*/record.json"))]
        self.h.write_json(self.directory / "record.json", self.result)
        with (self.run / "raw-setup-observations.jsonl").open("a") as out:
            out.write(json.dumps({"directory": str(self.directory.relative_to(self.run)),
                                  "run_id": self.record["run_id"], "kind": "real-player-measurement",
                                  "outcome": self.result["outcome"], "verdict": self.result["verdict"]}, ensure_ascii=False) + "\n")
        print(json.dumps({"evidence": str(self.directory), "outcome": self.result["outcome"],
                          "verdict": self.result["verdict"], "checks": self.result["checks"],
                          "release_verdict": "NOT_EVALUATED"}, ensure_ascii=False, indent=2))


def main():
    args = arguments()
    measure = None
    try:
        measure = Measurement(args)
        measure.execute()
    except BaseException as error:
        if measure is not None:
            measure.finish(error)
        else:
            print("MEASUREMENT PRECONDITION FAILED: " + repr(error), file=sys.stderr)
        return 1
    measure.finish()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
