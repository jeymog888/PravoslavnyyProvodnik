#!/usr/bin/env python3
"""Confirmed eight-case main journey. No visual acceptance or final aggregation.

Only for an explicitly authorized synthetic local AVD. Creates one new driver run,
installs once through driver begin, clears app data once, then uses observed selectors.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback
import uuid
import zoneinfo

sys.dont_write_bytecode = True
PACKAGE = 'ru.liturgyguide'
DRIVER_SHA = 'a6cc34cda663123d2bbafc63ae493bbf26e17b3ddb3337432b2c0485a95be319'
MEASURE_SHA = '4f9b34b42dff6315fe283ced0e64838f3152224acb580e2e08078fc88168303f'
CASES = ['fresh','manual-form','manual-temple','personal-form','personal-service','scheduled-entry','creed-original','creed-meaning']
T = lambda text: {'text': text}
D = lambda text: {'content-desc': text}
TAB = lambda text: {'text': text, 'ancestor': {'class': 'android.view.View', 'selected': True}}
LYRIC = lambda text: {'text': text, 'checked': True}
PLAY = D('Включить плеер')
FIRST = 'Верую во единаго Бога Отца, Вседержителя,'
FOURTH = 'Иже от Отца рожденнаго прежде всех век.'
FOURTH_RU = 'Он рожден от Отца прежде всех времен.'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path, value):
    path=Path(path)
    if path.exists(): raise ValueError('evidence already exists: '+str(path))
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def require(ok, message):
    if not ok: raise ValueError(message)
def args():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('repo','build','run','manifest','adb','serial'):
        p.add_argument('--'+key,required=True)
    p.add_argument('--api',required=True,type=int)
    p.add_argument('--driver',default='/private/tmp/feoria-release-native-v05.py')
    p.add_argument('--measure',default='/private/tmp/feoria-v05-player-measure.py')
    p.add_argument('--clear-owned-synthetic-data',action='store_true',
                   help='Explicitly authorize one pm clear on the selected synthetic local AVD')
    return p.parse_args()

class Journey:
    def __init__(self,a):
        self.a=a;self.run=Path(a.run).resolve();self.repo=Path(a.repo).resolve()
        require(a.clear_owned_synthetic_data,'explicit synthetic-data clear authorization required')
        require(re.fullmatch(r'emulator-[0-9]+',a.serial) and a.api>=26,'explicit local AVD serial/API required')
        require(not self.run.exists(),'run must be new; no replay over a prior attempt')
        self.journal=self.run.with_name(self.run.name+'.main-journey')
        require(not self.journal.exists(),'journey journal already exists; preserve prior attempt')
        self.journal.mkdir(parents=True)
        self.sequence=0;self.bound=None;self.evidence=None
        self.result={'kind':'final-main-journey','outcome':'STARTED','started_ns':time.time_ns(),
                     'started_monotonic_ns':time.monotonic_ns(),'serial':a.serial,'sdk':str(a.api),
                     'script_sha256':sha(__file__),'run_path':str(self.run),'cases':CASES,
                     'visual_verdict':'NOT_REVIEWED','release_verdict':'NOT_EVALUATED','steps':[]}
        write(self.journal/'started.json',self.result)

    def call(self,label,argv,timeout=60):
        self.sequence+=1;stem=self.journal/f'{self.sequence:03d}-{label}'
        r={'label':label,'argv':[str(x) for x in argv],'started_ns':time.time_ns(),
           'started_monotonic_ns':time.monotonic_ns(),'outcome':'STARTED','timeout_seconds':timeout}
        write(str(stem)+'.started.json',r)
        stdout=stderr=b''
        try:
            p=subprocess.run(r['argv'],capture_output=True,timeout=timeout)
            stdout,stderr=p.stdout,p.stderr;r['exit_code']=p.returncode
            require(p.returncode==0,'command failed: '+label)
            r['outcome']='RECORDED'
            return stdout
        except BaseException as error:
            if isinstance(error,subprocess.TimeoutExpired):
                stdout=error.stdout or b'';stderr=error.stderr or b''
            r.update(outcome='ERROR',error=repr(error));raise
        finally:
            Path(str(stem)+'.stdout').write_bytes(stdout);Path(str(stem)+'.stderr').write_bytes(stderr)
            r.update(finished_ns=time.time_ns(),finished_monotonic_ns=time.monotonic_ns(),
                     stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
            write(str(stem)+'.json',r);self.result['steps'].append(r)
            print(f'{self.sequence:03d} {label}: {r["outcome"]}',flush=True)

    def adb(self,label,*argv,timeout=30):
        return self.call(label,[self.a.adb,'-s',self.a.serial,*argv],timeout=timeout)
    def qa(self,label,*argv):
        require(sha(self.repo/'scripts/harness/feoria_harness.py')==self.harness_sha,'live harness changed during journey')
        return self.call(label,[sys.executable,str(self.frozen/'driver.py'),'--repo',str(self.repo),
             '--adb',self.a.adb,'--serial',self.a.serial,'--run',str(self.run),'--build',self.a.build,
             '--manifest',self.a.manifest,'--api',str(self.a.api),*argv],timeout=150 if argv==('begin',) else 60)
    def tap(self,case,selector,expected):
        return self.qa('tap-'+case,'tap','--case',case,'--selector',json.dumps(selector,ensure_ascii=False),
                       '--expect',json.dumps(expected,ensure_ascii=False))
    def enter(self,case,label,value):
        return self.qa('type-'+case,'type','--case',case,'--selector',json.dumps(T(label),ensure_ascii=False),'--text',value)
    def capture(self,case): return self.qa('capture-'+case,'capture','--case',case)

    def prepare(self):
        a=self.a
        self.frozen=self.journal/'frozen';(self.frozen/'repo/scripts/harness').mkdir(parents=True)
        require(sha(a.driver)==DRIVER_SHA,'driver differs from reviewed version')
        require(sha(a.measure)==MEASURE_SHA,'real movement helper differs from reviewed version')
        source=self.repo/'scripts/harness/feoria_harness.py';self.harness_sha=sha(source)
        for source_file,destination in [(source,self.frozen/'repo/scripts/harness/feoria_harness.py'),
             (Path(a.driver),self.frozen/'driver.py'),(Path(a.measure),self.frozen/'player-measure.py'),
             (Path(__file__),self.frozen/'main-journey.py'),
             (self.repo/'app/src/main/assets/liturgy_stages.json',self.frozen/'repo/app/src/main/assets/liturgy_stages.json')]:
            destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source_file,destination)
        spec=importlib.util.spec_from_file_location('frozen_main_harness',self.frozen/'repo/scripts/harness/feoria_harness.py')
        self.h=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.h)
        self.manifest=self.h.validate_manifest(self.h.read_json(a.manifest));build=self.h.read_json(a.build)
        require([c['id'] for c in self.manifest['cases']]==CASES,'manifest must contain exactly the eight ordered main cases')
        require(self.manifest['package']==PACKAGE and self.manifest['build_type']=='release','wrong manifest')
        for c in self.manifest['cases']:
            require(c['human_review_required'] and c.get('window_package',PACKAGE)==PACKAGE
                    and c['observed_requirements']['sdk']==str(a.api),'case review/package/API binding differs')
        self.h.validate_build(build,Path(a.build).with_name('build.log'),build['apk']['path'])
        require(build['build_type']=='release' and build['harness_sha256']==self.harness_sha,'release/harness binding differs')
        require(build['apk']['package']==PACKAGE and build['apk']['version_code']=='5'
                and build['apk']['version_name']=='0.5.0-guide' and build['apk']['debuggable'] is False,
                'requires signed Feoria 0.5 release receipt')
        require(build['apk']['certificate_sha256']=='bb0ea3162b2129b7411ed3a15956c6f2065c685574c1caa24fb260e452ef5247','wrong release signer')
        self.result.update(apk_sha256=build['apk']['sha256'],harness_sha256=self.harness_sha,
                           driver_sha256=DRIVER_SHA,measure_sha256=MEASURE_SHA,
                           manifest_sha256=sha(a.manifest),build_sha256=sha(a.build))
        write(self.journal/'inputs.json',{**vars(a),'apk_sha256':build['apk']['sha256'],
             'snapshots':{str(f.relative_to(self.frozen)):sha(f) for f in self.frozen.rglob('*') if f.is_file()}})
        require(self.adb('require-own-avd','shell','getprop','ro.kernel.qemu').decode().strip()=='1','selected device is not observed QEMU AVD')
        require(self.adb('require-api','shell','getprop','ro.build.version.sdk').decode().strip()==str(a.api),'wrong API')
        require(self.adb('require-user-zero','shell','am','get-current-user').decode().strip()=='0','requires user 0')
        self.qa('begin-once','begin')
        _,self.bound,_=self.h.load_run(self.run)
        self.result['run_id']=self.bound['run_id']
        self.evidence=self.run/'native-evidence'/(str(time.time_ns())+'-main-journey-'+uuid.uuid4().hex[:8])
        self.evidence.mkdir(parents=True)
        require(self.adb('clear-authorized-synthetic-data','shell','pm','clear',PACKAGE).decode().strip()=='Success','pm clear did not succeed')
        self.qa('launch-fresh','setup','--action','launch','--reason','Explicit fresh final QA on owned synthetic AVD after one authorized data clear')

    def dismiss_ime(self,case):
        allowed=self.h.case_by_id(self.manifest,case).get('allowed_windows',[])
        deadline=time.monotonic()+15
        def remaining():
            left=deadline-time.monotonic()
            require(left>0,'IME observation exceeded its common deadline')
            return min(10,left)
        def visible():
            w=self.adb('ime-windows','shell','dumpsys','window','windows',timeout=remaining()).decode()
            d=self.adb('ime-displays','shell','dumpsys','window','displays',timeout=remaining()).decode()
            _,windows=self.h.parse_windows(w,d,PACKAGE,allowed)
            remaining()
            return ('com.google.android.inputmethod.latin','InputMethod') in windows
        if not visible():return  # Never send Back when the observed keyboard is already hidden.
        self.adb('dismiss-observed-ime','shell','input','keyevent','KEYCODE_BACK',timeout=remaining())
        while visible():time.sleep(min(0.2,remaining()))

    def execute(self):
        self.prepare();self.capture('fresh')
        self.tap('manual-form',T('Выбрать храм'),[T('Выберите храм')])
        self.tap('manual-form',T('Добавить свой храм'),[T('Название храма')])
        self.enter('manual-form','Название храма','Feoria_QA_05');self.capture('manual-form')
        self.enter('manual-form','Город или населенный пункт','Kazan');self.dismiss_ime('manual-form')
        self.tap('manual-temple',T('Сохранить и выбрать'),[T('Feoria_QA_05'),T('Добавлен вами')]);self.capture('manual-temple')
        self.tap('personal-form',T('Указать время'),[T('Время литургии'),T('Начало литургии')])
        epoch=int(self.adb('device-clock','shell','date','+%s').decode().strip())
        zone=self.adb('device-timezone','shell','getprop','persist.sys.timezone').decode().strip()
        require(zone=='Europe/Moscow','personal time uses observed Moscow zone')
        now=dt.datetime.fromtimestamp(epoch,zoneinfo.ZoneInfo(zone));start=(now-dt.timedelta(minutes=6)).replace(second=0,microsecond=0)
        require(start.date()==now.date(),'six-minute start crosses midnight; stop without guessing another date')
        value=start.strftime('%H:%M')
        write(self.journal/'personal-time-input.json',{'device_epoch_seconds':epoch,'device_local':now.isoformat(),
            'timezone':zone,'personal_date':start.date().isoformat(),'personal_time':value,'declared_start':start.isoformat(),
            'elapsed_at_selection_seconds':epoch-int(start.timestamp()),'method':'six minutes before observed device time; no clock injection'})
        self.enter('personal-form','Начало литургии',value);self.capture('personal-form');self.dismiss_ime('personal-form')
        self.tap('personal-service',T('Сохранить время'),[T('Мой храм'),T(value+' · Литургия')])
        self.tap('personal-service',T('Служба'),[T('Начало указано вами'),T('Смотреть службу')]);self.capture('personal-service')
        self.tap('scheduled-entry',T('Смотреть службу'),[T('Уточнить'),PLAY]);self.capture('scheduled-entry')
        self.tap('creed-original',D('Порядок службы'),[T('Порядок службы')])
        self.tap('creed-original',T('Символ веры'),[T('Символ веры'),T('Оригинал'),PLAY])
        self.tap('creed-original',T('Оригинал'),[TAB('Оригинал'),LYRIC('Возлюбим друг друга, да единомыслием исповемы')])
        self.tap('creed-original',T('Следующий текст: Символ веры'),[LYRIC(FIRST),PLAY])
        for number in (2,3,4):self.tap('creed-original',D('Следующая фраза'),[T(f'Фраза {number}/20'),PLAY])
        self.tap('creed-original',T('По-русски'),[TAB('По-русски'),LYRIC(FOURTH_RU),PLAY])
        self.tap('creed-original',T('Оригинал'),[TAB('Оригинал'),LYRIC(FOURTH),PLAY]);self.capture('creed-original')
        self.tap('creed-original',T('1×'),[T('Примерный темп'),T('Быстрее · 1,25×')])
        self.tap('creed-original',T('Быстрее · 1,25×'),[{'text':'Быстрее · 1,25×','ancestor':{'class':'android.view.View','checked':True}}])
        self.tap('creed-original',T('Готово'),[T('1,25×'),LYRIC(FOURTH),PLAY])
        self.call('real-player-measurement',[sys.executable,str(self.frozen/'player-measure.py'),
            '--repo',str(self.repo),'--run',str(self.run),'--build',self.a.build,'--manifest',self.a.manifest,
            '--adb',self.a.adb,'--serial',self.a.serial,'--api',str(self.a.api),'--case','creed-meaning',
            '--start-phrase','4','--speed-label','1,25×','--lifecycle','none'],timeout=90)
        self.tap('creed-meaning',T('Смысл'),[TAB('Смысл'),T('Что происходит')]);self.capture('creed-meaning')
        self.result.update(outcome='RECORDED',verdict='EIGHT_CAPTURES_AND_DYNAMIC_CHECKS_RECORDED_ROOT_REVIEW_REQUIRED')

    def finish(self,error=None):
        if error is not None:
            self.result.update(outcome='ERROR',verdict='FAIL',error=repr(error))
            (self.journal/'error.txt').write_text(''.join(traceback.format_exception(type(error),error,error.__traceback__)))
        self.result.update(finished_ns=time.time_ns(),finished_monotonic_ns=time.monotonic_ns())
        write(self.journal/'result.json',self.result)
        if self.evidence is not None:
            # copyfile gives fresh capture mtimes; bytes and original timestamps remain in the ledger.
            for f in self.journal.rglob('*'):
                if f.is_file():
                    target=self.evidence/f.relative_to(self.journal);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
            record={**self.result,'artifacts':[self.h.artifact(f,self.run) for f in sorted(self.evidence.rglob('*')) if f.is_file() and f.stat().st_size>0]}
            write(self.evidence/'record.json',record)
        print(json.dumps({'outcome':self.result['outcome'],'journal':str(self.journal),'run':str(self.run),
              'visual_review':'REQUIRED for all eight cases; no review/finish was called',
              'aggregate':'NOT_CREATED','release_verdict':'NOT_EVALUATED'},ensure_ascii=False,indent=2))

def main():
    a=args();journey=None
    try:
        journey=Journey(a);journey.execute()
    except BaseException as error:
        if journey is not None:journey.finish(error)
        else:print('JOURNEY PRECONDITION FAILED: '+repr(error),file=sys.stderr)
        return 1
    journey.finish();return 0

if __name__=='__main__':raise SystemExit(main())
