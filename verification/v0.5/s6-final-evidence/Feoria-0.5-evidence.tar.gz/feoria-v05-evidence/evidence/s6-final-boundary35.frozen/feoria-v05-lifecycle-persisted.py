#!/usr/bin/env python3
"""Bounded Home/Sleep oracle for an already installed signed Feoria 0.5 on own rooted AVD.

Requires uid=0, never changes root state. Reads preferences only; no install/clear,
setup injection, preference writes, seek or manual player pause. A=B=C proves exact
persisted position plus returned checked phrase, not access to hidden runtime state.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import hashlib
import re
import xml.etree.ElementTree as ET
from pathlib import Path
import sys
import time
import traceback
import uuid

sys.dont_write_bytecode = True
PACKAGE = "ru.liturgyguide"
SIGNER = "bb0ea3162b2129b7411ed3a15956c6f2065c685574c1caa24fb260e452ef5247"
PLAY = {"content-desc": "Включить плеер"}
STOP = {"content-desc": "Остановить плеер"}


def mode(label):
    return {"text": label, "ancestor": {"class": "android.view.View", "selected": True}}


def arguments():
    p = argparse.ArgumentParser(description="Read-only persisted lifecycle oracle on an already rooted own AVD")
    for name in ("repo", "run", "build", "manifest", "adb", "serial", "case"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--api", type=int, required=True)
    p.add_argument("--start-phrase", type=int, default=8)
    p.add_argument("--speed-label", choices=("0,75×", "1×", "1,25×"), default="1,25×")
    p.add_argument("--text-size", type=int, choices=(0, 1, 2), default=1)
    p.add_argument("--dark", choices=("true", "false"), default="true")
    p.add_argument("--home-package", default="com.google.android.apps.nexuslauncher")
    p.set_defaults(play_timeout=30, lifecycle="home-sleep")
    return p.parse_args()


def strict_json(text):
    def unique(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError("duplicate JSON key: " + key)
            out[key] = value
        return out
    return json.loads(text, object_pairs_hook=unique)


def content_id(*parts):
    # Kotlin String.length counts UTF-16 code units, not UTF-8 bytes.
    encoded = "".join(str(len(s.encode("utf-16-le")) // 2) + ":" + s for s in parts)
    return hashlib.sha256(encoded.encode()).hexdigest()[:24]


def exact_field(text, pattern):
    values = re.findall(pattern, text, flags=re.M)
    if len(values) != 1:
        raise ValueError("missing or ambiguous OS field: " + pattern)
    return values[0]


def os_fields(power, windows, activity, home_package):
    wake = exact_field(power, r"^[ \t]+mWakefulness=(Awake|Asleep|Dozing|Dreaming)[ \t]*$")
    changing = exact_field(power, r"^[ \t]+mWakefulnessChanging=(true|false)[ \t]*$")
    interactive = exact_field(power, r"^[ \t]+mHalInteractiveModeEnabled=(true|false)[ \t]*$")
    screen = exact_field(windows, r"^[ \t]+mAwake=(?:true|false) mScreenOnEarly=(true|false) mScreenOnFully=(true|false)[ \t]*$")
    focus = exact_field(windows, r"^[ \t]+mCurrentFocus=(.+)$")
    owner = None
    if focus != "null":
        identity = re.fullmatch(r"Window\{(\S+) u(\d+) (.+)\}", focus)
        if not identity:
            raise ValueError("unknown focused-window identity")
        found = []
        for block in re.split(r"(?=^  Window #\d+ Window\{)", windows, flags=re.M)[1:]:
            head = re.match(r"  Window #\d+ Window\{(\S+) u(\d+) (.+)\}:", block)
            if head and head.groups() == identity.groups():
                ownerline = exact_field(block, r"^[ \t]+mOwnerUid=[^\r\n]+$")
                m = re.fullmatch(r"[ \t]+mOwnerUid=\d+[ \t]+showForAllUsers=(?:true|false)[ \t]+package=([\w.]+)[ \t]+appop=\S+[ \t]*", ownerline)
                if not m:
                    raise ValueError("unknown focused-window owner")
                found.append(m[1])
        if len(found) != 1:
            raise ValueError("focused window has no unique owner")
        owner = found[0]
    # Activity dumps repeat Task headers in later window-container inventories.
    # Parse only the primary activities section, never those diagnostic copies.
    sections = activity.split("ACTIVITY MANAGER ACTIVITIES (dumpsys activity activities)\n")
    if len(sections) != 2 or "\nActivityTaskSupervisor state:" not in sections[1]:
        raise ValueError("unknown/ambiguous primary activity section")
    activity = sections[1].split("\nActivityTaskSupervisor state:", 1)[0]
    tasks = []
    # Bound each Task block before its next Task header, including nested headers.
    for block in re.split(r"(?=^[ \t]+\* Task\{)", activity, flags=re.M)[1:]:
        header = block.splitlines()[0]
        if re.search(r"\bA=\d+:" + re.escape(PACKAGE) + r"(?: |\})", header):
            visible = exact_field(header, r".*\bvisible=(true|false)\b.*")
            sleeping = exact_field(block, r"^[ \t]+isSleeping=(true|false)[ \t]*$")
            tasks.append({"visible": visible, "sleeping": sleeping})
    if len(tasks) != 1:
        raise ValueError("expected one Feoria task in activity inventory")
    # These anchored activity-manager records must name the app, not arbitrary text.
    pending = [line for line in activity.splitlines() if re.match(
        r"^[ \t]+(?:topPausingActivity|mPausingActivity|topResumedActivity|mResumedActivity|ResumedActivity)[:=]", line)
        and re.search(r"\b" + re.escape(PACKAGE) + r"/", line)]
    resumed = [line for line in activity.splitlines() if re.match(r"^[ \t]+Resumed:", line)
               and re.search(r"\b" + re.escape(PACKAGE) + r"/", line)]
    common = changing == "false" and not pending and not resumed
    return {"wakefulness": wake, "changing": changing, "hal_interactive": interactive,
            "screen_on_early": screen[0], "screen_on_fully": screen[1], "focus_owner": owner,
            "app_task": tasks[0], "pending_or_resumed_app": pending + resumed,
            "home_ready": common and wake == "Awake" and interactive == "true"
                          and owner == home_package and tasks[0]["visible"] == "false",
            "sleep_ready": common and wake in ("Asleep", "Dozing") and interactive == "false"
                           and screen == ("false", "false") and tasks[0]["sleeping"] == "true"}


class Measurement:
    def __init__(self, args):
        self.a = args
        self.repo, self.run = Path(args.repo).resolve(), Path(args.run).resolve()
        source = self.repo / "scripts/harness/feoria_harness.py"
        spec = importlib.util.spec_from_file_location("feoria_measure_harness", source)
        if spec is None or spec.loader is None:
            raise ValueError("repository harness cannot be loaded")
        self.h = h = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(h)
        h.require(0 < args.play_timeout <= 30 and args.api >= 26, "invalid bounded timeout/API")
        _, self.record, self.manifest = h.load_run(self.run)
        h.require(h.canonical(h.read_json(args.manifest)) == h.canonical(self.manifest),
                  "external manifest differs from fixed run")
        h.require(h.sha(args.build) == self.record["build_sha256"], "build receipt differs from fixed run")
        build = h.read_json(args.build)
        h.validate_build(build, Path(args.build).with_name("build.log"), build["apk"]["path"])
        apk = build["apk"]
        h.require(build["build_type"] == "release" and self.manifest["build_type"] == "release" and
                  self.manifest["package"] == PACKAGE and apk["package"] == PACKAGE and
                  apk.get("debuggable") is False and apk.get("certificate_sha256") == SIGNER and
                  str(apk["version_code"]) == "5" and apk["version_name"] == "0.5.0-guide",
                  "requires the same signed non-debuggable Feoria 0.5 release")
        h.require(self.record["serial"] == args.serial, "explicit serial differs from run")
        self.case = h.case_by_id(self.manifest, args.case)
        h.require(self.case.get("window_package", PACKAGE) == PACKAGE, "case must observe app window")
        h.require(self.case.get("observed_requirements", {}).get("sdk") == str(args.api),
                  "case must explicitly require requested API")
        self.allowed = self.case.get("allowed_windows", [])
        asset = self.repo / "app/src/main/assets/liturgy_stages.json"
        entries = [row for row in build["inputs_after"]["files"] if row["path"] == "app/src/main/assets/liturgy_stages.json"]
        h.require(len(entries) == 1 and h.sha(asset) == entries[0]["sha256"], "Creed asset differs from built input")
        creed = [s for s in h.read_json(asset)["stages"] if s["id"] == "creed"]
        h.require(len(creed) == 1, "Creed stage is ambiguous")
        tracks = [t for t in creed[0]["texts"] if t.get("title") == "Символ веры"]
        h.require(len(tracks) == 1, "full Creed track is ambiguous")
        self.lines = [row["original"].strip() for row in tracks[0]["lines"]]
        self.track_id = "creed:prayer:" + content_id(tracks[0]["type"], "\n".join(self.lines))
        self.line_ids = [self.track_id + ":" + content_id(line) for line in self.lines]
        # Bind the schema/atomic-writer/ID assumptions to the actual release inputs.
        for relative in ("app/src/main/java/ru/liturgyguide/service/ServicePlaybackStore.kt",
                         "app/src/main/java/ru/liturgyguide/service/ReadingAcceptanceStore.kt",
                         "app/src/main/java/ru/liturgyguide/service/PrayerTrackFactory.kt",
                         "app/src/main/java/ru/liturgyguide/service/ServicePlaybackPlan.kt",
                         "app/src/main/java/ru/liturgyguide/ui/MainActivity.kt"):
            records = [row for row in build["inputs_after"]["files"] if row["path"] == relative]
            h.require(len(records) == 1 and h.sha(self.repo / relative) == records[0]["sha256"],
                      "source assumption differs from release: " + relative)
        self.segment_base = None
        self.preferences_path = "/data/user/0/" + PACKAGE + "/shared_prefs/guide_preferences.xml"
        self.initial_preserved = None
        self.process_id = None
        h.require(len(self.lines) == len(set(self.lines)) == 20, "requires the observed unique twenty-phrase Creed")
        h.require(2 <= args.start_phrase <= 10, "start with phrase 2..10, leaving room for real movement")
        self.directory = self.run / "native-evidence" / (str(time.time_ns()) + "-player-measure-" + uuid.uuid4().hex[:8])
        self.directory.mkdir(parents=True, exist_ok=False)
        self.phase, self.deadline, self.sequence = "initialization", None, 0
        self.result = {
            "kind": "persisted-lifecycle-measurement", "run_id": self.record["run_id"], "serial": args.serial,
            "sdk": str(args.api), "apk_sha256": apk["sha256"], "harness_sha256": h.sha(source),
            "measurement_sha256": h.sha(__file__), "started_ns": time.time_ns(),
            "started_monotonic_ns": time.monotonic_ns(), "outcome": "STARTED",
            "verdict": "NOT_REVIEWED", "scope": "Home/Sleep persisted position A=B=C and paused returned UI",
            "lifecycle_requested": args.lifecycle, "release_verdict": "NOT_EVALUATED",
            "limits": ["Reads persisted position, not hidden runtime anchor/state",
                       "Samples stable OS state; no continuous OS telemetry",
                       "No Recents, rotation, cold restart, secure keyguard or visual acceptance"],
            "observations": [], "actions": [], "checks": {},
        }
        h.write_json(self.directory / "started.json", self.result)
        self.append("measurement_started", {"arguments": vars(args)})
        owner = self

        class RecordedAdb(h.Adb):
            def run(self, *argv, timeout=30):
                owner.sequence += 1
                event = owner.directory / "commands" / f"{owner.sequence:05d}"
                event.mkdir(parents=True)
                effective = min(timeout, 30.0)
                if owner.deadline is not None:
                    effective = min(effective, h.remaining(owner.deadline))
                record = {"argv": [str(v) for v in argv], "phase": owner.phase,
                          "started_monotonic_ns": time.monotonic_ns(), "timeout_seconds": effective,
                          "apk_expected_sha256": owner.record["apk"]["sha256"], "outcome": "STARTED"}
                h.write_json(event / "started.json", record)
                try:
                    data = super().run(*argv, timeout=effective)
                    record.update(outcome="RECORDED", bytes=len(data), stdout_sha256=h.digest(data))
                    # Every installed APK read is hashed, without duplicating the same large binary.
                    apk_read = len(argv) == 3 and argv[:2] == ("exec-out", "cat") and str(argv[2]).endswith("/base.apk")
                    if apk_read:
                        record["installed_apk_sha256"] = h.digest(data)
                    else:
                        (event / "stdout.bin").write_bytes(data)
                    if owner.deadline is not None:
                        h.remaining(owner.deadline, reason="phase exceeded its monotonic deadline")
                    return data
                except BaseException as exc:
                    record.update(outcome="ERROR", error=repr(exc))
                    raise
                finally:
                    record["finished_monotonic_ns"] = time.monotonic_ns()
                    h.write_json(event / "record.json", record)
                    owner.append("command", {**record, "directory": str(event.relative_to(owner.directory))})

        self.adb = RecordedAdb(Path(args.adb).resolve(), args.serial)

    def append(self, kind, value):
        with (self.directory / "events.jsonl").open("a") as out:
            out.write(json.dumps({"kind": kind, "host_monotonic_ns": time.monotonic_ns(), **value}, ensure_ascii=False) + "\n")

    def bounded_phase(self, name, seconds=30):
        self.phase, self.deadline = name, time.monotonic() + seconds
        self.append("phase", {"name": name, "budget_seconds": seconds})

    def identity(self, label):
        h = self.h
        h.require(re.fullmatch(r"emulator-[0-9]+", self.a.serial), "requires an explicit local emulator serial")
        h.require(self.adb.shell("getprop", "ro.kernel.qemu") == "1", "requires an observed AVD before lifecycle actions")
        h.require(self.adb.shell("id", "-u") == "0", "requires already-rooted own AVD; helper never invokes adb root")
        h.require(self.adb.shell("am", "get-current-user") == "0", "requires observed Android user 0")
        facts = self.adb.facts(PACKAGE)
        h.write_json(self.directory / (label + "-facts.json"), facts)
        for key in h.REQUIRED_FACTS:
            h.require(h.known(facts.get(key)), "required fact is unknown: " + key)
        h.require(facts["sdk"] == str(self.a.api) and facts["fingerprint"] == self.record["initial_facts"]["fingerprint"],
                  "device identity changed")
        h.require(facts["version_code"] == "5" and facts["version_name"] == "0.5.0-guide", "version changed")
        for key, value in self.case.get("observed_requirements", {}).items():
            h.require(facts.get(key) == value, "case condition changed: " + key)
        actual = h.verify_installed(self.adb, PACKAGE, self.record["apk"]["sha256"])
        pid = self.adb.shell("pidof", PACKAGE)
        h.require(re.fullmatch(r"[1-9][0-9]*", pid), "app process missing/ambiguous")
        if self.process_id is None:
            self.process_id = pid
        h.require(pid == self.process_id, "process changed: this is a same-process lifecycle oracle")
        self.append("identity", {"label": label, "apk_sha256": actual, "pid": pid, "uid": 0})

    def observe(self, label):
        h = self.h
        folder = self.directory / "observations" / f"{len(self.result['observations']):03d}-{label}"
        folder.mkdir(parents=True)
        started = time.monotonic_ns()
        view = self.adb.view(PACKAGE, self.allowed, timeout=h.remaining(self.deadline))
        for name, data in (("view.xml", view.xml), ("windows.txt", view.windows.encode()), ("displays.txt", view.displays.encode())):
            (folder / name).write_bytes(data)
        obs = {"label": label, "started_monotonic_ns": started,
               "finished_monotonic_ns": time.monotonic_ns(), "directory": str(folder.relative_to(self.directory))}
        self.result["observations"].append(obs)
        view.expect([{"text": "Символ веры"}, mode("Оригинал"), {"text": self.a.speed_label}, PLAY])
        view.target(PLAY)
        h.require(not view.matching(STOP), "returned player is playing")
        nodes = [n for n in view.nodes if n.get("text") in self.lines and n.get("checked") == "true"]
        h.require(len(nodes) == 1, "expected one checked full-Creed phrase")
        node = nodes[0]
        h.bounds(node, view.size)
        h.require(all(node.get(key) == "true" for key in ("checkable", "enabled", "clickable")), "checked phrase control invalid")
        obs.update(phrase=self.lines.index(node.get("text")) + 1, original=node.get("text"), paused=True,
                   mode="Оригинал", speed=self.a.speed_label)
        h.write_json(folder / "observation.json", obs)
        self.append("ui_observation", obs)
        return obs

    def preferences(self, label):
        h = self.h
        folder = self.directory / "preferences"
        folder.mkdir(exist_ok=True)
        started = time.monotonic_ns()
        raw = self.adb.run("exec-out", "cat", self.preferences_path)
        stamp = str(started) + "-" + label
        (folder / (stamp + ".xml")).write_bytes(raw)
        root = ET.fromstring(raw)
        h.require(root.tag == "map", "unknown SharedPreferences format")
        prefs = {}
        for node in root:
            key = node.get("name")
            h.require(key and key not in prefs, "duplicate/unnamed preference")
            if node.tag == "string": value = node.text or ""
            elif node.tag in ("int", "long"):
                h.require(re.fullmatch(r"-?(0|[1-9][0-9]*)", node.get("value", "")), "invalid integer preference")
                value = int(node.get("value"))
            elif node.tag == "boolean":
                h.require(node.get("value") in ("true", "false"), "invalid boolean preference")
                value = node.get("value") == "true"
            else: raise ValueError("unexpected preference type: " + node.tag)
            prefs[key] = value
        snapshot = strict_json(prefs["service_playback_v1"])
        h.require(set(snapshot) == {"version", "context", "contentVersion", "planFingerprint", "segmentIndex", "elapsedQuarterMillis", "speed"},
                  "unexpected playback snapshot schema")
        h.require(all(type(snapshot[key]) is int and snapshot[key] == 1 for key in ("version", "contentVersion")),
                  "unsupported or non-integer snapshot version")
        for key in ("segmentIndex", "elapsedQuarterMillis"):
            h.require(type(snapshot[key]) is int and snapshot[key] >= 0, "invalid snapshot integer: " + key)
        h.require(re.fullmatch(r"[0-9a-f]{64}", snapshot["planFingerprint"]), "invalid plan fingerprint")
        speed = {"0,75×": "SLOW", "1×": "NORMAL", "1,25×": "FAST"}[self.a.speed_label]
        h.require(snapshot["speed"] == speed, "persisted speed changed")
        context = strict_json(snapshot["context"])
        h.require(context == strict_json(prefs["reading_context_v1"]), "snapshot/context mismatch")
        h.require(prefs["stage_id"] == "creed" and prefs["lyric_track_creed"] == self.track_id, "wrong stored track/stage")
        index = prefs["lyric_line_" + self.track_id]
        h.require(type(index) is int and 0 <= index < 19, "must remain inside full Creed before its final phrase")
        h.require(prefs["lyric_phrase_" + self.track_id] == self.line_ids[index], "atomic ID/index bookmark mismatch")
        if self.segment_base is not None:
            h.require(snapshot["segmentIndex"] == self.segment_base + index, "snapshot segment/bookmark mismatch")
        words = [w for w in re.split(r"\s+", self.lines[index]) if any(c.isalnum() for c in w)]
        h.require(snapshot["elapsedQuarterMillis"] < max(4000, len(words) * 500) * 4, "offset exceeds observed Creed phrase duration")
        preserved = {key: prefs.get(key) for key in ("church_id", "saved_churches_v1", "user_service_starts_v1", "reading_context_v1", "lyric_original", "dark", "text_size")}
        h.require(preserved["lyric_original"] is True and preserved["dark"] == (self.a.dark == "true")
                  and type(preserved["text_size"]) is int and preserved["text_size"] == self.a.text_size,
                  "language/theme/size differs from explicit initial state")
        if self.initial_preserved is None:
            self.initial_preserved = preserved
        h.require(preserved == self.initial_preserved, "church/context/settings changed")
        session = strict_json(prefs["session"])
        h.require(session["anchorStageId"] == "creed" and session["autoAdvance"] is False
                  and session["elapsedInStageMillis"] == 0, "invalid compatibility session")
        value = {"label": label, "snapshot": snapshot, "phrase": index + 1,
                 "line_id": self.line_ids[index], "track_id": self.track_id,
                 "preserved": preserved, "session": session,
                 "started_monotonic_ns": started, "finished_monotonic_ns": time.monotonic_ns(),
                 "raw_path": str((folder / (stamp + ".xml")).relative_to(self.directory))}
        h.write_json(folder / (stamp + ".json"), value)
        self.append("persisted_snapshot", value)
        return value

    def same_position(self, first, second):
        # Context, fingerprint, speed AND exact quarter-millisecond offset are included.
        self.h.require(first["snapshot"] == second["snapshot"] and first["line_id"] == second["line_id"]
                       and first["phrase"] == second["phrase"] and first["preserved"] == second["preserved"],
                       "persisted position/context/settings changed")

    def os_observation(self, kind):
        # Raw command outputs are journaled before parsing; no APK reads in polling.
        power = self.adb.shell("dumpsys", "power")
        windows = self.adb.shell("dumpsys", "window")
        activity = self.adb.shell("dumpsys", "activity", "activities")
        state = os_fields(power, windows, activity, self.a.home_package)
        state.update(kind=kind, observed_monotonic_ns=time.monotonic_ns())
        self.append("os_state", state)
        return state

    def stable_background(self, kind):
        first = None
        while True:
            state = self.os_observation(kind)
            if state[kind + "_ready"]:
                if first is not None and state["observed_monotonic_ns"] - first >= 500_000_000:
                    return state
                if first is None: first = state["observed_monotonic_ns"]
            else: first = None
            time.sleep(min(0.25, self.h.remaining(self.deadline)))

    def tap(self, selector, expected):
        started = time.monotonic_ns()
        result = self.h.tap(self.run, self.adb, self.a.case, selector, expected,
                            timeout=min(30, self.h.remaining(self.deadline)))
        action = {"selector": selector, "started_monotonic_ns": started,
                  "finished_monotonic_ns": time.monotonic_ns(), "result": result}
        self.result["actions"].append(action)
        self.append("harness_tap", action)

    def lifecycle(self, kind):
        h = self.h
        self.bounded_phase(kind + "-real-play-and-departure", 45)
        before_ui = self.observe(kind + "-before")
        before = self.preferences(kind + "-before")
        h.require(before_ui["phrase"] == before["phrase"], "initial UI differs from stored bookmark")
        self.tap(PLAY, [STOP, mode("Оригинал")])
        self.adb.shell("input", "keyevent", "KEYCODE_HOME" if kind == "home" else "KEYCODE_SLEEP")
        self.bounded_phase(kind + "-await-stable-background", 45)
        stable = self.stable_background(kind)
        a = self.preferences(kind + "-A-post-pause")
        h.require((a["snapshot"]["segmentIndex"], a["snapshot"]["elapsedQuarterMillis"]) >
                  (before["snapshot"]["segmentIndex"], before["snapshot"]["elapsedQuarterMillis"]),
                  "snapshot did not capture any actual foreground playback")
        self.bounded_phase(kind + "-background-interval", 30)
        samples = 0
        while True:
            state = self.os_observation(kind)
            h.require(state[kind + "_ready"], "stable background condition was lost")
            current = self.preferences(kind + "-background-sample")
            self.same_position(a, current)
            samples += 1
            if current["started_monotonic_ns"] - a["finished_monotonic_ns"] >= 8_000_000_000:
                b = current
                break
            time.sleep(min(0.25, h.remaining(self.deadline)))
        self.bounded_phase(kind + "-return", 45)
        if kind == "sleep": self.adb.shell("input", "keyevent", "KEYCODE_WAKEUP")
        self.adb.shell("am", "start", "-W", "-n", PACKAGE + "/.ui.MainActivity")
        returned = self.observe(kind + "-returned")
        h.require(returned["phrase"] == a["phrase"] == b["phrase"], "returned UI differs from A/B bookmark")
        c = self.preferences(kind + "-C-returned")
        self.same_position(a, b); self.same_position(a, c)
        h.require(self.adb.shell("pidof", PACKAGE) == self.process_id, "app process restarted during lifecycle route")
        return {"before_phrase": before["phrase"], "returned_phrase": returned["phrase"],
                "A": a, "B": b, "C": c, "observed_background_span_seconds":
                (b["started_monotonic_ns"] - a["finished_monotonic_ns"]) / 1e9,
                "background_samples": samples, "stable_os_state": stable,
                "persisted_position_equal": True, "returned_ui_paused": True,
                "hidden_runtime_state_verdict": "NOT_READ",
                "return_method": "am start; not Recents", "secure_keyguard_verdict": "NOT_EVALUATED"}

    def execute(self):
        self.bounded_phase("initial-identity-and-paused-position", 45)
        self.identity("initial")
        ui = self.observe("initial")
        initial = self.preferences("initial")
        self.h.require(ui["phrase"] == initial["phrase"] == self.a.start_phrase, "wrong declared initial phrase")
        # Creed lines are consecutive Text segments, verified against bound plan source.
        self.segment_base = initial["snapshot"]["segmentIndex"] - (initial["phrase"] - 1)
        self.h.require(self.segment_base >= 0, "invalid established Creed segment base")
        self.result["segment_mapping"] = {"track": self.track_id, "first_segment": self.segment_base,
                                          "basis": "initial exact UI+atomic bookmark; consecutive Creed Text segments"}
        for kind in ("home", "sleep"):
            self.result["checks"][kind] = self.lifecycle(kind)
        self.bounded_phase("final-identity", 45)
        self.identity("final")
        self.result.update(outcome="RECORDED", verdict="PERSISTED_POSITION_AND_PAUSED_RETURN_CHECKS_PASSED_ROOT_REVIEW_REQUIRED")

    def finish(self, error=None):
        self.deadline = None
        if error is not None:
            self.result.update(outcome="ERROR", verdict="FAIL", error=repr(error))
            (self.directory / "error.txt").write_text("".join(traceback.format_exception(type(error), error, error.__traceback__)))
        self.result.update(finished_ns=time.time_ns(), finished_monotonic_ns=time.monotonic_ns())
        self.append("measurement_finished", {"outcome": self.result["outcome"], "verdict": self.result["verdict"]})
        self.result["artifacts"] = [self.h.artifact(p, self.run) for p in sorted(self.directory.rglob("*"))
                                    if p.is_file() and p.stat().st_size > 0 and p.name != "record.json"]
        # Command record.json files also belong to evidence; exclude only this final record.
        self.result["artifacts"] += [self.h.artifact(p, self.run) for p in sorted((self.directory / "commands").glob("*/record.json"))]
        self.h.write_json(self.directory / "record.json", self.result)
        with (self.run / "raw-setup-observations.jsonl").open("a") as out:
            out.write(json.dumps({"directory": str(self.directory.relative_to(self.run)),
                                  "run_id": self.record["run_id"], "kind": "persisted-lifecycle-measurement",
                                  "outcome": self.result["outcome"], "verdict": self.result["verdict"]}, ensure_ascii=False) + "\n")
        print(json.dumps({"evidence": str(self.directory), "outcome": self.result["outcome"],
                          "verdict": self.result["verdict"], "checks": self.result["checks"],
                          "release_verdict": "NOT_EVALUATED"}, ensure_ascii=False, indent=2))


def main():
    args = arguments()
    measure = None
    try:
        measure = Measurement(args)
        measure.execute()
    except BaseException as error:
        if measure is not None:
            measure.finish(error)
        else:
            print("MEASUREMENT PRECONDITION FAILED: " + repr(error), file=sys.stderr)
        return 1
    measure.finish()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
