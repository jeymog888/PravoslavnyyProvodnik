#!/usr/bin/env python3
"""Explicit one-step release QA driver. Raw evidence is never a scenario PASS."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import time
import uuid

sys.dont_write_bytecode = True
PACKAGE = "ru.liturgyguide"
EDIT = "android.widget.EditText"
SETUP = {
    "launch": ("shell", "am", "start", "-W", "-n", PACKAGE + "/.ui.MainActivity"),
    "force-stop": ("shell", "am", "force-stop", PACKAGE),
    "home": ("shell", "input", "keyevent", "KEYCODE_HOME"),
    "recents": ("shell", "input", "keyevent", "KEYCODE_APP_SWITCH"),
    "sleep": ("shell", "input", "keyevent", "KEYCODE_SLEEP"),
    "wake": ("shell", "input", "keyevent", "KEYCODE_WAKEUP"),
}


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ("repo", "adb", "serial", "run", "build", "manifest"):
        p.add_argument("--" + key, required=True)
    p.add_argument("--api", required=True, type=int)
    p.add_argument("--timeout", type=float, default=30)
    s = p.add_subparsers(dest="command", required=True)
    s.add_parser("begin", help="Verify release identity and call begin_run (install -r exactly once)")
    for name in ("show", "tap", "type", "scroll", "capture"):
        c = s.add_parser(name)
        c.add_argument("--case", required=True)
        if name in ("tap", "type"):
            c.add_argument("--selector", required=True, help="JSON selector from a fresh dump")
        if name in ("tap", "scroll"):
            c.add_argument("--expect", required=True, help="Nonempty JSON postcondition array")
        if name == "type":
            c.add_argument("--text", required=True, help="ASCII QA text; empty field only")
        if name == "scroll":
            c.add_argument("--direction", choices=("up", "down"), required=True)
    c = s.add_parser("raw-snapshot", help="Unparsed system XML/windows/displays; no window allowance")
    c.add_argument("--label", required=True)
    c.add_argument("--png", action="store_true")
    s.add_parser("facts", help="Read-only package, network, power and IME observations")
    c = s.add_parser("setup", help="One explicit system action, recorded without a PASS verdict")
    c.add_argument("--action", required=True, choices=tuple(SETUP))
    c.add_argument("--reason", required=True)
    c = s.add_parser("review")
    c.add_argument("--case", required=True)
    c.add_argument("--decision", choices=("ACCEPT", "REJECT"), required=True)
    c.add_argument("--observations", required=True)
    s.add_parser("finish", help="Aggregate only the static manifest; raw evidence needs root review")
    return p


def json_arg(text):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate JSON selector key: " + key)
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs)


class Driver:
    def __init__(self, args):
        self.a = args
        source = Path(args.repo).resolve() / "scripts/harness/feoria_harness.py"
        spec = importlib.util.spec_from_file_location("feoria_harness", source)
        if spec is None or spec.loader is None:
            raise ValueError("cannot load repository harness")
        self.h = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.h)
        h = self.h
        h.require(0 < args.timeout <= 60, "timeout must be in (0, 60]")
        h.require(args.api >= 26, "explicit API >= 26 required")
        self.run = Path(args.run).resolve()
        self.adb = h.Adb(Path(args.adb).resolve(), args.serial)
        self.manifest = h.validate_manifest(h.read_json(args.manifest))
        self.build = h.read_json(args.build)
        h.require(self.manifest["package"] == PACKAGE and self.manifest["build_type"] == "release",
                  "driver requires a Feoria release manifest")
        h.require(self.build["build_type"] == "release" and self.build["apk"]["package"] == PACKAGE,
                  "driver requires a Feoria release build receipt")
        h.require(self.build["apk"].get("debuggable") is False, "release receipt must be non-debuggable")
        h.require(self.build["apk"].get("certificate_sha256") ==
                  "bb0ea3162b2129b7411ed3a15956c6f2065c685574c1caa24fb260e452ef5247",
                  "release signer differs from published 0.4")
        h.require(str(self.build["apk"]["version_code"]) == "5" and
                  self.build["apk"]["version_name"] == "0.5.0-guide", "not the final 0.5 release version")
        for case in self.manifest["cases"]:
            h.require(case.get("observed_requirements", {}).get("sdk") == str(args.api),
                      "each case must explicitly require this --api SDK")
            h.require(case["human_review_required"], "root visual review is required for every static case")
        sdk = self.adb.shell("getprop", "ro.build.version.sdk", timeout=args.timeout)
        h.require(sdk == str(args.api), "selected serial does not match explicit --api")
        if args.command != "begin":
            _, self.record, saved = h.load_run(self.run, self.adb)
            h.require(h.canonical(saved) == h.canonical(self.manifest), "external manifest differs from fixed run")
            h.require(h.sha(args.build) == self.record["build_sha256"], "external build differs from fixed run")
            binding = h.read_json(self.run / "driver.json")
            h.require(binding["driver_sha256"] == h.sha(__file__), "driver changed after begin")
            h.require(binding["run_id"] == self.record["run_id"] and binding["api"] == args.api and
                      binding["serial"] == args.serial, "driver/run/device binding mismatch")
            actual = self.adb.shell("getprop", "ro.build.fingerprint", timeout=args.timeout)
            h.require(actual == self.record["initial_facts"]["fingerprint"], "device fingerprint changed")

    def begin(self):
        h = self.h
        self.record = h.begin_run(self.a.manifest, self.a.build, self.run, self.adb)
        h.require(self.record["initial_facts"]["sdk"] == str(self.a.api), "SDK changed during begin")
        h.write_json(self.run / "driver.json", {
            "run_id": self.record["run_id"], "serial": self.a.serial, "api": self.a.api,
            "driver_sha256": h.sha(__file__), "apk_sha256": self.record["apk"]["sha256"],
            "limits": "One device and one release APK; raw setup/native observations are not scenario PASS",
        })
        return {"run_id": self.record["run_id"], "installed_sha256": self.record["installed_sha256"],
                "note": "begin_run installed with -r; data retained; app not launched"}

    def case(self):
        case = self.h.case_by_id(self.manifest, self.a.case)
        return case, case.get("window_package", PACKAGE), case.get("allowed_windows", [])

    def view(self):
        _, package, allowed = self.case()
        return self.adb.view(package, allowed, timeout=self.a.timeout)

    def save_view(self, directory, prefix, view):
        for name, data in (("xml", view.xml), ("windows.txt", view.windows.encode()),
                           ("displays.txt", view.displays.encode())):
            (directory / (prefix + "." + name)).write_bytes(data)

    def event(self, kind, operation, details=None):
        """Fail-closed supplemental ledger. Does not counterfeit a harness action/case."""
        h = self.h
        directory = self.run / "native-evidence" / (str(time.time_ns()) + "-" + uuid.uuid4().hex[:8])
        directory.mkdir(parents=True, exist_ok=False)
        record = {"kind": kind, "run_id": self.record["run_id"], "serial": self.a.serial,
                  "sdk": str(self.a.api), "apk_sha256": self.record["apk"]["sha256"],
                  "started_ns": time.time_ns(), "started_monotonic_ns": time.monotonic_ns(),
                  "details": details or {}, "outcome": "STARTED", "verdict": "NOT_REVIEWED"}
        h.write_json(directory / "started.json", record)
        self.journal(directory, record)
        error = None
        try:
            value = operation(directory)
            record.update(outcome="RECORDED", result=value)
        except Exception as exc:
            record.update(outcome="ERROR", error=str(exc))
            error = exc
        record.update(finished_ns=time.time_ns(), finished_monotonic_ns=time.monotonic_ns())
        record["artifacts"] = [h.artifact(p, self.run) for p in sorted(directory.iterdir()) if p.is_file()]
        h.write_json(directory / "record.json", record)
        self.journal(directory, record)
        if error:
            raise error
        return {"evidence": str(directory), "result": record["result"], "verdict": "NOT_REVIEWED"}

    def journal(self, directory, record):
        # Separate from actions/cases: executing setup is never accepted as scenario success.
        with (self.run / "raw-setup-observations.jsonl").open("a") as output:
            output.write(json.dumps({**record, "directory": str(directory.relative_to(self.run))},
                                    ensure_ascii=False) + "\n")

    def show(self, directory):
        view = self.view()
        self.save_view(directory, "fresh", view)
        print(view.xml.decode("utf-8"), flush=True)
        return {"window_package": view.package, "pixels": list(view.size),
                "note": "Fresh guarded observation, not a static case or movement oracle"}

    def raw_snapshot(self, directory):
        h = self.h
        deadline = time.monotonic() + self.a.timeout
        remote = "/data/local/tmp/feoria-release-" + uuid.uuid4().hex + ".xml"
        try:
            for suffix, command in (("windows.txt", ("shell", "dumpsys", "window", "windows")),
                                    ("displays.txt", ("shell", "dumpsys", "window", "displays"))):
                (directory / suffix).write_bytes(self.adb.run(*command, timeout=h.remaining(deadline)))
            self.adb.shell("uiautomator", "dump", remote, timeout=h.remaining(deadline))
            xml = self.adb.run("exec-out", "cat", remote, timeout=h.remaining(deadline))
            (directory / "raw.xml").write_bytes(xml)
            print(xml.decode("utf-8"), flush=True)
            if self.a.png:
                (directory / "screen.png").write_bytes(self.adb.run("exec-out", "screencap", "-p", timeout=h.remaining(deadline)))
            h.remaining(deadline)
        finally:
            if deadline > time.monotonic():
                try:
                    self.adb.shell("rm", "-f", remote, timeout=min(2, deadline - time.monotonic()))
                except h.GateError:
                    pass
        return {"label": self.a.label, "note": "Unparsed system evidence; no foreground, stability or oracle verdict"}

    def field(self, view, selector):
        """A label may be inside EditText. Resolve one enabled editable ancestor in this fresh View."""
        h = self.h
        view.target(selector)  # Same unique/enabled clickable ancestry guard used by tap.
        fields = set()
        for node in view.matching(selector):
            current = node
            while current is not None and current.tag == "node":
                if current.get("class") == EDIT:
                    fields.add(current)
                    break
                current = view.parents.get(current)
        h.require(len(fields) == 1, "selector must identify one EditText or its child label")
        field = next(iter(fields))
        h.bounds(field, view.size)
        h.require(field.get("enabled") == "true", "field disabled")
        x, y = view.target(selector)
        left, top, right, bottom = h.bounds(field, view.size)
        h.require(left <= x < right and top <= y < bottom, "clickable target is outside selected field")
        return field

    def type_text(self, directory):
        h, a = self.h, self.a
        h.require(re.fullmatch(r"[A-Za-z0-9_.: -]{1,120}", a.text) is not None,
                  "only 1-120 safe ASCII QA characters are supported")
        selector = json_arg(a.selector)
        before = self.view()
        field = self.field(before, selector)
        h.require(field.get("text", "") == "", "type supports empty fields only; no implicit replacement")
        self.save_view(directory, "before", before)
        # The only tap path is the harness: no raw coordinates or UI focus shortcuts.
        h.tap(self.run, self.adb, a.case, selector, [selector], timeout=a.timeout)
        focused = self.view()
        target = self.field(focused, selector)
        fields = [n for n in focused.nodes if n.get("class") == EDIT]
        h.require(target.get("focused") == "true" and target.get("text", "") == "", "selected empty field is not focused")
        h.require([n for n in fields if n.get("focused") == "true"] == [target], "ambiguous focused field")
        index, count = fields.index(target), len(fields)
        self.save_view(directory, "focused", focused)
        output = self.adb.run("shell", "input", "text", a.text.replace(" ", "%s"), timeout=a.timeout)
        h.write_json(directory / "input-output.json", {"stdout": output.decode(errors="replace"), "bytes": len(output)})
        after = self.view()
        self.save_view(directory, "after", after)
        current = [n for n in after.nodes if n.get("class") == EDIT]
        h.require(len(current) == count, "field hierarchy changed after text input")
        h.require([n for n in current if n.get("focused") == "true"] == [current[index]],
                  "focused field became ambiguous after input")
        h.require(current[index].get("focused") == "true" and current[index].get("text") == a.text,
                  "typed text did not reach the same focused field exactly")
        h.bounds(current[index], after.size)
        return {"text": a.text, "field_index": index, "note": "Exact input observed; no form submit performed"}

    def scroll(self, directory):
        h, a = self.h, self.a
        expected = json_arg(a.expect)
        h.validate_expected(expected)
        before = self.view()
        regions = [n for n in before.nodes if n.get("scrollable") == "true" and
                   n.get("enabled") == "true" and before._visible(n)]
        h.require(len(regions) == 1, "scroll requires exactly one visible enabled scrollable region")
        left, top, right, bottom = h.bounds(regions[0], before.size)
        x, y1, y2 = (left + right) // 2, top + (bottom - top) * 4 // 5, top + (bottom - top) // 4
        if a.direction == "up":
            y1, y2 = y2, y1
        self.save_view(directory, "before", before)
        output = self.adb.run("shell", "input", "swipe", str(x), str(y1), str(x), str(y2), "400", timeout=a.timeout)
        h.write_json(directory / "swipe-output.json", {"stdout": output.decode(errors="replace"), "bytes": len(output)})
        _, package, allowed = self.case()
        after = h.wait_for(self.adb, package, expected, allowed, timeout=a.timeout)
        self.save_view(directory, "after", after)
        return {"direction": a.direction, "observed_bounds": [left, top, right, bottom],
                "derived_swipe": [x, y1, x, y2], "expected": expected,
                "note": "One swipe only; inspect a fresh show before another"}

    def facts(self, directory):
        self.h.write_json(directory / "facts.json", self.adb.facts(PACKAGE))
        for name, argv in (("package", ("dumpsys", "package", PACKAGE)),
                           ("connectivity", ("dumpsys", "connectivity")),
                           ("power", ("dumpsys", "power")),
                           ("input_method", ("dumpsys", "input_method"))):
            (directory / (name + ".txt")).write_bytes(self.adb.run("shell", *argv, timeout=self.a.timeout))
        return {"note": "Raw facts only; wifi setting alone does not prove offline, package warning is not an app crash"}

    def setup(self, directory):
        self.h.require(self.a.reason.strip(), "explicit setup reason required")
        command = SETUP[self.a.action]
        output = self.adb.run(*command, timeout=self.a.timeout)
        self.h.write_json(directory / "stdout.json", {"stdout": output.decode(errors="replace"), "bytes": len(output)})
        return {"argv": list(command), "reason": self.a.reason,
                "note": "Command execution recorded; inspect resulting state separately"}

    def finish(self):
        h = self.h
        # Incomplete or failed driver attempts cannot silently disappear behind static PASS.
        for directory in (self.run / "native-evidence").glob("*"):
            record = h.read_json(directory / "record.json")
            h.require(record["outcome"] == "RECORDED", "driver contains a failed/incomplete attempt")
            h.require(record["run_id"] == self.record["run_id"] and record["apk_sha256"] == self.record["apk"]["sha256"],
                      "native evidence identity differs")
            for artifact in record["artifacts"]:
                h.validate_artifact(artifact, self.run, self.record["started_ns"])
        result = h.aggregate(self.run)
        h.write_json(self.run / "gate.json", result)
        return {"static_manifest": result, "native_evidence": "NOT_REVIEWED_BY_DRIVER",
                "limits": "Root must separately review lifecycle, movement, system dialogs and crash evidence; this is not a full-release PASS"}

    def execute(self):
        a, h = self.a, self.h
        if a.command == "begin":
            return self.begin()
        if a.command == "tap":
            return h.tap(self.run, self.adb, a.case, json_arg(a.selector), json_arg(a.expect), timeout=a.timeout)
        if a.command == "capture":
            return h.capture_case(self.run, self.adb, a.case, timeout=a.timeout)
        if a.command == "review":
            return h.review_case(self.run, a.case, "root", a.decision, a.observations)
        if a.command == "finish":
            return self.finish()
        if a.command == "raw-snapshot":
            h.require(h.IDENTIFIER.fullmatch(a.label), "invalid evidence label")
        operation = {"show": self.show, "type": self.type_text, "scroll": self.scroll,
                     "raw-snapshot": self.raw_snapshot, "facts": self.facts, "setup": self.setup}[a.command]
        details = {key: value for key, value in vars(a).items() if key in
                   ("case", "selector", "expect", "text", "direction", "label", "png", "action", "reason")}
        return self.event(a.command, operation, details)


def main():
    args = parser().parse_args()
    try:
        result = Driver(args).execute()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as exc:
        print("DRIVER STOP: " + str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
