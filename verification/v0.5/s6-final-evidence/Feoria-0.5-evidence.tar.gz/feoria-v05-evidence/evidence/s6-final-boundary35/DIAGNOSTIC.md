# Диагностическая попытка, не release aggregate

Home: точное сохраненное A=B=C и возврат на паузе прошли. Sleep helper завершился с FAIL по deadline из-за ошибочного veto по сводным ResumedActivity/Resumed ссылкам. В действительности Activity state=STOPPED, events показывают onPause/onStop, дисплей Asleep, Changing=false, noninteractive, screenoff, focus=null, task sleeping=true

Независимое review подтвердило дефект oracle. Меняется только sleep_ready по фактическим физическим флагам, Home и сохраненные данные не ослабляются. Новый полный сценарий будет в s6-final-boundary35-r2. Эта попытка не переписывается и finish не вызывается

После отказа выполнены отдельные read-only A/B за8.01с: bytes равны, segment111/offset5635/FAST, фраза8. После wake/launch те же bytes и UI Фраза8/20 с Включить плеер. Это ограниченное наблюдение не заменяет отсутствующий исходный Sleep checkpointA
