Feoria 0.5 Stage 6 evidence

The manifest preserves every selected file, its original path, size, mtime and SHA256.
Failed boundary r1/r2 attempts and CI failures remain failed.
Archiving verifies bytes only; inspect run/gate/review documents for individual outcomes.
No original evidence was deleted, repaired or overwritten.
