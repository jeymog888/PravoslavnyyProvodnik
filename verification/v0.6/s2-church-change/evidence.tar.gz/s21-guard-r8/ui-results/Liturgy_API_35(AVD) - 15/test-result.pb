
�	
�
ChurchChangeConfirmationTestru.liturgyguide.ui?aLongChurchNameAtLargeTextKeepsBothConfirmationActionsReachable2��������:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ChurchChangeConfirmationTest-aLongChurchNameAtLargeTextKeepsBothConfirmationActionsReachable.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain