#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1/first-failure-1794170393653" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-s21-r1/first-failure-1794170393653" "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1/first-failure-1794170393653" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1/first-failure-1794170393653/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1/first-failure-1794170393653.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/v06-s21-r1/first-failure-1794170393653.export.txt"
exit "$result"
