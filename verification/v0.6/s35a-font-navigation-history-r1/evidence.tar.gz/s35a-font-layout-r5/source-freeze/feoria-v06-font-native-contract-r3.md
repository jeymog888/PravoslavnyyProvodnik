# Current font contract after the r2 finding

This supersedes the custom A*P(sp) converter proposal in earlier 3.5a planning documents

The actual Compose 1.7.3 MeasureScope forwards density and fontScale, but not custom SP conversion overrides. The six direct-call AppTextDensity unit tests passed while real text used a different conversion path. Those tests and the unsupported uncommitted implementation were removed; their results and exact sources remain in historical evidence

Use native Density(parent.density, parent.fontScale * appFactor), with factors 1, 1.15 and 1.3. Font conversion is the native curve C_(S*A)(sp). It is deliberately not the old A*P_S(sp) formula. DP/PX density is unchanged. The application offers named size choices, not a promise of proportional glyph size

Primary guidance: https://developer.android.com/develop/ui/compose/accessibility/scalable-content#font-scaling (updated 2026-10-22). The official font-scaling example uses the native Density constructor and explicitly describes nonlinear behavior

Witness profiles 320x640/2.6, 400x800/2.6 and 640x360/1.69 now mean requested native fontScale. They are not labeled linear. The 120dp reading area, 48dp actions, base 28sp/39.2sp reader style, no font caps and real text-bound checks are unchanged

Actual Text line extents and baselines must agree with native TextMeasurer for identical text, style and constraints. This does not prove absence of rounded-shape clipping; visual review remains necessary. r3 passed 9 unit and 21 UI cases but was rejected visually for portrait sidebars

Real system 200% remains a separate required integration run. Root controls and verifies the system setting. For every app factor, compare conversions against native Density with the recorded system factor and verify actual Text metrics. At system 2.0 with app factor 1, require demonstrable nonlinearity. Do not require linearity or a particular curve beyond 2.0; record actual conversions. No hidden settings mutations or skipped tests

Compact provenance and soundless notes remain in the scrollable controls and reading details, with full accessible status. A mixed Original+Russian Scripture scenario explicitly checks the fallback explanation and preservation of the user's selected original mode
