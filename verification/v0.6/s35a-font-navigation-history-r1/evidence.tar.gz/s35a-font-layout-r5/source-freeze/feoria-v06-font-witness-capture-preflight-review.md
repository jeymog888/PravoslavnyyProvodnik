# Capture preflight после stale кадра r4

ACCEPT test-only delta для последующего общего freeze и запуска. Это не исправление production runtime и не преждевременная приемка новых изображений

Прочитан точный diff ReaderFontLayoutWitnessTest против r4/source-freeze. Текущий прочитанный SHA256 d5a71a9081c6458e83f2eef9e70fb5219f8e73f7822e731a570933e1f5dfbaa4. Геометрические/assertion проверки не ослаблены. Вместо глобального UiAutomation screenshot снимается font_witness_host через captureToImage, сохраняются PNG SHA/source metadata; каждая из семи заведомо визуально разных fixture данного профиля обязана иметь другой hash. Нет пользовательского цикла пересъемки, подмены файла или выбора удачного кадра; duplicate приводит к FAIL после сохранения evidence

Независимо проверен actual cached ui-test-android1.7.3: classes.jar внутри AAR побайтно совпал с /private/tmp/feoria-ui-test-173.jar, SHA256 bc631fb3cfd87677d7fb36100c813463210a8941066f9659965e5de88cd06356. Bytecode сохранен /private/tmp/feoria-v06-capture-WindowCapture-javap.txt

WindowCapture captureRegionToImage вызывает forceRedraw до generateBitmap/PixelCopy. В API>=29 при hardware acceleration регистрируется frameCommitCallback, затем invalidate; redraw wait ограничен2000ms, PixelCopy await1000ms. Для других условий используется OnDrawListener, поэтому нельзя универсально обещать frameCommit на любом устройстве. Наш API35 путь соответствует предложенному обоснованию

Точная оговорка к словам "без retries": в тесте повторов нет, но библиотечный captureRegionToImage содержит ограниченный retry только для PixelCopy ERROR_SOURCE_NO_DATA, до трех попыток. Это штатное ожидание данных источника, не повтор assertions/поиск визуально удачного результата

Снимок относится к реальным window pixels указанной области host. Это cropped fixture evidence, не полный экран телефона, не доказательство системных overlay/всех insets. Различие SHA ловит конкретный stale duplicate r4, но само по себе не доказывает соответствие каждому состоянию - личный просмотр PNG и сопоставление JSON остаются обязательными

R4 сохраняется как numeric PASS,20 visual ACCEPT и1 stale capture REJECT. Новые изображения еще NOT RUN. Gradle/adb не запускались, repo не менялся
