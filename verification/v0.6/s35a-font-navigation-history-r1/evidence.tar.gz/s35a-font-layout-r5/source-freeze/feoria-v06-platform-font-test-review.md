# Независимое review ReaderPlatformFontTest

ACCEPT для включения в общий freeze и последующего запуска. NOT RUN, это не приемка фактической системной200%

Manifest SHA25644d04e6b73318bdd10472b1707a71ee9089b2b1667cf0159dccf1a64cf4492da проверен. ReaderPlatformFontTest.kt SHA256473f9989a948b4bf6c1a9b85e80aaa9d6a13315407fb0b89b2598faa0acc725a,14254bytes совпали. Прочитан полный новый файл и сверены production selectors/settings/menu/details, helpers закрытия окон и схема fixture

Статических блокеров не найдено

- Parent считывается непосредственно из реального ComponentActivity LocalDensity/LocalConfiguration, до AppNavigation. В тесте нет подложенного Density provider или изменения системной настройки. При explicit expected2 обе реальные metadata обязаны быть2 и дополнительно проверяется нелинейность преобразования реального parent
- Настройка приложения меняется только через production UI0->1->2->0->2. Проверяются preference, исходный parent без накопления множителя, requested child S*A, неизменный physical density, прямые/обратные DP/PX преобразования, actual line metrics через принятый NativeFontAssertions
- Popup, AlertDialog, controls Sheet, settings title/row и bottom navigation действительно достигаются через существующие selectors. Dropdown содержит "Тексты этапа"; "Тексты этого этапа" относится к другой поверхности и здесь не перепутано
- Fixture использует actual current plan/date2026-11-08, существующий parish elisavetinsky_opalikha, creed track1/line3, FAST и offset1234. Принятие идет через ReadingAcceptanceStore; затем проверяются сохраненный playback,context,bookmark values,preferred Original,selected original line и пауза. Fixture не выдается за пользовательский journey
- scenario.recreate создает реальный новый Activity, идентичность проверяется. Допустимый путь через явный resume после восстановления с диска не пропускает проверки: оба маршрута завершаются одинаковыми assertions чтения/настройки/данных
- Нет Assume/skip, условие expectedScale2 только усиливает проверку нелинейности. Если аргумент отсутствует, метод все равно выполняется на реальном текущем parent, но такой запуск нельзя маркировать ни baseline1, ни system200%

Обязательство root: baseline запускать с feoriaExpectedSystemFontScale=1, отдельный реальный200% с аргументом2 после внешнего изменения ОС. Этот тест сам не переключает ОС. Оба запуска и native screenshots пока отсутствуют

Фиксированные sampled тексты проверяются целиком в bounds. Для длинной читаемой строки fixed=false намеренно допускает прокрутку; внутренние glyph/ellipsis/maxLines проверки остаются. Это не ослабляет требования к fixed controls. Численный120dp и28sp/39.2sp сохранен, полная48dp матрица остается в отдельных witness/старых suites

Тест допускает явный FAIL при реальном clipping settings/window текста - до запуска его геометрия не доказана. Ни production изменения, ни обходы этих assertions этим review не разрешаются автоматически

Gradle/adb не запускались, repo не менялся
