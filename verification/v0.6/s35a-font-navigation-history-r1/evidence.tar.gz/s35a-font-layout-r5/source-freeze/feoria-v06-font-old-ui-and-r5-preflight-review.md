# Независимое review старых UI tests и общего R5

ACCEPT для общего R5 запуска по manifest. NOT RUN, геометрия всех этапов, фактическая200% и конечная native приемка пока не доказаны

Прочитаны полностью diff всех5 файлов адаптации и карта ожиданий. Проверены5 SHA/bytes, aggregate0faaab979e2e57b0457b3e9460a7a3fed490788ad9b9338828b8c725be06360e, SHA linked diff/report/beforeManifest. Общий /private/tmp/feoria-v06-font-layout-freeze-r5-root.json проверен:15 SHA/bytes, aggregate6927015d98bca990eba5d0b7050429322a408e95c57c146aadcbc97efe8e33d3 совпали. Все6 production файлов точные r4

Статических блокеров и ослаблений assertions ради прохода не найдено

## Адаптация прежних гарантий

- ReaderAccessibilityTest:48dp,120dp,300dp church/settings guards сохранены. Молитва теперь28sp/39.2sp с проверкой native glyph metrics вместо прежнего capped20sp. Проверка отделения fixed controls от body обобщена на две оси, что необходимо для sidebar и не допускает перекрытия. Полный текст/ellipsis/line extents и строгие one-line normal labels остаются
- CompactReaderMatrixTest: все18 этапов в обеих ориентациях остаются в цикле. Короткое имя проверяется как видимый stress title, полное имя отдельно в accessible контексте и в читаемом controls sheet. Полная provenance не исчезает из ожиданий: проверяется StateDescription и явный текст подробностей. День,24-часовой скачок часов, pause/state и stale callbacks сохранены
- ReaderCompositionFlowTest: прежнее заменяющее место Clarify/Return адаптировано к согласованным раздельным слотам. Новые проверки сохраняют координаты Clarify,primary,controls,reading при Return и Play/Pause; Return отдельно имеет48dp, отсутствие overlap, доступное имя и текстовую альтернативу. BeforeStart playing проверяет одновременно доступные Pause и Clarify
- ReaderFeedFlowTest: long-line/shrink proof, measured oldOffset>shortExtent, реальный before-frame input<16ms, rejected writer, elapsed/date/owner и stale actions не удалены и не заменены ослабленными ожиданиями. Захват старого tab callback имеет дополнительное явное доказательство NORMAL layout. Mode переключается через существующие UI routes
- ReaderTestControls: нет retry, direct player вызова или production formatter для expected status. Helper выбирает видимую вкладку либо настоящий sheet, проверяет selected/enabled в фактическом действии. После переключения заново определяет layout, поэтому не требует сохранения прежней ветки. Открытие/закрытие sheet не маскирует итоговые player/write/anchor assertions

Существующий последовательный reader-title oracle для длинного scrollable текста сохранен. Full fixed title/controls не объявлены читаемыми только по exists. Строгие one-line navigation/settings и300dp остались и могут выявить настоящий незакрытый дефект после снятия caps; заранее подгонять их не требуется

## Общий preflight

ReaderPlatformFontTest точный ранее принятый473f9989a948b4bf6c1a9b85e80aaa9d6a13315407fb0b89b2598faa0acc725a. Witness точный принятый capture delta d5a71a9081c6458e83f2eef9e70fb5219f8e73f7822e731a570933e1f5dfbaa4, NativeFontAssertions c3d24a242787b9c88a7c1356e6f49cb03ba6296f730aa9bad78369966180cbdd. Существующие capture/platform reports применимы без нового изменения кода

Разрешенный по review следующий шаг: полныйunit и7 UI классов, перечисленных в R5 manifest, с explicit feoriaExpectedSystemFontScale=1 для platform baseline. НастоящаяOS200 с аргументом2 остается отдельным запуском. Численный R4 PASS/20 принятых кадров/1 stale capture сохраняются; R5 требует собственных результатов и новых PNG, distinct SHA не заменяет личного просмотра

Это независимый read-only review: Gradle/adb и изменения repo не выполнялись
