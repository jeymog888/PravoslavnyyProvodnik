# Old reader UI expectations adapted to stage 3.5a

Only four reader suites and ReaderTestControls changed. ChurchChangeConfirmationTest, runtime, ReaderFontLayoutWitnessTest, NativeFontAssertions and ReaderPlatformFontTest were not edited

Expectation map

- ReaderAccessibilityTest: prayer 20sp expectation becomes 28sp/39.2sp with native renderer/predictor comparison. Three normal tabs remain; compact checks a visible selected mode and three real choices in the sheet. Fixed controls/status must be fully visible and disjoint from the reading area in two dimensions, permitting a header or sidebar. Soundless details remain reachable. All 120dp/48dp/300dp guards and line extents remain
- CompactReaderMatrixTest: all 18 portrait and landscape stage names still checked. Compact uses the exact short title while full stage name is checked in accessible context and a readable controls title. Full status remains checked via StateDescription and visible sheet details; compact live status has explicit expected text. Both prayer languages retain 28sp/39.2sp and native metrics. Original state/date/time/stale checks remain
- ReaderCompositionFlowTest: Return has its own stable slot and does not remove clarification. Viewport, primary, clarify and controls bounds must stay identical across Return and Play/Pause. Return and Pause remain 48dp and disjoint. Compact Return also has a full accessible name and a signed sheet action. Live BeforeStart keeps both direct Pause and Clarify, while the existing sheet correction/pause outcome is unchanged
- ReaderFeedFlowTest: mode choices follow the real adaptive route, compact status is checked independently of the full accessible status, and Return preserves clarification bounds. Measured long-line/shrink/old-offset witnesses, before-frame cancellation, rejected writes and late callbacks are unchanged
- ReaderTestControls: existing APIs unchanged. Added explicit tab/chooser routes without retries or direct player calls. Mode selected/enabled checks use actual action semantics. Full and compact status strings are supplied as test literals, not computed by the production formatter

Self-review and QA

A real helper edge was corrected before freeze: choosing a mode can change normal/compact placement, so post-choice assertions inspect the new layout instead of requiring the old chooser to survive. Independent QA read all five diffs and found no blocking issue. Existing captures of tab callbacks keep an explicit normal-layout witness, preserving the same stale-action test rather than replacing it with another route

Still intentionally strict: one-line short navigation/day labels and settings headings, 300dp church/settings content, sequential readability of long track titles. These may expose a real remaining layout issue when caps are removed; no thresholds were silently lowered

Validation

Static diff check passed. Protected state/time/date/write/anchor assertions were compared against the five saved inputs with no loss. Gradle/adb NOT RUN. Exactly 43 existing UI methods across four suites remain; no new artificial test count

SOURCE FREEZE. Root runs and reviews the final rendered result
