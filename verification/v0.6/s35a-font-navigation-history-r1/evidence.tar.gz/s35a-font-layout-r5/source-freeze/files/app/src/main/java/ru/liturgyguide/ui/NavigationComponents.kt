package ru.liturgyguide.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GuideBottomBar(selected: String, onHome: () -> Unit, onChurch: () -> Unit, onSettings: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surface) {
    Row(Modifier.fillMaxWidth().navigationBarsPadding().height(IntrinsicSize.Min).selectableGroup()) {
        listOf(Triple("home", "Служба", Icons.Default.MenuBook), Triple("church", "Храм", Icons.Default.Place),
            Triple("settings", "Настройки", Icons.Default.Tune)).forEach { (id, title, icon) ->
            val active = selected == id
            Column(Modifier.weight(1f).fillMaxHeight().heightIn(min = 80.dp)
                .selectable(selected = active, role = Role.Tab, onClick = when(id) { "church" -> onChurch; "settings" -> onSettings; else -> onHome })
                .testTag(if (id == "settings") "open_settings" else "nav_$id").padding(horizontal = 6.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically)) {
                Box(Modifier.background(if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Icon(icon, null, tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(title, style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 0.sp),
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    }
}

@Composable
fun GuideActionRow(title: String, subtitle: String?, icon: ImageVector, onClick: () -> Unit, tag: String = "") {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).testTag(tag).padding(20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
