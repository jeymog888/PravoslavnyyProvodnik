# Узкое review R6 unit oracle

ACCEPT точечного test-only исправления ReaderVisibleStatusTest

Лично прочитан diff против точного R5/source-freeze и два failure в unit XML. Итог XML435 tests,2 failures,0 errors,0 skipped. Оба отказа действительно ожидают прежнее скрытие приблизительности при restored=true: строки21/66. Новый результат добавляет " · примерное место", остальные части совпадают

Изменены только2 expected строки и поясняющий комментарий. Дата Missing, статус паузы, факт сохраненности,3 остальных метода и проверки отсутствия дублирования приблизительности/языка не ослаблены. Это согласование oracle с уже принятой R3 независимостью restored и isApproximate, не подгонка production поведения

Новый SHA256 ReaderVisibleStatusTest.kt9f1dbac855a00b623faece4e018a87aad775c05ccc0f17eda88613c1821c0fab,6246bytes. Все15 файлов из R5 manifest независимо перепроверены - bytes/SHA неизменны, включая весь runtime и instrumentation

R5 остается FAIL, UI NOT RUN. Допускается следующий R6 полныйunit + прежние7UI по общему freeze с добавлением этого файла. Успешное выполнение пока не заявляется

Gradle/adb и изменения repo не выполнялись

Дополнение: общийR6 freeze16файлов проверен полностью, aggregate2ef93f58c3a7ddcbcb48befd85f81fef0977f4442358b5a7d431c63883bbff7a совпал
