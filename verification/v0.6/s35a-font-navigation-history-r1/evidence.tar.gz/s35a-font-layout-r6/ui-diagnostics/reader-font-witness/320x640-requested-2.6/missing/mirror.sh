#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/320x640-requested-2.6/missing/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
