#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r6/reader-font-witness/400x800-requested-2.6/russian-scripture/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
