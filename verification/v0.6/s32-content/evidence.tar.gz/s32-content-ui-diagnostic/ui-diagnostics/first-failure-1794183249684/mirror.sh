#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684" "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s32-content-ui-diagnostic/first-failure-1794183249684.export.txt"
exit "$result"
