
�
�
ExpandedContentFlowTestru.liturgyguide.uiOanaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations2͠������:Ԡ�������
�java.lang.AssertionError: Assert failed: The component is not displayed!
at androidx.compose.ui.test.AssertionsKt.assertIsDisplayed(Assertions.kt:34)
at ru.liturgyguide.ui.ExpandedContentFlowTest.scroll(ExpandedContentFlowTest.kt:158)
at ru.liturgyguide.ui.ExpandedContentFlowTest.selectTrack(ExpandedContentFlowTest.kt:149)
at ru.liturgyguide.ui.ExpandedContentFlowTest.anaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations$lambda$3(ExpandedContentFlowTest.kt:58)
at ru.liturgyguide.ui.ExpandedContentFlowTest.$r8$lambda$HphfSlIuY0FUY_X07OBp0T4Vr20(Unknown Source:0)
at ru.liturgyguide.ui.ExpandedContentFlowTest$$ExternalSyntheticLambda8.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ExpandedContentFlowTest.anaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations(ExpandedContentFlowTest.kt:51)
java.lang.AssertionError�java.lang.AssertionError: Assert failed: The component is not displayed!
at androidx.compose.ui.test.AssertionsKt.assertIsDisplayed(Assertions.kt:34)
at ru.liturgyguide.ui.ExpandedContentFlowTest.scroll(ExpandedContentFlowTest.kt:158)
at ru.liturgyguide.ui.ExpandedContentFlowTest.selectTrack(ExpandedContentFlowTest.kt:149)
at ru.liturgyguide.ui.ExpandedContentFlowTest.anaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations$lambda$3(ExpandedContentFlowTest.kt:58)
at ru.liturgyguide.ui.ExpandedContentFlowTest.$r8$lambda$HphfSlIuY0FUY_X07OBp0T4Vr20(Unknown Source:0)
at ru.liturgyguide.ui.ExpandedContentFlowTest$$ExternalSyntheticLambda8.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ExpandedContentFlowTest.anaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations(ExpandedContentFlowTest.kt:51)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ExpandedContentFlowTest-anaphoraSuppliesTheMissingSubjectAndExplanationsBesideBothLanguagePresentations.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain