# R13 FirstVisit modal Back focus review

ACCEPT узкой test-only коррекции: после открытия явно assertIsDisplayed(church_picker), затем единственный Back через Espresso.onView(isRoot()).inRoot(isDialog()).perform(pressKey(KEYCODE_BACK)) внутри существующего withCiFailureDiagnostics. Не менять общий pressBack helper или failure handler, не вводить retry

Независимо прочитаны failure.txt, capture.json, windows.txt, displays.txt, power/policy, FirstVisitFlowTest.kt:107-122 и ChurchScreen.kt:90-100. screen.png лично открыт: нормальный открытый picker поверх Church, не blank/frozen Activity

Доказанный отказ: FirstVisitFlowTest:112 вызывает общий Espresso.pressBack сразу после open_church без явной проверки picker. RootViewWithoutFocusException показывает выбранный BASE_APPLICATION/type1 root с has-window-focus=false, layout-requested=false. Capture interactive=true, keyguard/device locked=false. displays.txt mCurrentFocus=7f9b84d; это видимое полноэкранное прозрачное APPLICATION окно модали. Базовое окно 8b8099f имеет BASE_APPLICATION. Оба поверхности нарисованы, focus принадлежит модальному окну. Поэтому исключение ожидания focus Activity не свидетельствует о неработающем Back приложения

ChurchScreen открывает именно ModalBottomSheet с skipPartiallyExpanded=true и church_picker LazyColumn. onDismissRequest вызывает прежний cancellation, очищает draft и picker flags. Предложенный pressKey проходит через настоящее окно/обработку Back, не вызывает callback напрямую и сохраняет проверку этого пути

Дополнительно проверен локальный Espresso3.5.1 bytecode RootMatchers$IsDialog.matchesSafely: исключает TYPE_BASE_APPLICATION1, требует application type<99 и совпадающие decor window/application tokens. Наблюденное APPLICATION окно соответствует нужному классу окна; isDialog оставляет runtime проверку токенов, вместо жесткого ID или выбора первого root. В данном сценарии открыт один известный dialog; assertion church_picker делает предпосылку явной

Ограничение причинности: packet доказывает неверно выбранный unfocused base root на отказе и наличие focused modal, но не восстанавливает всю временную последовательность выбора Espresso. Не утверждаем, что новая nav geometry вызвала этот race или что исправление уже прошло

Сохранить все последующие assertions: picker исчез, Church остался, Home отсутствует, preferences unchanged, restoration, повторный выбор и успешный переход Home. Эти гарантии не заменять видимостью диалога. Только один метод требует адресной коррекции; другие Back callers не расширять без свидетельств

R13 остается 48 PASS/1 FAIL. Следующий целевой запуск проверяет коррекцию, прежний отказ сохраняется. Source не редактировал, Gradle/adb не запускал
