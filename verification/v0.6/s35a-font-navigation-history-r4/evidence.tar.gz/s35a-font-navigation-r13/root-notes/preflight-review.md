# R13 adaptive navigation review

REQUEST_CHANGES: одна узкая поправка округления ширины predictor. После нее остальной прочитанный delta пригоден для целевого запуска; UI еще NOT_RUN

Прочитаны exact NavigationComponents.kt и ReaderAccessibilityTest.kt против R12 source-freeze. Все 19 текущих SHA/bytes совпали с freeze aggregate 08551a7b5a1d9ae343a0428777e833f78c14872211f80068227aed1e1c6b579d

NavigationComponents.kt:40 cellTextWidth вычитает round(12dp), но реальный Column padding(horizontal=6.dp) вычитает дважды round(6dp). Например density1.25: predictor вычитает15px, actual16px. На границе переноса predictor может оставить columns при фактически не помещающемся label. Минимальная правка: вычитать 2 * roundToPx(6.dp). При текущем density420 оба равны32px, так что это не диагноз прошлого native отказа

Остальная реализация соответствует решению: измеряются все три точных native labels независимо от selected; normal columns сохраняются при полном размещении. Stacked rows дают прежние destinations одним нажатием, сохраняют IDs, selectableGroup, Role.Tab, selection и callback. Insets один раз вокруг группы, label12sp без cap, rows >=48dp. Modifier.weight(1f) в rows занимает остаток ширины, full native text сохранен. Нет влияния на reader ownership или persistence

Тесты содержательны: baseline требует трех колонок, полных однострочных12sp labels, >=48 targets, общую верхнюю линию icons/no-overlap и реальные переходы всех трех destinations. Stress требует stacked, одну полную строку, native metrics, actual paragraph/node width, >=48, общую колонку icons/no-overlap. Church/Settings >=300dp и readable scroll headings сохранены. Изменение icon geometry соответствует настоящему новому расположению, не снимает проверку

Оставшая формулировка assertion "Centered navigation" в stacked helper неточна редакционно, но проверяет нужное равенство node/paragraph widths и не блокирует запуск

После точечной поправки нужен новый freeze SHA. Реального fit не заявляю; source, Gradle и adb не менял/не запускал

## Final corrected freeze

ACCEPT для целевого запуска. Root заменил только вычитаемый padding на 2 * roundToPx(6.dp); строка лично перечитана. Все 19 SHA/bytes повторно совпали с окончательным aggregate 6f9f3ffdf5f34ea52237584f5bf3d1f2cc5cc57f601eab288e5c257588148135. Указанный rounding blocker закрыт до сборки. Прежний REQUEST_CHANGES выше описывает исходную версию, окончательный вердикт - ACCEPT, NOT_RUN
