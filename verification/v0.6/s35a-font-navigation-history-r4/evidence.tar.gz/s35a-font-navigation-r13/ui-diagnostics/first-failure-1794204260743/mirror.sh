#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r13/first-failure-1794204260743.export.txt"
exit "$result"
