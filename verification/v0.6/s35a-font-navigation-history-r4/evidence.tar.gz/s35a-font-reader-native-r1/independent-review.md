# Controls mode selection visual preflight

REJECT текущего large-controls PNG. ACCEPT_WITH_CONDITIONS узкой визуальной коррекции ReaderControlAction

PNG лично открыт. SHA/bytes case артефактов сверены. Все три режима действительно выглядят одинаковыми: цвет/вес текста совпадают, нет выбранной поверхности или маркера. after.xml подтверждает selected=true именно на clickable ancestor "Оригинал" [0,1452][1080,1636], а не на дочернем Text. Следовательно это настоящий разрыв между semantics и видимым выбранным режимом, не stale capture или неверное чтение XML

ServiceScreen.kt:553-561 использует selection только в semantics; selected не участвует в drawing. Вызовы modes:269-274 передают нужный selectedTab и защищенный owner callback. Исправление не требует менять selection logic

Принимаю full-row secondaryContainer только при selection==true, остальные прозрачны. Использовать согласованный onSecondaryContainer для selected label/check, чтобы не переносить случайный primary contrast на новый фон. Для всех трех mode rows одинаково зарезервировать trailing24dp и одинаковый gap, Check показывать только selected. Icon декоративный contentDescription=null: выбранность уже передается существующим selected/Role.Tab. Не создавать второй clickable target или fake check action

Native bodyLarge, min48dp, IDs, disabled state, owner key/guard, callback и момент закрытия sheet сохраняются. Для selection==null обычные controls не обязаны получать пустую колонку маркера. Стабильная ширина всех mode labels предотвращает reflow только из-за перемещения Check

Проверить видимый маркер ровно одного выбранного mode и его перенос после действительного переключения, сохранив existing state checks. Новая native PNG нужна: semantics alone уже оказалась недостаточной. При крупном масштабе подтвердить glyph/no-overlap после уменьшения доступной ширины label на reserved slot. Светлая/темная selected поверхность должна оставаться различимой

Некрасивый разрыв "Управлени/е" остается обязательной полировкой этапа 5, не скрывается данным ACCEPT направления исправления. Исходный run с двумя captures остается неполным и controls REJECT, не aggregate PASS

Source не редактировал, Gradle/adb не запускал
