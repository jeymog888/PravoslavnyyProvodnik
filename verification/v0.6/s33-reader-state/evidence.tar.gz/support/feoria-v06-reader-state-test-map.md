# Карта проверок состояний reader для 3.3

Read-only QA по root brief, NIGHT_PLAN 3.3, текущему ServiceScreen и связанным UI-тестам после подготовки 3.2. Исходники не менялись, Gradle/adb/git не запускались. Это карта будущего изменения, не приемка реализации

## Что изменить в ожиданиях

| Класс / метод | Прежнее ожидание | Ожидание по контракту 3.3 |
| --- | --- | --- |
| GuideNavigationTest.onePlayerStartsDirectlyAndPausesWithoutASecondStageTimer | После start_guide открывается preparation и сразу нажимается enabled play_lyrics, затем next_stage | BeforeStart показывает наблюдаемый признак и основной шаг "Литургия началась". Нажатие открывает следующий этап на паузе. Единственный player и отсутствие legacy autoAdvance сохраняются; активный BeforeStart проверить отдельно через настоящее состояние того же engine |
| FirstVisitFlowTest.newTempleWithoutScheduleLeadsThroughPersonalTimeToTheExactService | После watch_next подготовка подтверждается наличием contentDescription "Включить плеер" | Сохранить точные приход/дату/source/startEpochMillis; подготовку подтверждать ее статусом и шагом "Литургия началась", без ожидания обычного Play |
| UnifiedPlayerFlowTest.onePlayMovesThroughTextsAUsefulWaitAndTheNextStage | Text/Wait имеют одинаковую иконку "Остановить плеер"; Wait проверяет "Дальше слушаем службу" и полное stage.meaning | Text показывает действие "Двигать текст"/"Пауза" и "Без звука"; после текста Wait объясняет, что этап может продолжаться, дает следующий ориентир и отдельный статус включенного примерного перехода. Не требовать полного stage.meaning в Wait. Сохранить точные переходы, новые времена 3.2, последний bookmark и единый clock |
| UnifiedPlayerFlowTest.missingDatedReadingsStopHugeTicksAndEachNeedsItsOwnManualContinuation | В Missing трижды ожидается disabled play_lyrics; продолжение расположено перед длинным cue внутри lyrics_list | Play отсутствует, есть одно основное подтверждение "Чтение в храме закончилось", видна сохраненная дата. Общий next_stage не дублирует обход преграды. Проверки huge tick, обеих независимых преград, recreation и даты оставить. Доступность 48 dp и видимость основного действия оставить, не закреплять старое место внутри конкретной карточки |
| UnifiedPlayerFlowTest.endStopsThePlayerAndFinishingClearsTheAcceptedReading | End имеет disabled play_lyrics, завершение выполняется через общий next_stage | End показывает один основной "Закончить чтение", без disabled Play и второго дубликата завершения. Wait последнего этапа не обещает следующий этап. Сохранить остановку на End и очистку context/snapshot/session/bookmarks только после явного завершения |
| GuideNavigationTest.switchingToMeaningPausesScrollingAndKeepsThePhrase; UnifiedPlayerFlowTest.languageAndProgrammaticScrollKeepPlayingButMeaningAndUserDragPause | Meaning скрывает Play, возвращение идет через tab; явная видимая пауза не проверяется | Сохранить отсутствие Play, добавить видимый статус паузы и понятный возврат к тексту. Возврат сохраняет адрес и темп и остается paused. Проверки языка во время движения, времени в Meaning и user drag не ослаблять |
| GuideNavigationTest.choosingManualReadingFromTempoOptionsStopsAnActiveScroll; changing-speed сценарий UnifiedPlayerFlowTest.changingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase | Темп/остановка проверяются через старые иконки и manual_reading | Три скорости остаются прежними; пояснение говорит о скорости движения текста/примерного перехода, а исправление разового отставания - о выборе места. Материализацию времени на старой скорости и точный offset сохранить. Проверять живой статус paused/playing, а не только слова внутри иконки |
| ReaderAccessibilityTest.ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed и assertFooterTargets | Meaning обязан сохранять previous_stage + next_stage; все тексты кнопки Play считаются вложенными под play_lyrics | Для Meaning проверить видимые паузу и возврат, отсутствие транспортного Play. Статус теперь отдельный элемент, поэтому проверка читаемости должна охватывать его отдельно от подписи действия. Число шести transport targets не переносить на Missing/End/BeforeStart. Глобальная переработка крупного текста остается 3.5a |
| CompactReaderMatrixTest.nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement; acceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid | Получают действие next_stage из прежней оболочки | Сохранить поведение на текущем отображаемом этапе и недействительность захваченного callback после новой generation. Новые основные действия BeforeStart/Missing/End также должны иметь эту защиту, а старые проверки нельзя удалить при смене тегов |
| ReaderAccessibilityTest.scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu | Preparation проверяет только отсутствие track title и наличие "Уточнить" | Дополнить смысловым состоянием BeforeStart и достижимым шагом начала; ручное уточнение остается доступно. Scripture остается русским fallback с честной подписью. Перестройка меню режима относится к 3.5a, не к этой порции |

## Helpers, которые нельзя обновить одной заменой текста

- UnifiedPlayerFlowTest.play/assertPaused, GuideNavigationTest.startScrolling/assertManualReading, ManualMomentFlowTest.assertManualSession, ExhaustedServiceEntryTest.assertAccepted, Published05PlaybackIntegrationTest.assertStored и несколько assertions SavedReadingTest/ArrivalFlowTest используют "Включить плеер"/"Остановить плеер" как признак живого состояния
- После разведения состояний helper должен проверять соответствующие действие и отдельный статус. Наличие snapshot и результат engine.restore сами по себе не доказывают паузу UI: сохраненный snapshot всегда paused, даже во время живого Play
- В Text можно проверять "Двигать текст" + paused status; в Wait - "Продолжить по времени" + остановленный переход; BeforeStart/Missing/End требуют своих действий. Не вводить универсальное ожидание Play на каждом reader

## Инварианты, которые сохраняются

- Один player/engine и один monotonic clock, прежние duration/скорости/snapshot. Переименование кнопок не меняет содержание или fingerprint
- Язык не меняет адрес, offset или режим движения; Meaning и пользовательская прокрутка останавливают живое движение. Возврат из Meaning и фона не потребляет скрытое время и не включает Play
- Сохраненные дата, полный context и темп остаются прежними при ручном уточнении той же службы. Новый сервис и exhausted occurrence сохраняют уже принятые контракты
- Missing - преграда даже при огромном tick, системном времени и recreation; продолжение каждой преграды требует своего явного действия. End не двигается дальше от времени
- Pause остается обязательной при уходе и ошибке записи; успешное ручное принятие идет через существующий writer. Отказ записи не показывает успешное переключение
- Generation/screen guards сохраняются для старых и новых callbacks. Проверки lifecycle/top-resumed в UnifiedPlayerFlowTest, staleDetailsAction и readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause остаются необходимыми
- Migration note, источник пояснения 2.5 и metadata 3.2 сохраняются при смене представления. Эта порция не переносит редакционное пояснение в список произносимых строк

## Пробелы покрытия для новой порции

1. BeforeStart paused -> "Литургия началась" -> следующий этап paused, без фиктивного срока начала; отдельно уже playing preparation -> видимая остановка -> paused без второго таймера
2. Wait paused/playing различаются и по действию, и по статусу, после Pause не остается сообщения "переход включен". Переход в Wait из Text не теряет выбранный темп
3. Meaning поверх Missing/End сохраняет underlying state и отсутствие движения; возвращение к тексту снова показывает правильное основное действие, не обычный Play
4. Count/semantics основного действия: один в Missing и End, отсутствие дублирующего общего перехода и disabled Play. Признак отсутствия звука доступен в Text/Wait

## Два конкретных дефекта нынешней подачи

1. ReaderFooter считает любой Wait playable, включая preparation без единой строки. Кнопка называется состоянием "На паузе"/"По расчету", а подпись "Переходы" не объясняет, что будет двигаться. У подготовки нет специального действия начала. Это непосредственно соответствует жалобе пользователя; код подтверждает механизм, новый нативный прогон в этой ревизии не выполнялся
2. Missing/End сохраняют визуально главное disabled Play и общий next_stage. У Missing одновременно есть осмысленное подтверждение в body, а общий переход ведет дальше без этого текста; у End завершение дублируется в body и footer. Дефект здесь - противоречивая иерархия и семантика действий. Это не утверждение, что engine автоматически перескакивает преграду: временной барьер уже защищен и должен остаться защищенным
