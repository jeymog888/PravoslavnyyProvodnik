"""Root-only explicit layout fixtures, never upgrade or real-user navigation evidence."""
from pathlib import Path
import importlib.util,json,subprocess,sys,time,hashlib,shlex,zipfile,xml.etree.ElementTree as E
sys.dont_write_bytecode=True
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
base=repo/'app/build/verification/v0.6'
spec=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
planroot=base/'s32-current-plans';tables=json.loads((planroot/'published-plans.json').read_text())
oldbuild=json.loads((base/'s32-content-r2/build.json').read_text())
assert h.sha(base/'s32-content-r2/build.json')=='cdf2ef95524f87d8c8127671f1ff14b05ddc77d037cdf9cff17345c23b78f3da'
assert h.sha(planroot/'producer.json')=='c3d75c84a9b5eb5630800e84576c23b7bb270ac4f0723fa1bd2a7f6b89a52423'
assert h.sha(planroot/'published-plans.json')=='6f06b7f710691b61ac630597622ad370439a246f5307aadb30ffea12d3ff94e1'

def fixture(kind,dark,textsize):
    assert kind in ['text','wait','before','meaning','missing','end']
    assert dark in ['light','dark'] and textsize in [0,1,2]
    date='2026-11-09' if kind=='missing' else '2026-11-08'
    plan=next(p for p in tables if p['serviceDate']==date)
    wanted={'text':('great_litany','Text'),'meaning':('great_litany','Text'),'wait':('great_litany','Wait'),'before':('preparation','Wait'),'missing':('epistle','MissingReading'),'end':(None,'End')}[kind]
    segment=next(s for s in plan['segments'] if s['type']==wanted[1] and (wanted[0] is None or s['stageId']==wanted[0]))
    context={'version':1,'parishId':'vsetsaritsa_nakhabino','serviceDate':date,'timezone':'Europe/Moscow','source':'MANUAL','startEpochMillis':None}
    encoded=json.dumps(context,ensure_ascii=False,separators=(',',':'))
    stored={'version':1,'context':encoded,'contentVersion':plan['contentVersion'],'planFingerprint':plan['fingerprint'],'segmentIndex':segment['index'],'elapsedQuarterMillis':1234 if segment['type']=='Text' else 0,'speed':'SLOW'}
    session={'anchorEpochMillis':1794132000000,'anchorIsApproximate':False,'anchorStageId':segment['stageId'],'autoAdvance':False,'elapsedInStageMillis':0}
    root=E.Element('map')
    for name,val in [('church_id',context['parishId']),('stage_id',segment['stageId']),('session',json.dumps(session,separators=(',',':'))),('reading_context_v1',encoded),('service_playback_v1',json.dumps(stored,separators=(',',':')))]:E.SubElement(root,'string',{'name':name}).text=val
    for name,val in [('dark',dark=='dark'),('lyric_original',True)]:E.SubElement(root,'boolean',{'name':name,'value':str(val).lower()})
    E.SubElement(root,'int',{'name':'text_size','value':str(textsize)})
    return E.tostring(root,encoding='utf-8',xml_declaration=True),{'kind':kind,'theme':dark,'app_text_size':textsize,'context':context,'stored':stored,'segment':segment,'plan_table_sha256':h.sha(planroot/'published-plans.json'),'plan_producer_sha256':h.sha(planroot/'producer.json')}

if sys.argv[1]=='dry-run':
    for kind in ['text','wait','before','meaning','missing','end']:
        value,record=fixture(kind,'dark',1)
        parsed=E.fromstring(value)
        assert json.loads(parsed.find("string[@name='service_playback_v1']").text)==record['stored']
        print(json.dumps({'kind':kind,'date':record['context']['serviceDate'],'type':record['segment']['type'],'index':record['segment']['index'],'xml_sha256':h.digest(value)}))
    sys.exit()

run=Path(sys.argv[1]);kind=sys.argv[2];dark=sys.argv[3];textsize=int(sys.argv[4])
adb=Path('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb');a=h.Adb(adb,'emulator-5554')
_,runrecord,manifest=h.load_run(run,a)
assert a.shell('getprop','ro.kernel.qemu')=='1' and manifest['package']=='ru.liturgyguide'
assert runrecord['apk']['debuggable'] is True
current=json.loads((run/'build.json').read_text())
oldfiles={p['path']:p['sha256'] for p in oldbuild['inputs_before']['files']}
newfiles={p['path']:p['sha256'] for p in current['inputs_before']['files']}
paths=['app/src/main/java/ru/liturgyguide/service/'+n for n in ['ServicePlaybackPlan.kt','PrayerTrackFactory.kt','StageMatcher.kt']]
paths+=['app/src/main/java/ru/liturgyguide/model/'+n for n in ['DailyReadings.kt','PrayerTrack.kt','LiturgyStage.kt']]
for path in paths:assert oldfiles[path]==newfiles[path],path+' changed; regenerate actual plan fixture table'
assert h.sha(runrecord['apk']['path'])==runrecord['apk']['sha256'],'Local APK bytes changed'
with zipfile.ZipFile(runrecord['apk']['path']) as z:
    for asset in ['liturgy_stages.json','daily_readings.json']:
        assert h.sha(planroot/asset)==oldfiles['app/src/main/assets/'+asset],'Historical table source assets changed'
        assert h.digest(z.read('assets/'+asset))==h.sha(planroot/asset)
value,record=fixture(kind,dark,textsize)
ledger=run/'supplemental'/('fixture-'+str(time.time_ns()));ledger.mkdir(parents=True)
(ledger/'preferences.xml').write_bytes(value)
record.update(status='STARTED',run_id=runrecord['run_id'],apk_sha256=runrecord['apk']['sha256'],script_sha256=h.sha(__file__),fixture_sha256=h.digest(value),stable_plan_source_files=paths,started_ns=time.time_ns(),limits='Explicit own emulator layout fixture replacing own test preferences. Not a real-user journey, migration or acoustic result. Meaning still requires actual UI tab selection. System font settings are not changed here.')
h.write_json(ledger/'event.json',record)
try:
    a.shell('am','force-stop','ru.liturgyguide')
    a.shell('run-as','ru.liturgyguide','mkdir','-p','shared_prefs')
    args=[str(adb),'-s','emulator-5554','shell','run-as','ru.liturgyguide','sh','-c',shlex.quote('cat > shared_prefs/guide_preferences.xml')]
    p=subprocess.run(args,input=value,capture_output=True,timeout=30)
    (ledger/'write.stdout').write_bytes(p.stdout);(ledger/'write.stderr').write_bytes(p.stderr);assert p.returncode==0
    observed=a.run('exec-out','run-as','ru.liturgyguide','cat','shared_prefs/guide_preferences.xml')
    (ledger/'readback.xml').write_bytes(observed);assert observed==value
    (ledger/'launch.txt').write_bytes(a.run('shell','am','start','-W','-n','ru.liturgyguide/.ui.MainActivity'))
    h.verify_installed(a,manifest['package'],runrecord['apk']['sha256']);record['status']='RECORDED'
except Exception as e:
    record['status']='FAIL';record['error']=repr(e);raise
finally:
    record['finished_ns']=time.time_ns();h.write_json(ledger/'completion.json',record)
print(json.dumps({'status':record['status'],'ledger':str(ledger),'fixture_sha256':record['fixture_sha256'],'kind':kind}))
