from pathlib import Path
import json,subprocess,sys
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
run=repo/'app/build/verification/v0.6/s33-reader-native'
manifest=json.loads((run/'manifest.json').read_text())
def call(script,*args):
    subprocess.run([sys.executable,'/private/tmp/'+script,*map(str,args)],check=True)
for kind in ['wait','before','meaning','missing','end']:
    print('Preparing '+kind,flush=True)
    call('feoria-v06-reader-fixture.py',run,kind,'light',0)
    call('feoria-v06-native.py','show',run,kind)
    expected=next(x['expected'] for x in manifest['cases'] if x['id']==kind)
    arrival=([{'text':'Миром Господу помолимся'},{'text':'На паузе'},{'content-desc':'Двигать текст'}] if kind=='meaning' else expected)
    call('feoria-v06-native.py','tap',run,kind,json.dumps({'text':'Сохраненное чтение'},ensure_ascii=False),json.dumps(arrival,ensure_ascii=False))
    if kind=='meaning':
        call('feoria-v06-native.py','tap',run,kind,json.dumps({'text':'Смысл'},ensure_ascii=False),json.dumps(expected,ensure_ascii=False))
    call('feoria-v06-native.py','capture',run,kind)
    print('Captured '+kind+'; human review still required',flush=True)
