# Preflight native reader fixture

Вердикт: ACCEPT_WITH_CONDITIONS. Схема и ограниченный сценарий подходят для layout PNG; перед первым использованием нужны две небольшие проверки происхождения bytes

Скрипт прочитан, не запускался. Прочитан helper load_run/verify_installed; adb/Gradle и изменения репозитория не выполнялись

Контекст MANUAL/null start, parish/date/zone согласованы. В snapshot вложенный context сериализован строкой, version/contentVersion/fingerprint/index взяты из закрепленной таблицы. Offset 1234 допустим для Text с минимальной длительностью 4000 ms; Wait/Missing/End получают 0. Marker указывает тот же stage, autoAdvance=false/elapsed 0; restore остается paused. Meaning намеренно тот же Text и требует реального выбора вкладки после Resume

Команды ограничены emulator-5554, собственным package ru.liturgyguide с debuggable=true и проверенным установленным SHA. force-stop предшествует записи, run-as ограничивает доступ данными этого приложения; shell redirection - фиксированная строка без пользовательской интерполяции, XML передается stdin. Широкого удаления, su, изменения системных настроек или установки чужого пакета нет. Полная замена prefs здесь явно объявлена, поэтому это допустимая тестовая fixture, а не сохранение пользовательских настроек

Два условия перед применением `/private/tmp/feoria-v06-reader-fixture.py`:

1. Перед чтением zip проверить SHA локального `runrecord['apk']['path']` против `runrecord['apk']['sha256']`. load_run с adb сверяет установленный пакет, но не содержимое локального APK по переиспользуемому пути. Пока локальные bytes не проверены, нельзя автоматически приписывать их asset установленной сборке
2. SHA `planroot/liturgy_stages.json` и `daily_readings.json` сверить с зафиксированными входами oldbuild либо producer 3.2, затем сравнивать actual APK assets. Сейчас таблица закреплена SHA, но ее соседние asset файлы проверяются только на равенство APK. Если эти два mutable файла обновятся вместе, старая таблица останется прежней, а guard не обнаружит несоответствие ее входам

Это проверки до мутации, не новая инфраструктура. Проверка шести исходников parser/factory/plan/models и pinned table SHA полезна и должна остаться

Exact XML readback доказывает запись fixture bytes до старта, но не саму успешную загрузку приложением. После start обязательны видимый Resume, нужные state/дата/режим, затем case XML/PNG; если приложение отвергнет snapshot или восстановит иной файл SharedPreferences, нельзя принимать только prelaunch readback. Не считать start command exit 0 доказательством нужного экрана

Фиксированный session timestamp может давать stale notice по реальным часам; это часть fixture, не естественная пользовательская история. Все шесть состояний начинают paused, поэтому отдельный playing кадр требует настоящего Play. System font не меняется скриптом и подтверждается отдельными observed facts

Только layout fixture: не upgrade, не навигационный путь пользователя, не proof сохранения старых prefs, не акустика. Двенадцать PNG показывают состояния/темы, но сами не доказывают переходы, keep-awake или сохранность данных. Следует сохранять event STARTED/FAIL/RECORDED и полный readback, не превращать fixture completion в функциональный PASS

## Закрытие delta preflight

Окончательный вердикт: ACCEPT

Точечно перечитан обновленный script: строки10-11 закрепляют literal SHA старого build receipt и producer, строка50 проверяет локальный APK против runrecord, строка53 связывает planroot assets с входами закрепленного build. Прежняя строка54 далее сравнивает actual APK bytes с этими проверенными assets. Pinned table и проверки исходников сохранены

Все четыре добавленные проверки выполняются до force-stop, записи prefs и запуска приложения. Два замечания происхождения bytes устранены, новых условий не добавляю. Скрипт не запускался в этом review, повторный dry-run принадлежит root. Preflight разрешает использовать fixture в ранее ограниченной роли layout preparation, без автоматической приемки будущих native кадров
