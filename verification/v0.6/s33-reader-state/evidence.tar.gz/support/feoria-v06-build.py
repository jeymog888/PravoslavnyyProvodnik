# coding: utf-8
"""Root-only serialized build/test receipt. Does not assign UI or native acceptance."""
from pathlib import Path
import importlib.util,os,json,sys,shutil,subprocess,re,xml.etree.ElementTree as E
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
t=Path('/private/tmp/liturgy-android-toolchain')
assert len(sys.argv)>=3, 'name task... required'
name=sys.argv[1];assert name.replace('-','').replace('_','').isalnum()
tasks=sys.argv[2:]
os.environ.update(JAVA_HOME=str(t/'jdk-17.0.21+9/Contents/Home'),GRADLE_USER_HOME=str(t/'gradle-home'),ANDROID_HOME=str(t/'sdk'),ANDROID_USER_HOME=str(t/'android-user'),ANDROID_AVD_HOME=str(t/'android-user/avd'),ANDROID_SERIAL='emulator-5554')
key=repo/'.local/android/debug.keystore'
for k,v in {'store.file':str(key),'store.password':'android','key.alias':'androiddebugkey','key.password':'android'}.items():os.environ['ORG_GRADLE_PROJECT_android.injected.signing.'+k]=v
s=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
out=repo/'app/build/verification/v0.6'/name
extra=[key]+[p for d in ['test','androidTest'] for p in (repo/'app/src'/d).rglob('*') if p.is_file()]
kind='release' if 'assembleRelease' in tasks else 'debug'
if 'assemble'+kind.title() not in tasks:tasks=['assemble'+kind.title()]+tasks
diagnosticPrefix='-Pandroid.testInstrumentationRunnerArguments.feoriaCiDiagnosticsRun='
diagnosticIds=[task[len(diagnosticPrefix):] for task in tasks if task.startswith(diagnosticPrefix)]
assert len(diagnosticIds)<=1
diagnosticPrep=[]
diagnosticRemote=None
if diagnosticIds:
 diagnosticId=diagnosticIds[0]
 assert re.fullmatch(r'[A-Za-z0-9_-]{1,100}',diagnosticId)
 diagnosticRemote='/data/local/tmp/feoria-ci-diagnostics/'+diagnosticId
 for args in [('shell','mkdir','-p','/data/local/tmp/feoria-ci-diagnostics'),('shell','mkdir',diagnosticRemote)]:
  proc=subprocess.run([str(t/'sdk/platform-tools/adb'),'-s','emulator-5554',*args],capture_output=True,timeout=20)
  diagnosticPrep.append({'command':list(args),'exit_code':proc.returncode,'stdout':proc.stdout.decode(errors='replace'),'stderr':proc.stderr.decode(errors='replace')})
  assert proc.returncode==0, 'Diagnostic destination must be fresh and writable: '+str(diagnosticPrep[-1])
build_error=None
try:
 r=h.build_receipt(repo,repo/f'app/build/outputs/apk/{kind}/app-{kind}.apk',out,kind,['--no-daemon','--console=plain']+tasks,str(t/'sdk/build-tools/34.0.0/aapt'),str(t/'sdk/build-tools/34.0.0/apksigner'),extra_inputs=extra)
except Exception as error:
 build_error=error
 if not (out/"build.json").exists():raise
 r=json.loads((out/"build.json").read_text())
if diagnosticRemote:
 (out/'diagnostic-preparation.json').write_text(json.dumps(diagnosticPrep,indent=2))
 proc=subprocess.run([str(t/'sdk/platform-tools/adb'),'-s','emulator-5554','pull',diagnosticRemote,str(out/'ui-diagnostics')],capture_output=True,timeout=30)
 (out/'diagnostic-export.json').write_text(json.dumps({'remote':diagnosticRemote,'exit_code':proc.returncode,'stdout':proc.stdout.decode(errors='replace'),'stderr':proc.stderr.decode(errors='replace'),'complete_packets':len(list((out/'ui-diagnostics').rglob('.complete'))),'limits':'Empty export does not prove no test failure; result XML and capture status remain authoritative'},indent=2))
summaries={}
for label,folder,requested in [('unit',repo/'app/build/test-results/testDebugUnitTest','testDebugUnitTest' in tasks),('ui',repo/'app/build/outputs/androidTest-results/connected/debug','connectedDebugAndroidTest' in tasks)]:
 if not requested:continue
 log=(out/'build.log').read_text()
 task_name='testDebugUnitTest' if label=='unit' else 'connectedDebugAndroidTest'
 task_ran=('> Task :app:'+task_name) in log
 if not task_ran:
  summaries[label]={'status':'NOT_RUN','reason':'No task execution marker in this build log; older result XML is ignored'}
  continue
 if folder.exists():
  shutil.copytree(folder,out/(label+'-results'))
  total={k:0 for k in ['tests','failures','errors','skipped']}
  for p in folder.rglob('TEST-*.xml'):
   root=E.parse(p).getroot()
   for k in total:total[k]+=int(root.get(k,'0'))
  summaries[label]=total
(out/'test-summary.json').write_text(json.dumps({'requested_tasks':tasks,'results':summaries,'limits':'Result XML copied only for requested test task; inspect Gradle log for executed versus up-to-date'},indent=2))
print(json.dumps({'status':r['status'],'source':r['source'],'apk_sha256':r.get('apk',{}).get('sha256'),'tests':summaries}))
if build_error is not None:raise build_error
assert r['status']=='PASS' and r['inputs_before']==r['inputs_after']
assert all(v.get('failures')==0 and v.get('errors')==0 for v in summaries.values())
