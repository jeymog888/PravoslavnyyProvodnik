# Реализация 3.3 - состояния читателя

Реализация передана для root/Astra review и последующей проверки. Gradle, adb и git-коммиты implementer/QA не запускали; новый код и тесты пока не считаются PASS

## Что изменилось

- Новый чистый `ReaderPresentation.kt` вычисляет kind/status/primaryAction/primaryLabel по принятому `ActiveServicePlayback` и представлению Meaning. Не хранит отдельную позицию, таймер или признак движения
- `ServiceScreen` показывает один основной footer action во всех шести состояниях. Status отделен от действия, Text/Wait/BeforeStart имеют отдельное "Без звука"
- BeforeStart показывает наблюдаемый возглас следующего `beginning` и "Литургия началась". Если расчет уже включен, есть явная вторичная "Пауза". Нет обычного Play или обещания срока начала
- Text называет действие "Двигать текст"/"Пауза". Wait называет действие "Продолжить по времени"/"Пауза", отличает включенный и остановленный переход и показывает cue следующего этапа. Последний Wait предлагает слушать заключительные молитвы, не обещает еще один этап
- Meaning показывает паузу и один возврат "К тексту"/"К ходу службы". Возврат останавливает реальный player и снимает только `meaning`; `preferredOriginal` не меняется. При промежуточном live-playing входе pure presenter честно сообщает об остановке, эффект завершает pause
- Missing определяется только по `PlaybackSegment.MissingReading`, не по отсутствию Scripture на всем этапе. Основное действие подтверждает окончание чтения в храме, передает существующий `continueAfterMissing(generation)` и остается единственным путем в footer
- End говорит о конце порядка в приложении и имеет один "Закончить чтение". Disabled Play и дубликаты Missing/End удалены
- Все основные callbacks проверяют generation; возврат/завершение и переход начала после pause проверяют ее повторно. Формула времени, engine, store, assets и идентификаторы не менялись
- В compact сохранены видимые названия main action. Убраны две вторичные кнопки (предыдущая фраза/предыдущий этап), доступ к ним остается через текст и порядок. В уже определенном landscape status и "Без звука" стоят рядом с управлением в той же строке, чтобы новая статусная строка не забрала еще высоту у чтения. Новые font caps или уменьшения SP не добавлены
- Три прежних темпа сохранены. Диалог различает изменение скорости и разовое исправление позиции

## Самопроверка

Подтвержденный прежний дефект: preparation показывался как обычный playable Wait, а Missing/End сохраняли главное disabled Play плюс дубли переходов. Это исправлено. Дополнительный дефект новой реализации не придумывался для отчета

Прочитаны новый вычислитель, все ветви primary/status, retained-text поведение, контракты `ServicePlayerState`/engine и связанные existing UI тесты. Проверены риски: introductory Text при отсутствующем дневном чтении; сохранение original после Meaning; следующий cue вместо текущего; последняя Wait без следующего этапа; актуальный pause status; stale generation; единственный первичный шаг. Полностью прочитаны 8 новых unit, 8 новых UI и diff всех 10 обновленных UI suites. Exact date/offset/speed, huge tick, lifecycle/top-resumed, отказ writer, stale callbacks и прежние 120dp/48dp/отсутствие clipping сохранены. `git diff --check` чистый

Крупная оболочка, снятие прежних caps, единая много-track лента, keep-awake и микрофон не входят в эту порцию. Достаточность доступной высоты и визуальный результат нельзя считать принятыми до нативных проверок root


## Замечания перед freeze

- Root справедливо отметил риск добавления ~24dp вертикального footer в прежнем landscape. Это статический риск, не измеренный дефект: сделан минимальный inline status fit без изменения размеров текста. Root проверит фактическую геометрию; assertions 120dp не снижены
- В Missing убрана привязка инструкции к "кнопке внизу", чтобы текст описывал действие независимо от последующего адаптивного расположения управления
- QA дополнительно явно проверяет introductory Text до missing barrier, последний Wait до End и возвращение из Meaning перед общим переходом этапа

## Тесты для root

Новые unit: `ru.liturgyguide.ui.ReaderPresentationTest` - 8 методов

Основная UI-группа:

- `ru.liturgyguide.ui.ReaderStateFlowTest` - 8 новых методов, real ServicePlayerState, управляемые clock/writer и реальные UI callbacks
- `ru.liturgyguide.ui.UnifiedPlayerFlowTest`
- `ru.liturgyguide.ui.ReaderAccessibilityTest`
- `ru.liturgyguide.ui.CompactReaderMatrixTest`
- `ru.liturgyguide.ui.GuideNavigationTest`

Смежные измененные UI suites:

- `ru.liturgyguide.ui.FirstVisitFlowTest`
- `ru.liturgyguide.ui.ArrivalFlowTest`
- `ru.liturgyguide.ui.ManualMomentFlowTest`
- `ru.liturgyguide.ui.SavedReadingTest`
- `ru.liturgyguide.ui.Published05PlaybackIntegrationTest`
- `ru.liturgyguide.ui.ExhaustedServiceEntryTest`

Новые UI методы обернуты `withCiFailureDiagnostics`; для получения пакета отказа root использует оба аргумента harness (`feoriaCiDiagnostics=true` и `feoriaCiDiagnosticsRun=...`). Полный unrelated UI набор до этапа 6 не требуется этой порцией

## Границы проверки

Assets текущего и опубликованного 0.5, timing/plan/engine/store, fingerprint/golden fixtures не изменены. Root-owned `verification/v0.6/reader-baseline/` не входит в freeze implementer. Полное визуальное принятие, языковая оболочка/шрифты и большой текст остаются последовательными 3.4/3.5/3.5a, однако уже существующие геометрические требования не ослаблены


## Финальный SOURCE FREEZE

14 файлов (2 runtime, 12 test). Все SHA QA manifest сверены с диском, общий manifest: `/private/tmp/feoria-v06-reader-state-freeze.json`

Aggregate SHA-256: `97ac3210683877bf68554585468010afdbbe41636400fcc98591521231efccad`

QA-отчет: `/private/tmp/feoria-v06-reader-qa.md`, read-only existing diff: `/private/tmp/feoria-v06-reader-qa-existing.diff`

В промежуточном QA self-review найдена и исправлена реальная неверная адаптация старого assertion: FirstVisit и corrupt-snapshot restart открывают BeforeStart, поэтому ожидание обычного Text Play было заменено на точный `start_liturgy` + статус подготовки + отсутствие Play. Это исправление тестового контракта, не дополнительная ошибка timing engine

После manifest implementer и QA не меняют исходники без нового явного старта root
