# coding: utf-8
"""Root-only supplemental observer over the repository's strict APK/window harness."""
from pathlib import Path
import importlib.util,json,sys,time
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
a=h.Adb(Path('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb'),'emulator-5554')
command=sys.argv[1];run=Path(sys.argv[2]);args=sys.argv[3:]
if command=='begin':
 r=h.begin_run(args[0],args[1],run,a);print(json.dumps({'run_id':r['run_id'],'apk_sha256':r['apk']['sha256']}));sys.exit()
_,record,manifest=h.load_run(run,a)
if command=='capture':
 result=h.capture_case(run,a,args[0],timeout=20)
 print(json.dumps({key:result.get(key) for key in ['run_id','case_id','status','visual_status','apk_sha256','manifest_sha256']}));sys.exit()
if command=='tap':print(json.dumps(h.tap(run,a,args[0],json.loads(args[1]),json.loads(args[2]),timeout=20)));sys.exit()
if command=='review':print(json.dumps(h.review_case(run,args[0],'root',args[1],args[2])));sys.exit()
if command=='finish':
 result=h.aggregate(run);h.write_json(run/'gate.json',result);print(json.dumps(result));sys.exit()
ledger=run/'supplemental'/str(time.time_ns());ledger.mkdir(parents=True)
event={'command':command,'args':args,'run_id':record['run_id'],'apk_sha256':record['apk']['sha256'],'status':'ERROR','started_ns':time.time_ns(),'verdict':'RAW_OBSERVATION'}
h.write_json(ledger/'event.json',event)
try:
 if command=='setup':
  # These arguments are explicit root instructions for this own test device, not app content.
  output=a.run(*args,timeout=30);(ledger/'stdout').write_bytes(output)
  print(output.decode(errors='replace')[:1200])
 elif command=='prefs':
  output=a.run('exec-out','run-as','ru.liturgyguide','cat','shared_prefs/guide_preferences.xml');(ledger/'preferences.xml').write_bytes(output)
  print(json.dumps({'path':str(ledger/'preferences.xml'),'sha256':h.sha(ledger/'preferences.xml')}))
 elif command in ('show','scroll'):
  case=h.case_by_id(manifest,args[0]);package=case.get('window_package',manifest['package']);allowed=case.get('allowed_windows',[])
  before=a.view(package,allowed);(ledger/'before.xml').write_bytes(before.xml);(ledger/'windows.txt').write_text(before.windows);(ledger/'displays.txt').write_text(before.displays)
  if command=='scroll':
   panes=[h.bounds(n,before.size) for n in before.nodes if n.get('scrollable')=='true']
   h.require(len(panes)==1,'Exactly one observed scrollable pane required')
   x1,y1,x2,y2=panes[0];x=(x1+x2)//2;low=y1+(y2-y1)*3//4;high=y1+(y2-y1)//4
   h.require(args[1] in ('up','down'),'Explicit direction required')
   ys=(low,high) if args[1]=='up' else (high,low)
   a.shell('input','swipe',str(x),str(ys[0]),str(x),str(ys[1]),'350')
   after=h.wait_for(a,package,json.loads(args[2]),allowed,20);(ledger/'after.xml').write_bytes(after.xml)
  else:after=before
  print(json.dumps([{'text':n.get('text'),'desc':n.get('content-desc'),'selected':n.get('selected'),'bounds':n.get('bounds')} for n in after.nodes if n.get('text') or n.get('content-desc')],ensure_ascii=False))
 else:raise ValueError('Unknown command')
 h.verify_installed(a,manifest['package'],record['apk']['sha256'])
 event['status']='RECORDED'
except Exception as e:
 event['error']=str(e);raise
finally:
 event['finished_ns']=time.time_ns();h.write_json(ledger/'completion.json',event)
