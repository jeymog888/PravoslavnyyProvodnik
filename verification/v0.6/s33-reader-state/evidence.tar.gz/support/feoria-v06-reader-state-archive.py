#!/usr/bin/env python3
"""Archive completed 3.3 evidence. No waits, Gradle, adb, or test execution."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET

sys.dont_write_bytecode = True
REPO = Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
TMP = Path('/private/tmp')
ROOTS = ('s33-reader-state-r1', 's33-reader-state-r2', 's33-reader-native')
SOURCE = 'app/src/main/java/ru/liturgyguide/ui/ServiceScreen.kt'
OLD = '448b791db8b272762d75aeb9fd502bb6dfe55e9b2a8b726310889327a509af26'
NEW = '9b208da3507f19990214c081aba29117651cd231a886a0d9b369546c11390504'
HARNESS_SHA = '83fd3348250f02ee4274790a9aa1a345a9fce3016b568f9d11a9b63281d4a614'
FIXTURE_SHA = '77f798e5b3d49e685dc9af09544dabfdf9180edab30872b189327ad0b80fd218'
MANIFEST_SHA = '8f7c2d2f999ab5aa29332187bb6410a33c7a1b63f99c0e6d4cc9d582033f3f63'
FAIL_ID = 'ru.liturgyguide.ui.ReaderStateFlowTest#capturedBeginningContinuationAndFinishCannotChangeAReplacementReading'
R2_SUITES = {'ru.liturgyguide.ui.' + name for name in (
    'ReaderStateFlowTest', 'UnifiedPlayerFlowTest', 'CompactReaderMatrixTest', 'ReaderAccessibilityTest')}
NATIVE_CASES = {'text', 'wait', 'before', 'meaning', 'missing', 'end'}
SUPPORT_NAMES = (
    'feoria-v06-reader-state-freeze-before-copy.json', 'feoria-v06-reader-state-freeze-r1.json',
    'feoria-v06-reader-state-freeze.json', 'feoria-v06-reader-state-code-review.md',
    'feoria-v06-reader-state-correction-review.md', 'feoria-v06-reader-state-implementation.md',
    'feoria-v06-reader-qa.md', 'feoria-v06-reader-qa-freeze.json', 'feoria-v06-reader-qa-existing.diff',
    'feoria-v06-reader-state-failure.md', 'feoria-v06-reader-state-qa-failure.md',
    'feoria-v06-reader-clickable-javap.txt', 'feoria-v06-reader-clickable-legacy-javap.txt',
    'feoria-v06-reader-state-primary-fix.diff', 'feoria-v06-reader-ServiceScreen-r1.kt',
    'feoria-v06-reader-root-brief.md', 'feoria-v06-reader-state-exploration.md',
    'feoria-v06-reader-state-test-map.md', 'feoria-v06-reader-fixture.py',
    'feoria-v06-reader-fixture-review.md', 'feoria-v06-reader-state-manifest.json',
    'feoria-v06-reader-state-root-preflight.json', 'feoria-v06-reader-state-archive-qa-checklist.md',
    'feoria-v06-reader-state-archive-review.md', 'feoria-v06-reader-state-native-cases.py',
    'feoria-v06-reader-state-native-review.md', 'feoria-v06-reader-state-root-results.md',
    'feoria-v06-native.py', 'feoria-v06-build.py')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            need(key not in result, 'Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=unique)


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode()).hexdigest()


def file_map(entries):
    result = {item['path']: item['sha256'] for item in entries}
    need(len(result) == len(entries), 'Duplicate input paths')
    return result


def read_build(root, expected_status):
    value = strict_json(root / 'build.json')
    need(value['status'] == expected_status, str(root) + ': unexpected build status')
    need(value['kind'] == 'build' and value['schema'] == 1, 'Unexpected build schema')
    need(value['exit_code'] == (1 if expected_status == 'FAIL' else 0), 'Unexpected Gradle exit')
    need(value['started_ns'] < value['finished_ns'], 'Unfinished build receipt')
    need(value['inputs_before'] == value['inputs_after'], 'Inputs changed during build')
    need(digest(value['inputs_before']['files']) == value['inputs_before']['sha256'], 'Invalid input fingerprint')
    need(sha(root / 'build.log') == value['log_sha256'], 'Build log changed')
    need(value['harness_sha256'] == HARNESS_SHA, 'Unreviewed harness version')
    return value, file_map(value['inputs_before']['files'])


def results(root, kind):
    cases = {}
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    paths = sorted((root / (kind + '-results')).rglob('TEST-*.xml'))
    need(paths, str(root) + ': missing ' + kind + ' XML')
    for path in paths:
        for case in ET.parse(path).getroot().iter('testcase'):
            name, method = case.get('classname'), case.get('name')
            need(name and method, 'Testcase identity missing')
            identity = name + '#' + method
            need(identity not in cases, 'Duplicate testcase: ' + identity)
            flags = [case.find(tag) is not None for tag in ('failure', 'error', 'skipped')]
            need(sum(flags) <= 1, 'Ambiguous testcase verdict: ' + identity)
            status = next((label for label, present in zip(('FAIL', 'ERROR', 'SKIP'), flags) if present), 'PASS')
            cases[identity] = {'run': root.name, 'status': status, 'xml': str(path.relative_to(root))}
            totals['tests'] += 1
            for key, present in zip(('failures', 'errors', 'skipped'), flags):
                totals[key] += int(present)
    return cases, totals


def freeze(path):
    value = strict_json(path)
    entries = value['files']
    need(len(entries) == 14, 'Unexpected freeze scope')
    calculated = hashlib.sha256(''.join(x['path'] + '\t' + x['sha256'] + '\n' for x in entries).encode()).hexdigest()
    need(calculated == value['aggregateSha256'], 'Freeze aggregate mismatch')
    need(entries == sorted(entries, key=lambda x: x['path']), 'Freeze order changed')
    return value, file_map(entries)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=REPO)
    args = parser.parse_args()
    repo = args.repo.resolve()
    base = repo / 'app/build/verification/v0.6'
    out = repo / 'verification/v0.6/s33-reader-state'
    roots = [base / name for name in ROOTS]
    # Fail immediately, without polling or writing an incomplete archive.
    required = [TMP / name for name in SUPPORT_NAMES]
    required += [p / 'build.json' for p in roots]
    required += [roots[0] / 'test-summary.json', roots[1] / 'test-summary.json',
                 roots[2] / 'run.json', roots[2] / 'manifest.json', roots[2] / 'gate.json']
    missing = [str(p) for p in required if not p.is_file()]
    need(not missing, 'NOT_READY: missing completed evidence: ' + ', '.join(missing))

    builds = [read_build(p, status) for p, status in zip(roots, ('FAIL', 'PASS', 'PASS'))]
    (b1, m1), (b2, m2), (bn, mn) = builds
    need(b1['finished_ns'] <= b2['started_ns'], 'Builds were not serialized')
    need(set(m1) == set(m2), 'Build input paths changed')
    changed = {p: (m1[p], m2[p]) for p in m1 if m1[p] != m2[p]}
    need(changed == {SOURCE: (OLD, NEW)}, 'Unapproved r1 -> r2 delta: ' + str(changed))
    need(mn == m2, 'Native build differs from r2, including external inputs')
    need(b2['apk'] == bn['apk'], 'Native and r2 APK identity differ')
    need(sha(Path(b2['apk']['path'])) == b2['apk']['sha256'], 'Current APK differs from completed r2')

    old_freeze, old_hashes = freeze(TMP / 'feoria-v06-reader-state-freeze-r1.json')
    final_freeze, final_hashes = freeze(TMP / 'feoria-v06-reader-state-freeze.json')
    need(set(old_hashes) == set(final_hashes), 'Freeze paths changed')
    need({p: (old_hashes[p], final_hashes[p]) for p in old_hashes if old_hashes[p] != final_hashes[p]}
         == {SOURCE: (OLD, NEW)}, 'Unapproved freeze delta')
    for entry in final_freeze['files']:
        p = repo / entry['path']
        need(p.is_file() and not p.is_symlink() and sha(p) == entry['sha256'] and p.stat().st_size == entry['bytes'],
             'Frozen source changed: ' + entry['path'])
    old_source = TMP / 'feoria-v06-reader-ServiceScreen-r1.kt'
    need(sha(old_source) == OLD, 'r1 source copy changed')
    source_text = (repo / SOURCE).read_text()
    start = source_text.index('                    key(generation) {\n                        Button(onClick = onPrimary,')
    end = source_text.index('                    if (text) IconButton', start)
    lines = source_text[start:end].splitlines(keepends=True)
    need(lines[-1] == '                    }\n' and all(line.startswith('    ') for line in lines[1:-1]), 'Unexpected key-wrapper body')
    restored = source_text[:start] + ''.join(line[4:] for line in lines[1:-1]) + source_text[end:]
    need(restored.encode() == old_source.read_bytes(), 'Source delta is more than the approved key(generation) wrapper')

    harness_path = repo / 'scripts/harness/feoria_harness.py'
    need(sha(harness_path) == HARNESS_SHA, 'Harness changed')
    spec = importlib.util.spec_from_file_location('s33_archive_harness', harness_path)
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)  # Import only; no CLI or adb call.
    production = {p: value for p, value in m2.items() if not p.startswith('external/')}
    need(file_map(harness.source_fingerprint(repo)['files']) == production,
         'Current production file set/bytes differ from r2 (including untracked files)')
    external_by_name = {}
    for path, value in m2.items():
        if path.startswith('external/'):
            external_by_name.setdefault(Path(path).name, []).append(value)
    test_bindings = []
    for folder in ('app/src/test', 'app/src/androidTest'):
        for p in sorted((repo / folder).rglob('*')):
            if not p.is_file():
                continue
            need(not p.is_symlink() and external_by_name.get(p.name) == [sha(p)],
                 'Test input missing, ambiguous, or changed after build: ' + str(p))
            test_bindings.append({'path': str(p.relative_to(repo)), 'sha256': sha(p)})
    for path, value in final_hashes.items():
        need(m2.get(path, (external_by_name.get(Path(path).name) or [None])[0]) == value,
             'Freeze is not bound to build input: ' + path)

    unit, unit_totals = results(roots[0], 'unit')
    ui1, totals1 = results(roots[0], 'ui')
    ui2, totals2 = results(roots[1], 'ui')
    need(unit_totals == dict(tests=421, failures=0, errors=0, skipped=0), 'Unexpected r1 unit results')
    need(totals1 == dict(tests=123, failures=1, errors=0, skipped=0), 'Unexpected r1 UI results')
    need([key for key, value in ui1.items() if value['status'] != 'PASS'] == [FAIL_ID], 'r1 failure changed')
    need(totals2 == dict(tests=37, failures=0, errors=0, skipped=0), 'Unexpected r2 UI results')
    need(set(ui2) == {key for key in ui1 if key.split('#')[0] in R2_SUITES}, 'r2 scenario coverage changed')
    need(FAIL_ID in ui2, 'Original failing case was not rerun')
    summary1, summary2 = [strict_json(p / 'test-summary.json') for p in roots[:2]]
    need(summary1['results']['unit'] == unit_totals and summary1['results']['ui'] == totals1, 'r1 summary/XML mismatch')
    need(summary2['results']['ui'] == totals2, 'r2 summary/XML mismatch')
    need(re.search(r'^> Task :app:testDebugUnitTest\s*$', (roots[0] / 'build.log').read_text(), re.M), 'r1 unit task was not executed')
    need(not any(x.split(':')[-1] == 'testDebugUnitTest' for x in b2['command']), 'r2 unexpectedly requested unit tests')
    need(not list((roots[1] / 'unit-results').rglob('TEST-*.xml')), 'Stale unit XML appeared in r2')
    need(not isinstance(summary2['results'].get('unit'), dict) or summary2['results']['unit'].get('tests', 0) == 0,
         'r2 summary falsely claims unit rerun')
    latest = {**ui1, **ui2}
    need(len(latest) == 123 and all(v['status'] == 'PASS' for v in latest.values()), 'Latest UI coverage incomplete')
    diagnostic = strict_json(roots[0] / 'diagnostic-export.json')
    need(diagnostic['exit_code'] == 0 and diagnostic['complete_packets'] == 1, 'Original failure packet is incomplete')
    packets = list((roots[0] / 'ui-diagnostics').glob('*/capture.json'))
    need(len(packets) == 1 and (packets[0].parent / '.complete').is_file(), 'Original diagnostic packet missing')
    need((packets[0].parent / 'screen.png').is_file(), 'Original failure PNG missing')

    preflight = strict_json(TMP / 'feoria-v06-reader-state-root-preflight.json')
    need(preflight['tests'] == 'NOT_RUN' and preflight['status'] == 'ENVIRONMENT_PREPARATION_FAILED', 'Pre-Gradle environment event was reclassified')
    need(sha(TMP / 'feoria-v06-reader-fixture.py') == FIXTURE_SHA, 'Native fixture helper changed')
    need(sha(TMP / 'feoria-v06-reader-state-manifest.json') == MANIFEST_SHA, 'Native planned manifest changed')
    # begin_run normalizes JSON whitespace; compare data and preserve both exact byte hashes.
    need(strict_json(roots[2] / 'manifest.json') == strict_json(TMP / 'feoria-v06-reader-state-manifest.json'),
         'Native manifest differs from the reviewed plan')
    recomputed_gate = harness.aggregate(roots[2])  # Local artifact validation only; no adb parameter.
    stored_gate = strict_json(roots[2] / 'gate.json')
    for gate in (recomputed_gate, stored_gate):
        need(gate['status'] == 'PASS' and gate['required_cases'] == gate['passed_cases'] == 6,
             'Native six-state gate not complete')
        need(set(gate['visual_reviews']) == NATIVE_CASES, 'Native visual reviews incomplete')
    need({**stored_gate, 'visual_reviews': sorted(stored_gate['visual_reviews'])} ==
         {**recomputed_gate, 'visual_reviews': sorted(recomputed_gate['visual_reviews'])}, 'Stored native gate changed')
    native_run = strict_json(roots[2] / 'run.json')
    need(native_run['started_ns'] >= b2['finished_ns'], 'Native run predates corrected build')

    plans = base / 's32-current-plans'
    pins = {'producer.json': 'c3d75c84a9b5eb5630800e84576c23b7bb270ac4f0723fa1bd2a7f6b89a52423',
            'published-plans.json': '6f06b7f710691b61ac630597622ad370439a246f5307aadb30ffea12d3ff94e1'}
    for name, value in pins.items():
        need(sha(plans / name) == value, 'Fixture plan provenance changed: ' + name)
    fixture_records = []
    for directory in sorted((roots[2] / 'supplemental').glob('fixture-*')):
        event = strict_json(directory / 'event.json')
        completion = strict_json(directory / 'completion.json')
        need(completion['run_id'] == native_run['run_id'] and completion['apk_sha256'] == b2['apk']['sha256'], 'Fixture run/APK mismatch')
        need(completion['script_sha256'] == FIXTURE_SHA and completion['plan_table_sha256'] == pins['published-plans.json']
             and completion['plan_producer_sha256'] == pins['producer.json'], 'Fixture helper/plan identity mismatch')
        need(event['status'] == 'STARTED' and event['fixture_sha256'] == completion['fixture_sha256'], 'Fixture event mismatch')
        need(sha(directory / 'preferences.xml') == completion['fixture_sha256'], 'Fixture bytes changed')
        if completion['status'] == 'RECORDED':
            need((directory / 'readback.xml').read_bytes() == (directory / 'preferences.xml').read_bytes(), 'Fixture readback mismatch')
        fixture_records.append(completion)
    need(fixture_records, 'No real native fixture records')
    for case_id in NATIVE_CASES:
        case = strict_json(roots[2] / 'cases' / case_id / 'case.json')
        previous = [r for r in fixture_records if r['finished_ns'] <= case['started_ns']]
        need(previous, 'Case has no preceding fixture: ' + case_id)
        active = max(previous, key=lambda r: r['finished_ns'])
        need(active['status'] == 'RECORDED' and active['kind'] == case_id and active['theme'] == 'light'
             and active['app_text_size'] == 0, 'Case fixture identity/conditions differ: ' + case_id)

    files = {}
    excluded = []
    def add(path, archive_name):
        need(path.is_file() and not path.is_symlink(), 'Not an ordinary evidence file: ' + str(path))
        need(not Path(archive_name).is_absolute() and '..' not in Path(archive_name).parts and archive_name not in files,
             'Unsafe or duplicate archive name: ' + archive_name)
        if path.suffix.lower() == '.apk':
            excluded.append({'path': archive_name, 'sha256': sha(path), 'reason': 'APK bytes excluded; receipt identity retained'})
            return
        files[archive_name] = {'source': path, 'sha256': sha(path), 'bytes': path.stat().st_size}
    for root in (*roots, plans):
        for path in sorted(root.rglob('*')):
            if path.is_file():
                add(path, str(path.relative_to(base)))
    add(base / 's32-content-r2/build.json', 'fixture-origin/s32-content-r2-build.json')
    need(sha(base / 's32-content-r2/build.json') == 'cdf2ef95524f87d8c8127671f1ff14b05ddc77d037cdf9cff17345c23b78f3da', 'Fixture origin build changed')
    for name in SUPPORT_NAMES:
        add(TMP / name, 'support/' + name)
    add(harness_path, 'support/feoria_harness.py')
    add(Path(__file__).resolve(), 'support/feoria-v06-reader-state-archive.py')
    for entry in final_freeze['files']:
        add(repo / entry['path'], 'source-final/' + entry['path'])

    coverage = {'uniqueScenarios': 123, 'latestResults': latest,
                'runs': {ROOTS[0]: totals1, ROOTS[1]: totals2}, 'originalFail': FAIL_ID,
                'latestProvenance': {ROOTS[0]: 86, ROOTS[1]: 37},
                'unit': {'run': ROOTS[0], 'totals': unit_totals, 'r2': 'NOT_RUN',
                         'limits': '421 unit executed on r1 before the sole key(generation) delta; not repeated on r2'},
                'environmentEvent': {'tests': 'NOT_RUN', 'artifact': 'support/feoria-v06-reader-state-root-preflight.json'},
                'limits': 'Latest union is not 123 tests repeated on r2. Native fixtures are layout evidence, not arrival, upgrade or acoustic tests.'}
    helper_manifest = {'harness': {'path': 'support/feoria_harness.py', 'sha256': HARNESS_SHA},
                       'fixture': {'path': 'support/feoria-v06-reader-fixture.py', 'sha256': FIXTURE_SHA},
                       'nativeManifest': {'path': 'support/feoria-v06-reader-state-manifest.json', 'sha256': MANIFEST_SHA,
                                          'normalizedRunCopySha256': sha(roots[2] / 'manifest.json')},
                       'nativeRunner': {'path': 'support/feoria-v06-reader-state-native-cases.py',
                                        'sha256': sha(TMP / 'feoria-v06-reader-state-native-cases.py')},
                       'archiveHelper': {'path': 'support/feoria-v06-reader-state-archive.py', 'sha256': sha(__file__)},
                       'fixturePlanPins': pins, 'testInputBindings': test_bindings,
                       'limits': 'External input hashes are equal between r1/r2/native. Private keystore bytes are never archived.'}
    names = ('evidence.tar.gz', 'archive.json', 'ui-coverage.json', 'helper-manifest.json', 'evidence-files.json')
    need(not any((out / name).exists() for name in names), 'Archive output already exists; never overwrite evidence')
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.s33-archive-', dir=out.parent) as staging:
        staging = Path(staging)
        archive = staging / names[0]
        with tarfile.open(archive, 'w:gz') as bundle:
            for name, item in sorted(files.items()):
                bundle.add(item['source'], arcname=name, recursive=False)
        with tarfile.open(archive, 'r:gz') as bundle:
            members = bundle.getmembers()
            need(len(members) == len(files) and {m.name for m in members} == set(files), 'Archive member set differs')
            for member in members:
                item = files[member.name]
                need(member.isfile() and not member.name.lower().endswith('.apk'), 'Unsafe archive member')
                data = bundle.extractfile(member).read()
                need(len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], 'Archived bytes differ: ' + member.name)
                need(sha(item['source']) == item['sha256'], 'Evidence changed while archiving: ' + member.name)
        inventory = [{'path': name, 'sha256': item['sha256'], 'bytes': item['bytes']} for name, item in sorted(files.items())]
        metadata = {'archive': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                    'files': len(files), 'roots': list(ROOTS), 'fixtureOrigin': plans.name,
                    'sourceDelta': {SOURCE: {'r1': OLD, 'r2Native': NEW, 'scope': 'Only key(generation) wrapper; reverse byte comparison passed'}},
                    'inputGroups': {'r1': b1['inputs_before']['sha256'], 'r2': b2['inputs_before']['sha256'], 'native': bn['inputs_before']['sha256']},
                    'nativeGate': recomputed_gate, 'excludedFiles': excluded,
                    'exclusionPolicy': 'No APK or keystore bytes; APK identities remain in build/run receipts. Failed r1 has no successful APK receipt.',
                    'limits': '421 unit only r1; latest UI union 123 from r1/r2, not a full corrected-source rerun. Six native light/normal/paused layout fixtures, no automatic accessibility or release-wide visual verdict.'}
        documents = {'archive.json': metadata, 'ui-coverage.json': coverage,
                     'helper-manifest.json': helper_manifest, 'evidence-files.json': inventory}
        for name, value in documents.items():
            (staging / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        out.mkdir(exist_ok=True)
        published = []
        try:
            for name in names:
                os.link(staging / name, out / name)  # Atomic creation, refuses overwriting any existing file.
                published.append(out / name)
        except Exception:
            for path in published:
                path.unlink()
            raise
        print(json.dumps({'status': 'ARCHIVED', 'output': str(out), **metadata}, ensure_ascii=False))


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'status': 'NOT_ARCHIVED', 'error': str(error)}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
