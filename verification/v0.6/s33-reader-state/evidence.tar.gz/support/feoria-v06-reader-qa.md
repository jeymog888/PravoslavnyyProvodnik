# QA 3.3 - представление состояний плеера

Локальная работа завершена, исходники тестов заморожены. Выполнение тестов остается root: Gradle, adb и git не запускались, production/assets не менялись. Это отчет о подготовке и статическом ревью, не результат PASS

## Новые проверки

- ReaderPresentationTest: 8 unit. Text paused/playing при всех скоростях и ненулевом offset, Wait с сохраненной фразой и без нее, final Wait отдельно от End, доступное вступление epistle перед отсутствующим дневным чтением, BeforeStart paused/playing, фиксированная дата Missing при Locale.US, End, приоритет Meaning над всеми состояниями и честное промежуточное сообщение пока runtime еще playing
- ReaderStateFlowTest: 8 UI, каждый с withCiFailureDiagnostics. Реальный ServiceScreen и ServicePlayerState с packaged assets; контролируются только часы и writer. Проверяются подпись/доступное имя/StateDescription, один основной action, отдельный статус и отсутствие звука, полная видимость action и минимум 48dp
- Text: реальное Play, смена языка без паузы, реальный Pause, 303 quarter-ms на SLOW после 101ms, отсутствие движения после больших часов
- Wait: честное объяснение продолжения службы и cue следующего этапа, действия остановленного/включенного перехода, сохранение context/speed/retained phrase, явный следующий этап paused
- BeforeStart: наблюдаемый cue и явное начало paused; отдельный сценарий уже playing подготовки, доступной остановки и отказа записи при начале
- Meaning: реальная остановка owner, отсутствие транспорта, возврат к той же оригинальной фразе с тем же offset/темпом после скрытого времени
- Missing: до преграды доходим реальным Play и огромным tick, затем сохраняются дата и paused barrier при Meaning/возврате/отказе writer; только успешное явное подтверждение открывает Gospel paused
- End: заключительный Wait не обещает другой этап, огромный tick останавливается на End, Meaning/возврат не завершают чтение, отдельный Finish вызывается ровно один раз
- Captured callbacks Begin/Continue/Finish после replacement с новой датой не меняют живое playing-чтение, не записывают состояние и не вызывают завершение

## Обновлены прежние ожидания

| Suite | Изменение |
| --- | --- |
| GuideNavigationTest | BeforeStart использует start_liturgy; Text действия описывают движение/паузу; Meaning возвращается отдельным действием; compact не требует убранный previous_line |
| UnifiedPlayerFlowTest | Сохранены 22500/85000/612500ms, offsets, lifecycle/top-resumed, обе Missing-преграды, recreation, date, bookmarks. Missing/End имеют единственный footer action без disabled Play и generic next. Геометрия перенесена с карточки на footer без ослабления видимости |
| ReaderAccessibilityTest | Явные наборы normal/compact/Meaning, status и primary label читаемы, >=48dp, отсутствие пересечений/clipping, >=120dp reading area сохранены. В BeforeStart проверяется доступный основной шаг |
| CompactReaderMatrixTest | После выбора track в Meaning нужен явный возврат перед next; прежние captured callbacks и paused details сохраняются |
| FirstVisitFlowTest | Точный context/дата/source/start остаются; preparation проверяется через собственные действие и статус |
| ArrivalFlowTest, ManualMomentFlowTest, SavedReadingTest, Published05PlaybackIntegrationTest, ExhaustedServiceEntryTest | Старые названия иконок заменены на действие Text с отдельным live status. Остальные фактические assertions неизменны |

## Самопроверка и пределы

Прочитан полный diff всех 10 прежних UI-файлов относительно копий до правки, сверены новые тесты с окончательным API и действиями ServiceScreen. Простая массовая замена старого Play обнаружила реальный дефект в промежуточных assertions: FirstVisit и corrupt-snapshot restart приходят в preparation, поэтому не могут требовать "Двигать текст"/"На паузе". Эти места исправлены на BeforeStart с проверкой отсутствия Play

Отдельно проверены все вызовы helper Published05.assertStored и Exhausted.assertAccepted: они действительно стоят на Text, включая консервативную миграцию прежнего Wait к последней опубликованной фразе. В качестве доказательства живой паузы не используется один лишь сохраненный snapshot. Новые UI-проверки обращаются к реальному owner и видимому статусу, прежние поведенческие сценарии дополнительно проверяют статус

Нет оставшихся assertions старых "Включить плеер"/"Остановить плеер", disabled Play или paused-статуса внутри line_status. wait_next_stage присутствует только в проверке отсутствия. Нет retries, sleeps, новых условных пропусков geometry или уменьшения 120dp. Тесты не исполнялись; компиляцию, runtime и реальные снимки подтверждает root

## Freeze

12 файлов: 2 новых + 10 обновленных UI suites. После этого manifest источники не изменяются без согласования

- Manifest: /private/tmp/feoria-v06-reader-qa-freeze.json
- Existing diff: /private/tmp/feoria-v06-reader-qa-existing.diff
- Aggregate SHA-256: f45b227a5037826d94cfc61149230b968e2cadef8b76321e240ad98eeea94ba0
