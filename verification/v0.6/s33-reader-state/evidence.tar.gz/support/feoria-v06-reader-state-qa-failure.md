# QA 3.3 - captured primary callback после replacement

Read-only диагностика одного FAIL. Source/tests не менялись, Gradle/adb/git не запускались

## Вывод

Гипотеза root подтверждается точным механизмом установленного Compose Foundation 1.7.3 и наблюдаемым отказом: захваченный SemanticsActions.OnClick ссылается на переиспользованный clickable node, который к моменту вызова уже хранит новый onClick. Поэтому старый callback не входит в старый generation guard, а вызывает новый primary PAUSE с новой generation

Минимальное предлагаемое исправление - key(generation) вокруг всего primary Button в ReaderFooter. После replacement создается другой clickable node; старый action остается на старом node/closure, где срабатывает уже существующая проверка generation. В рамках того же owner ключ не меняется при Play/Pause/Wait, поэтому не требуется пересоздавать кнопку на каждой смене подписи и терять ее идентичность для accessibility

Это предложение до исполнения проверки, а не утверждение PASS после патча. Тест сохраняется без ослабления

## Наблюдаемые факты

- Тест ReaderStateFlowTest.capturedBeginningContinuationAndFinishCannotChangeAReplacementReading, строки 186-211: захватывает action, принимает новое чтение creed с другой датой, вызывает реальный player.play(), дожидается idle, вызывает прежний action и требует прежнее playing-состояние без новых записей
- В harness часы остаются 1000ms; ServiceScreen не содержит playback ticking coroutine, Meaning не включался. Это не выход по времени из Text и не lifecycle pause от AppNavigation
- Log: app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderStateFlowTest-capturedBeginningContinuationAndFinishCannotChangeAReplacementReading.txt
- Log строки 167-184: expected ContentDescription=[Пауза], actual Node #17422 tag play_lyrics, bounds (147,2053)-(807,2200)px, ContentDescription=[Двигать текст], StateDescription=На паузе, Text=[Двигать текст]. Assertion падает на ReaderStateFlowTest.kt:204 -> assertPrimary:250
- ServiceScreen.kt:103-118 уже проверяет generation до dispatch. ReaderFooter.kt как отдельного файла нет: сам Button расположен в ServiceScreen.kt:378-385, общий для всех primaryAction; меняются tag/label/onPrimary, отдельного generation key пока нет

## Точный локальный bytecode

JAR: /private/tmp/liturgy-android-toolchain/gradle-home/caches/transforms-4/57091831924c5ba8a5216e782a279c14/transformed/foundation-release/jars/classes.jar

META-INF/androidx.compose.foundation_foundation.version = 1.7.3

SHA-256: 30ad4cfbb0cd76c75210223803d6d290eb80ee1183aa2608561be0614bab73e9

Javap выполнен локальным JDK 17; полный dump: /private/tmp/feoria-v06-reader-clickable-javap.txt

- Строки 2-24, AbstractClickableNode$applySemantics$1: поле this$0 хранит node; invoke читает this$0.getOnClick() и затем вызывает Function0.invoke. Старое значение onClick в callback не копируется
- Строки 771-793, AbstractClickableNode.applySemantics: регистрирует OnClick новой оберткой AbstractClickableNode$applySemantics$1(this)
- Строки 1084-1100, ClickableElement.update: передает текущий onClick в существующий ClickableNode.update
- Строки 1368-1378: ClickableNode.update делегирует updateCommon
- Строки 255-258, updateCommon: bytecode offsets 177-180 загружает аргумент 6 и выполняет putfield onClick
- Дополнительный legacy путь в том же 1.7.3 JAR имеет ту же семантику: ClickableSemanticsNode$applySemantics$1.invoke читает mutable node.onClick через access$getOnClick$p. Dump: /private/tmp/feoria-v06-reader-clickable-legacy-javap.txt. Вывод не зависит от выбора одного из этих двух путей

## Почему подходит key(generation)

Button занимает один и тот же composition call site, поэтому при новом accepted reading его clickable node может сохраниться и получить новый onPrimary. Переименование testTag не создает новый node. Повторная generation проверка в новом onPrimary тоже не решает проблему: она видит уже новое значение generation и законно ставит новое чтение на паузу

Ключ должен охватывать Button целиком, включая его clickable/semantics modifiers. Не требуется key по label/primaryAction и не требуется пересоздание всего reader со scroll/mode state. Старые проверки generation внутри действия нужно сохранить

## Дальнейшая проверка и пределы доказательства

- После разрешенного root исправления тот же тест без изменений должен пройти все три captured actions: Begin, Continue, Finish. В исходном log нет отдельного маркера итерации; по самому log нельзя утверждать, что все три случая были достигнуты
- Сохранить реальные Text Play/Pause, BeforeStart, Missing и End проверки, включая writer counts и paused/playing status. Желательно отдельно сравнить сохранение node identity внутри одной generation, если это потребуется для заявленного accessibility результата; текущая диагностика не содержит TalkBack-прогона
- Bytecode доказывает mutable-wrapper механизм, а log показывает согласующийся эффект. Полной runtime трассы node identity до/после replacement нет, поэтому не приписывается точное событие внешней accessibility-службы или физического tap. Это проверка late callback контракта приложения
- Нет оснований добавлять retry, задержку или проверять только snapshot: snapshot всегда paused даже при live Play и скрыл бы данный дефект
