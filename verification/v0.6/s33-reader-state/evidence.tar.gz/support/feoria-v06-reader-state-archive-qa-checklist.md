# QA checklist архива 3.3

Read-only сверка реальных схем завершена. Скрипт архива не запускался, repo/source/tests не менялись. На момент чтения r2 содержит только build.log, s33-reader-native еще отсутствует - финальную приемку пока утверждать нельзя

## 1. Результаты и сохранение исходного FAIL

- r1 build.json: schema=1, kind=build, status=FAIL, exit_code=1. Это ожидаемый исходный результат, его нельзя требовать PASS или переписывать. build.log SHA должен совпасть с log_sha256
- r1 test-summary.json имеет requested_tasks, results.unit/results.ui и limits. Фактически unit={tests:421,failures:0,errors:0,skipped:0}, ui={tests:123,failures:1,errors:0,skipped:0}
- В r1 34 unit XML, 421 testcase PASS; один UI XML, 122 PASS и один FAIL. Единственный отказ: ru.liturgyguide.ui.ReaderStateFlowTest#capturedBeginningContinuationAndFinishCannotChangeAReplacementReading
- XML testsuite.name в UI равен SavedReadingTest, хотя внутри 13 suites. ID обязательно брать из каждого testcase.classname + '#' + testcase.name, не из testsuite.name. Проверять failure, error И skipped; старый s32 archive script ошибочно считал skipped за PASS
- После завершения r2: build.status=PASS, exit_code=0; UI ровно 37 PASS, без skips/errors/failures; ID уникальны внутри каждого run. r2 IDs подмножество r1, включают исходный FAIL
- latest union по порядку r1 -> r2: ровно 123 сценария, все PASS, источники 86 из r1 и 37 из r2. Сохранить per-run totals и исходный FAIL, не выдавать 160 выполнений за 160 разных сценариев или 123 за полный повтор на r2
- 421 unit относятся только к r1. r1 build.log содержит выполненный ':app:testDebugUnitTest' без UP-TO-DATE. Если r2 не запрашивает этот task, отсутствие unit-results ожидаемо. Нельзя подложить старые XML в r2 или назвать unit повторно пройденными после key-wrapper

## 2. Строго ограниченная дельта и актуальные файлы

- В каждом завершенном build inputs_before == inputs_after, включая sha256 и files. Схема files: список объектов {path,sha256}; в r1 155 файлов
- r1 -> r2 разрешено изменить ровно app/src/main/java/ru/liturgyguide/ui/ServiceScreen.kt. Старый SHA 448b791db8b272762d75aeb9fd502bb6dfe55e9b2a8b726310889327a509af26, новый 9b208da3507f19990214c081aba29117651cd231a886a0d9b369546c11390504
- Допускается только принятый key(generation) wrapper. Сохранить /private/tmp/feoria-v06-reader-state-primary-fix.diff и correction-review; проверка обратного удаления wrapper должна давать старый SHA. Простого allowlist имени ServiceScreen недостаточно для разрешения любых изменений файла
- Сверять maps путей/хешей без потери файлов. В production входят 80 non-external inputs; но 75 external содержат tests/fixtures. Например external/15/ReaderPresentationTest.kt, external/74/ReaderStateFlowTest.kt. Не отбрасывать external при доказательстве неизменности тестов. Между r1/r2 все внешние hashes тоже должны остаться прежними
- Текущие production files на диске соответствуют r2/native inputs. Все 14 файлов final freeze и их sizes/aggregate сверены; остальные 13 файлов идентичны r1 freeze. Сами freeze/reviews архивируются, а не только ссылка на /tmp
- native build input map соответствует r2 production, включая ServiceScreen нового SHA. Его собственный inputs_before/after стабилен. Source.commit одинаковый сам по себе не доказывает равенство dirty inputs

## 3. Диагностика и происхождение

- Сохранить целиком r1 ui-diagnostics/first-failure-1794184864648: .complete, capture.json, failure-context.json, failure.txt, PNG, системные dumps; также diagnostic-preparation.json и diagnostic-export.json
- Реальный diagnostic-export: exit_code=0, complete_packets=1. capture.source=readerState.stalePrimaryActions, run=s33-reader-state-r1, test совпадает с XML, verdict=DIAGNOSTIC_ONLY. Diagnostic packet не объявлять успешным тестом
- Сохранить root/QA failure reports, bytecode dumps, initial code review, correction review, source freezes r1/final, QA manifest/report. Freeze.tests.executed=false - историческое свойство момента freeze, не ошибка и не источник итогового PASS
- В архиве должны быть точные скрипты/helper manifest/fixture, используемые для native, с хешами. Копии должны соответствовать script_sha256/harness_sha256 в receipts, а не просто текущей последней версии по имени

## 4. Native - только после появления фактов

- План /private/tmp/feoria-v06-reader-state-manifest.json задает 6 cases: text, wait, before, meaning, missing, end. Все light/normal/paused. Это не доказательство dark/200%/landscape или естественного входа - эти пределы явно сохранить
- Native run.json содержит run_id, manifest_sha256, build_sha256, installed_sha256, apk, harness_sha256. Проверить реальные bytes manifest/build и равенство installed_sha256 == apk.sha256 == build.apk.sha256
- case.json для каждого case: тот же run_id/apk_sha256/manifest_sha256, status=PASS; artifacts map {path,sha256,bytes} проверяется по каждому файлу. Пути разрешаются внутри native root. Проверить наличие PNG и before/after XML, условия SDK/font_scale/timezone
- case.visual_status может оставаться NOT_REVIEWED и после внешнего review. Авторитетен отдельный review.json: тот же run_id/case_id, screen_sha256 фактического PNG, decision=ACCEPT. gate.json должен быть PASS, required_cases=passed_cases=6 и содержать полный набор visual_reviews
- Fixture helper /private/tmp/feoria-v06-reader-fixture.py использует s32-current-plans: архивировать actual table/producer и нужную цепочку их SHA либо ссылаться на уже неизменяемый архив с точным hash. Сохранить все supplemental/fixture-*/event.json, completion.json, preferences.xml, readback.xml и write/launch logs; completion=RECORDED, fixture bytes == readback == fixture_sha256
- Fixture helper сравнивает шесть планообразующих source files и два APK assets с producer baseline. Эти проверки/producer hashes сохраняются. Не называть fixture естественным входом, upgrade, акустической проверкой. Meaning должен быть открыт реальным UI tab, что сохраняется в native action receipts
- Независимый visual review и root review не заменяются совпадением XML. Если они еще не появились, скрипт должен остановиться или оставить явный NOT_READY, а не создать приемочный PASS

## 5. Содержимое tar и самопроверка архива

- Roots явно заданы: r1, r2, native и согласованные supplemental evidence. Никаких еще дописываемых каталогов: требовать завершенные receipts до упаковки. Исходный FAIL и его packet обязательно входят
- Уникальные безопасные относительные arcnames; только обычные файлы, без повторов/выхода за root. APK bytes исключаются, их SHA/package/version/certificate/debuggable receipts сохраняются. r1 build.json не содержит apk из-за failed build - не выдумывать receipt
- После создания перечитать tar и сравнить SHA/size КАЖДОГО member с исходными bytes, а также точное множество members с выбранным списком. Проверить отсутствие .apk, число файлов, полный размер и archive SHA-256. Не включать создаваемый archive внутрь самого себя
- archive.json/ui-coverage.json описывают разные source groups: r1 до key-wrapper, r2/native после. Старое s32 утверждение all production groups equal здесь неверно. Итог честно указывает разрешенную единственную дельту и происхождение результатов

Готов проверить написанный скрипт статически по этому списку; никакой запуск архива не требуется
