# 3.3 r1 - позднее действие главной кнопки

Read-only диагностика implementer + QA. Полный Gradle прогон r1 еще идет; source/tests остаются frozen. Никакие правки, Gradle или adb в этой диагностике не выполнялись

## Подтвержденный отказ

`ReaderStateFlowTest.capturedBeginningContinuationAndFinishCannotChangeAReplacementReading` падает на line204 -> `assertPrimary` line250: ожидалась доступная подпись "Пауза", фактически узел `play_lyrics` имеет "Двигать текст" и StateDescription "На паузе"

Лог: `app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderStateFlowTest-capturedBeginningContinuationAndFinishCannotChangeAReplacementReading.txt`

Тест захватывает настоящий SemanticsActions.OnClick старого primary, принимает новую дату/чтение, включает Play, дает композиции обновиться и только затем вызывает старое действие. Clock не продвигается, пользовательского drag и Meaning нет. Поэтому это не гонка таймера или автоматическое завершение. Runtime presenter выводит фактическое состояние player

## Причина

Один `Button(onClick = onPrimary)` находится в одной стабильной позиции композиции. После новой generation Compose переиспользует clickable node и обновляет его onClick

QA извлек bytecode exact локального Compose Foundation 1.7.3; implementer самостоятельно прочитал ключевые участки в `/private/tmp/feoria-v06-reader-clickable-javap.txt`:

1. `AbstractClickableNode$applySemantics$1` захватывает **node** в this$0
2. Его invoke на каждом вызове выполняет `this$0.getOnClick().invoke()` - это не неизменяемая ссылка на старый callback
3. `ClickableElement.update` вызывает `ClickableNode.update`, а тот `updateCommon`
4. `updateCommon` перезаписывает поле node.onClick новым callback

Старый semantic action поэтому обращается к уже новому `onPrimary`, содержащему новую generation и действие PAUSE. Проверка generation в старом приложенном callback сама по себе правильная, но этот старый callback больше не вызывается

Это продуктовый дефект владения clickable узлом между принятыми контекстами. Ослаблять тест, вызывать старое действие до recomposition или подменять его прямым вызовом lambda приложения нельзя: это скроет воспроизведенный путь

## Минимальный предлагаемый фикс

После завершения Gradle и отдельного разрешения root обернуть **только primary Button** в `key(generation)` внутри ReaderFooter. Сохранить все существующие onPrimary/generation guards, label/status/tags, размеры и assertions

При replacement создается другой node; старый semantic action продолжит ссылаться на старый node с прежним callback, и его existing generation guard отклонит действие. Внутри той же generation обычные Play/Pause сохраняют один node и не теряют focus из-за смены действия

Не использовать `key(primaryAction)` или `key(primaryLabel)`: такой ключ перестраивал бы кнопку при каждом Play/Pause. Не расширять фикс на engine, store, assets, весь footer или остальные unrelated callbacks без отдельного доказанного дефекта

## Проверка после одобрения

Root повторяет неизмененный failing test после delta review, затем связанные реальные primary-сценарии ReaderStateFlowTest. Должны пройти все три cases Begin/Continue/Finish, сохраняться accepted state, live playing, writer count и отсутствие Finish. Старый r1/log/diagnostics сохраняются как исходное свидетельство, это не flaky retry

QA подтверждение будет в `/private/tmp/feoria-v06-reader-state-qa-failure.md`. Исправление и повторный результат пока не выполнены; этот отчет не объявляет PASS


## Одобренный delta после завершения r1

Root сообщил финальный r1: 421 unit PASS, 122/123 UI PASS, единственный отказ разобран выше. После отдельного разрешения root внесен только `key(generation)` вокруг primary Button в ReaderFooter. Тело Button, modifier, callbacks, guards, тесты и остальные controls неизменны

- Предыдущий manifest: `/private/tmp/feoria-v06-reader-state-freeze-r1.json`
- Точный delta: `/private/tmp/feoria-v06-reader-state-primary-fix.diff`
- Новый manifest: `/private/tmp/feoria-v06-reader-state-freeze.json`
- Из 14 source/test SHA изменен только ServiceScreen
- Новый aggregate SHA-256: `b6ab6370713d67713cbeb55948342403c49681ed1dfbda96e374ffffa87b2e1d`

SOURCE FREEZE возобновлен. Новый кандидат еще не запускался; root/Astra delta review, затем root targeted ReaderStateFlow/Unified/Compact/ReaderAccessibility (37 методов). Implementer Gradle/adb не запускал
