#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648" "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s33-reader-state-r1/first-failure-1794184864648.export.txt"
exit "$result"
