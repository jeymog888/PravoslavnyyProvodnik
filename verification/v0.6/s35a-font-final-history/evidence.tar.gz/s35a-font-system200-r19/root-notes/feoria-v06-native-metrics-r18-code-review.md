# R18 exact font oracle correction

ACCEPT для узкого повторного запуска landscape. NOT_RUN этим reviewer

Все 20 SHA/bytes совпали с freeze aggregate b459be8d789a21f0ad12089c99ee88077122edbdb4b568c53811094eb006db89. Побайтное сравнение с R16 source-freeze подтвердило, что изменен только ReaderAccessibilityTest.kt. NativeFontAssertions восстановлен точно R16, production и остальные файлы неизменны

Exact delta соответствует принятому причинному разбору R17: landscape expected scale теперь независимо вычисляется как 1.3f * 1.3f; рядом с прежним metadata assertion добавлено точное равенство Float raw bits. Wrapper withCiFailureDiagnostics расположен внутри try до finally orientation cleanup. Временные alternative prediction/logging удалены вместе с восстановлением NativeFontAssertions

Сохранены все native glyph/baseline checks, constraints, tolerances, 28sp/39.2sp, >=120dp и действия seek/mode. Отрицательная проверка прежнего mode marker осталась в точной базе R16. Новых статических blockers нет

Это коррекция эквивалентности входа oracle по подтвержденному Android evidence, не округление production scale и не ослабление условий. R16/R17 FAIL остаются сохраненными. PASS нового запуска еще не заявляется

Source не редактировал, Gradle/adb не запускал
