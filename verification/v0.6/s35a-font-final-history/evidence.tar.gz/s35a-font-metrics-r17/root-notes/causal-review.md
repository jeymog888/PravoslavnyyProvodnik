# R17 Android metrics causal review

ACCEPT причинного вывода для наблюденного Android mismatch и ACCEPT preflight R18 test-only correction. Новый R18 PASS еще не заявляется

Лично прочитан полный failure message в s35a-font-metrics-r17/ui-results XML. Это фактический Android результат, не экстраполяция локального JVM probe

| Величина | Actual | Literal oracle | Independent product oracle |
| --- | --- | --- | --- |
| Scale raw bits | 3fd851ea | 3fd851ec | 3fd851ea |
| 28sp px | 84.97999 | 85.36499 | 84.97999 |
| 39.2sp px | 109.83119 | 110.165596 | 109.83119 |
| Line0 left/right/top/bottom | 0 / 763.0664 / 0 / 104 | 0 / 772.04297 / 0 / 105 | 0 / 763.0664 / 0 / 104 |
| Line1 left/right/top/bottom | 0 / 849 / 104 / 219 | 0 / 859 / 105 / 220 | 0 / 849 / 104 / 219 |
| First/last baseline | 79 / 198 | 79 / 199 | 79 / 198 |

Обе predictions используют одинаковые text/style/resolver/paragraph width 860, а product scale независимо задан fixture как 1.3f*1.3f. Он не скопирован из actual. Совпадают также line ranges 0..18 и 18..37. Actual style действительно 28sp/39.2sp, weight600. Следовательно различие входного Float масштаба объясняет конкретное наблюденное расхождение metrics: точное production expression воспроизводит все actual line extents и baselines, literal не воспроизводит

Это согласуется с независимо доказанными native converter cache keys 168/169 и JVM order dependence. Не требуется и не утверждается несуществующее доказательство Compose ceil. Не восстанавливается история cache предыдущего R16, и R17 conversions не называются snapshot до oracle. Достаточный вывод: исходная проверка сравнивала разные native входы

R18 корректен при точном заявленном delta

- NativeFontAssertions вернуть побайтно к R16, убрать временную диагностику, сохранить все line/baseline/native constraints проверки
- Только landscape expected scale заменить с округленного literal 1.69f на независимое 1.3f*1.3f, соответствующее fixture и MainActivity multiplication
- Добавить точное равенство raw bits expectedScale/actual fontScale рядом с прежним metadata assertion. Остальные вызовы helper используют 1.3f или 2.6f, соответствующие своим fixture products
- Сохранить withCiFailureDiagnostics до finally orientation cleanup
- Не менять runtime, global cache, tolerances, paragraph width, 28sp/39.2sp, 120dp и действия сценария

Такое изменение усиливает эквивалентность входов oracle, а не выбирает actual metadata вместо независимого expected. Один целевой повтор landscape после freeze достаточен для этой коррекции. R16/R17 FAIL сохраняются

Source не редактировал, Gradle/adb не запускал
