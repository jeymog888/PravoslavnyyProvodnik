import androidx.compose.ui.unit.fontscaling.FontScaleConverter;
import androidx.compose.ui.unit.fontscaling.FontScaleConverterFactory;
import androidx.collection.SparseArrayCompat;
public class FeoriaR16ConverterProbe {
  public static void main(String[] args) {
    var factory = FontScaleConverterFactory.INSTANCE;
    var initial = factory.getSLookupTables().clone();
    float product = 1.3f * 1.3f, literal = 1.69f;
    float[][] sequences = { {product, literal}, {literal, product}, {1.3f, product, literal}, {1.68f, product, literal}, {product, 1.68f, literal} };
    for (int i = 0; i < sequences.length; i++) {
      factory.setSLookupTables(initial.clone());
      System.out.println("SEQUENCE " + i);
      for (float scale: sequences[i]) {
        FontScaleConverter converter = factory.forScale(scale);
        System.out.printf(java.util.Locale.ROOT,"scale=%.9f bits=%08x key=%d sp28=%.9f sp39.2=%.9f px28@2.625=%.9f converterId=%x%n", scale, Float.floatToRawIntBits(scale), (int)(scale*100f), converter.convertSpToDp(28f), converter.convertSpToDp(39.2f), converter.convertSpToDp(28f)*2.625f, System.identityHashCode(converter));
      }
    }
  }
}
