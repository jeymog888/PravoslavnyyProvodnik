# R17 native metrics diagnostic preflight

ACCEPT для одного целевого диагностического запуска. NOT_RUN; причинность R16 pixel mismatch еще не принята

Все 20 SHA/bytes совпали с freeze aggregate bdc95cd1dee604420fe50acc60fa83b26b95137681b3f00d48e2690b53b274e5. Exact comparison с s35a-font-controls-r16/source-freeze подтвердило изменения только NativeFontAssertions.kt и ReaderAccessibilityTest.kt; runtime неизменен

Исходный literal1.69f остается единственным assertion oracle. predict(native) использует те же input/style/resolver/constraints и прежний native font. Все lineCount, left/right/top/bottom, baselines и допуски сохранены. Независимое1.3f*1.3f поступает отдельным diagnosticScale из fixture, не копируется из actual metadata. Дополнительный predict не используется для автоматического PASS или fallback

Диагностическое сообщение содержит actual/original/product raw scale bits, DP/PX conversions, style/constraints/paragraph width/size, line ranges/geometry и first/last baselines. Оно встроено в assertion message, поэтому не зависит только от возможного обрезания logcat. Сравнение actual с обеими predictions позволит проверить конкретную гипотезу без изменения runtime или tolerances

Ограничение: conversions логируются после создания literal Density и predict(native), не являются snapshot factory до вмешательства oracle. Нельзя описывать их как восстановленную историю заполнения cache R16. Это не мешает сравнению уже существующих actual glyph metrics с двумя независимыми input scales в данном запуске

withCiFailureDiagnostics находится внутри try, до finally orientation cleanup. Следовательно failure packet снимается до возврата portrait. Нет retry, sleep, catch-and-pass или снятых assertions. При ожидаемом исходном FAIL он сохраняется как FAIL

Новых compile blockers по delta не найдено. Reviewer ничего не редактировал в repo, Gradle/adb не запускал
