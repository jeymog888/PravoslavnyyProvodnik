# R16: расхождение native metrics

Read-only diagnosis, 2026-11-09. Runtime/tests/repo не менялись, Gradle/adb не запускались. Прочитаны замороженные R16 исходники, XML/logcat, точный Compose 1.7.3 bytecode. Выполнен только локальный JVM probe существующего converter jar; это не Android-прогон и не повтор R16

Вывод: доказано, что oracle получает другой font-scale cache key, чем production. Доказана зависимость полученной конверсии от порядка запросов. Это конкретный дефект эквивалентности входов проверки, а не основание менять runtime или допуск. Причинность именно разницы 8.97656 px на Android пока требует диагностического сопоставления

## Факты

- FAIL: `ReaderAccessibilityTest.kt:111`, первый `assertReadingSpaceAndScale(3, 1.69f)`, `NativeFontAssertions.kt:24` right extent: expected772.04297, actual763.0664
- Это до `next_line` и Meaning. QA подтвердил: `assertReadableHeader` открывает/закрывает modes без выбора и программно позиционирует список; accepted selected line3 не меняется. Stale fontWeight после seek не объясняет последовательность. Runtime Line явно SemiBold для selected, Normal для остальных
- `launchApp` передает parent `Density(deviceDensity,1.3f)`. `MainActivity.kt:482` умножает на factor1.3f. Metadata assertion допускает .001f, но затем oracle создает `Density(...,literal1.69f)`
- R16 `diagnostic-export.json` имеет 0 complete packets. Фактические input style/fontWeight, conversions и constraints в отказе не сохранены. R10 использовал тот же NativeFontAssertions; runtime delta R16 затрагивает ReaderControlAction, не prayer Line

| Значение | float32 | raw bits | `(scale*100f).toInt()` |
| --- | --- | --- | --- |
| production `1.3f*1.3f` | 1.6899998188018799 | 0x3fd851ea | 168 |
| oracle `1.69f` | 1.690000057220459 | 0x3fd851ec | 169 |

В реальном `FontScaleConverterFactory` ключ именно truncation после float multiplication. `forScale` ищет в общей SparseArray, при отсутствии интерполирует по соседним таблицам и вставляет новую таблицу. Позиция соседней таблицы восстанавливается как key/100f, даже если она создана запросом почти1.69 и сохранена под168. Это объясняет, почему микроскопическая разница Float может стать заметной разницей конверсии

Локальный probe использует **точный ui-unit1.7.3 classes.jar**: SHA256 `80d406316586878164434d3ac539a97a0a754ae9d4935b85f61539b8c322a62e`, совпадение с classes.jar внутри AAR проверено

| Порядок вызовов в свежем factory | 28sp production, dp | 28sp literal oracle, dp | px при density2.625 |
| --- | --- | --- | --- |
| product -> literal | 32.373329163 | 32.519996643 | 84.979988098 против85.364990234 |
| literal -> product | 32.373329163 | 32.373332977 | 84.979988098 против84.979995728 |

Для первого порядка 39.2sp дают41.840454102 против41.967845917dp. Предварительный запрос1.3f сохраняет тот же результат. Поэтому R10 PASS/R16 FAIL совместимы с порядком заполнения process cache; это пока объяснение, а не восстановленная история Android cache R16. Нельзя выводить точные Android glyph extents только из разницы px-size: влияют shaping/hinting и line layout

## Один точный диагностический шаг

До assertions в `assertNativeTextMetrics` сохранить compact structured failure data:

1. Actual input density class, density/fontScale и raw bits; текущий oracle density/bits; отдельный ожидаемый production scale, независимо вычисленный из fixture `1.3f*1.3f`. Не подменять expected константу копией actual metadata
2. Для этих трех Density: 28sp и39.2sp -> dp/px; также18sp/16sp, если нужен witness общего converter. Снять actual conversions до создания нового literal oracle, чтобы было видно состояние до вмешательства диагностики
3. Text, fontSize/lineHeight/fontWeight/fontFamily/fontStyle/fontSynthesis, letterSpacing, localeList, lineBreak/hyphens, layoutDirection, resolver identity; actual input constraints, paragraph width/height, result size
4. Все line start/end, left/right/top/bottom/baseline, lineCount, first/lastBaseline для actual и ДВУХ свежих TextMeasurer(cacheSize=0): текущий literal oracle и production-expression oracle. Обоим оставить ровно текущие constraints/minWidth=paragraphWidth. Допуски1px и нынешний основной assertion не менять

Если production-expression oracle совпадет с actual, а literal oracle воспроизведет отказ при разных conversions, причина этого Android mismatch установлена. Если оба расходятся, numeric gap недостаточен: смотреть actual fontWeight и resolver/paragraph данные, не добавлять retry и не менять runtime наугад

Обернуть landscape test в существующий `withCiFailureDiagnostics` **внутри try до finally с обратной ориентацией**, чтобы PNG/semantics снимались до возврата portrait. Сохранить mismatch-поля в failure packet/полном XML assertion message, не только длинной строкой logcat, которая может обрезаться. Никаких новых ожиданий, sleep или tolerance widening

После подтверждения достаточная правка - oracle с тем же независимо вычисленным float expression, что задан fixture/production, плюс точная проверка raw scale bits. Не округлять runtime fontScale и не очищать global converter cache ради зеленого теста. Существующая проверка полного размера28sp и39.2sp, line extents и геометрии остается

Evidence: `/private/tmp/feoria-v06-r16-font-converter-bytecode.txt`, `/private/tmp/FeoriaR16ConverterProbe.java`, `/private/tmp/feoria-v06-r16-converter-probe.txt`. QA независимо подтвердил порядок теста, SHA R16 и Float bits

## Дополнительная проверка гипотезы 85/86 px

По запросу root проверены exact `AndroidParagraphIntrinsics`, `TextPaintExtensions_androidKt`, `AndroidTextPaint` и `SpannableExtensions_androidKt`. Обычный путь: AndroidParagraphIntrinsics -> applySpanStyle -> Density.toPx -> AndroidTextPaint.setTextSize(float), без ceil/round. AndroidTextPaint не переопределяет setTextSize. Альтернативный font-size span использует roundToInt -> AbsoluteSizeSpan, не ceil; обычный String здесь не задает font-size spans

772.04297 /763.0664 близко86/85: пересчет actual*86/85 дает772.0436518, отличие0.0006818px. Это сильная совместимость с дискретизацией в platform shaping, но **не доказательство ceil в Compose**. Поэтому exact Android metric diagnostic остается обоснованным, причинность конкретного bound mismatch без него не объявляем

Дополнительный bytecode: `/private/tmp/feoria-v06-r16-textpaint-bytecode.txt`, `/private/tmp/feoria-v06-r16-spannable-bytecode.txt`
