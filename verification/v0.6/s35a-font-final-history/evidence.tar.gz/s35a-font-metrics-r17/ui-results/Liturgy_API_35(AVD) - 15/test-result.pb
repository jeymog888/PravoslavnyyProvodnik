
�7
�
ReaderAccessibilityTestru.liturgyguide.uiHlandscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize2�������):��������.
�java.lang.AssertionError: Native text measurement: Он рожден от Отца прежде всех времен. at 1.69
actual input scale=1.6899998 bits=3fd851ea 12.0.sp=20.279999.dp/53.234997px, 28.0.sp=32.37333.dp/84.97999px, 39.2.sp=41.840454.dp/109.83119px
original expected scale=1.69 bits=3fd851ec 12.0.sp=20.39.dp/53.52375px, 28.0.sp=32.519997.dp/85.36499px, 39.2.sp=41.967846.dp/110.165596px
independent product expected scale=1.6899998 bits=3fd851ea 12.0.sp=20.279999.dp/53.234997px, 28.0.sp=32.37333.dp/84.97999px, 39.2.sp=41.840454.dp/109.83119px
style=TextStyle(color=Color(0.88235295, 0.9019608, 0.8627451, 1.0, sRGB IEC61966-2.1), brush=null, alpha=1.0, fontSize=28.0.sp, fontWeight=FontWeight(weight=600), fontStyle=null, fontSynthesis=null, fontFamily=null, fontFeatureSettings=null, letterSpacing=Unspecified, baselineShift=null, textGeometricTransform=null, localeList=LocaleList(localeList=[ru]), background=Color(0.0, 0.0, 0.0, 0.0, None), textDecoration=null, shadow=null, drawStyle=null, textAlign=Unspecified, textDirection=Unspecified, lineHeight=39.2.sp, textIndent=null, platformStyle=null, lineHeightStyle=null, lineBreak=LineBreak(strategy=Strategy.HighQuality, strictness=Strictness.Strict, wordBreak=WordBreak.None), hyphens=Hyphens.Auto, textMotion=null) constraints=Constraints(minWidth = 0, maxWidth = 860, minHeight = 0, maxHeight = Infinity) paragraphWidth=860 size=860 x 219
actual=0:0..18 0.0,763.0664,0.0,104.0, 1:18..37 0.0,849.0,104.0,219.0 baselines=79.0/198.0
original prediction=0:0..18 0.0,772.04297,0.0,105.0, 1:18..37 0.0,859.0,105.0,220.0 baselines=79.0/199.0
product prediction=0:0..18 0.0,763.0664,0.0,104.0, 1:18..37 0.0,849.0,104.0,219.0 baselines=79.0/198.0 expected:<772.04297> but was:<763.0664>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:577)
at ru.liturgyguide.ui.NativeFontAssertionsKt.assertNativeTextMetrics(NativeFontAssertions.kt:40)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-xMeaFFI(ReaderAccessibilityTest.kt:424)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-xMeaFFI$default(ReaderAccessibilityTest.kt:417)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize$lambda$3(ReaderAccessibilityTest.kt:112)
at ru.liturgyguide.ui.ReaderAccessibilityTest.$r8$lambda$EB7xzJrojZwgjvZew-IPQl_eryA(Unknown Source:0)
at ru.liturgyguide.ui.ReaderAccessibilityTest$$ExternalSyntheticLambda7.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:108)
java.lang.AssertionError�java.lang.AssertionError: Native text measurement: Он рожден от Отца прежде всех времен. at 1.69
actual input scale=1.6899998 bits=3fd851ea 12.0.sp=20.279999.dp/53.234997px, 28.0.sp=32.37333.dp/84.97999px, 39.2.sp=41.840454.dp/109.83119px
original expected scale=1.69 bits=3fd851ec 12.0.sp=20.39.dp/53.52375px, 28.0.sp=32.519997.dp/85.36499px, 39.2.sp=41.967846.dp/110.165596px
independent product expected scale=1.6899998 bits=3fd851ea 12.0.sp=20.279999.dp/53.234997px, 28.0.sp=32.37333.dp/84.97999px, 39.2.sp=41.840454.dp/109.83119px
style=TextStyle(color=Color(0.88235295, 0.9019608, 0.8627451, 1.0, sRGB IEC61966-2.1), brush=null, alpha=1.0, fontSize=28.0.sp, fontWeight=FontWeight(weight=600), fontStyle=null, fontSynthesis=null, fontFamily=null, fontFeatureSettings=null, letterSpacing=Unspecified, baselineShift=null, textGeometricTransform=null, localeList=LocaleList(localeList=[ru]), background=Color(0.0, 0.0, 0.0, 0.0, None), textDecoration=null, shadow=null, drawStyle=null, textAlign=Unspecified, textDirection=Unspecified, lineHeight=39.2.sp, textIndent=null, platformStyle=null, lineHeightStyle=null, lineBreak=LineBreak(strategy=Strategy.HighQuality, strictness=Strictness.Strict, wordBreak=WordBreak.None), hyphens=Hyphens.Auto, textMotion=null) constraints=Constraints(minWidth = 0, maxWidth = 860, minHeight = 0, maxHeight = Infinity) paragraphWidth=860 size=860 x 219
actual=0:0..18 0.0,763.0664,0.0,104.0, 1:18..37 0.0,849.0,104.0,219.0 baselines=79.0/198.0
original prediction=0:0..18 0.0,772.04297,0.0,105.0, 1:18..37 0.0,859.0,105.0,220.0 baselines=79.0/199.0
product prediction=0:0..18 0.0,763.0664,0.0,104.0, 1:18..37 0.0,849.0,104.0,219.0 baselines=79.0/198.0 expected:<772.04297> but was:<763.0664>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:577)
at ru.liturgyguide.ui.NativeFontAssertionsKt.assertNativeTextMetrics(NativeFontAssertions.kt:40)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-xMeaFFI(ReaderAccessibilityTest.kt:424)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-xMeaFFI$default(ReaderAccessibilityTest.kt:417)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize$lambda$3(ReaderAccessibilityTest.kt:112)
at ru.liturgyguide.ui.ReaderAccessibilityTest.$r8$lambda$EB7xzJrojZwgjvZew-IPQl_eryA(Unknown Source:0)
at ru.liturgyguide.ui.ReaderAccessibilityTest$$ExternalSyntheticLambda7.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:108)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain