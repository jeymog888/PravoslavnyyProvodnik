#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35a-font-metrics-r17/first-failure-1794206026865.export.txt"
exit "$result"
