package ru.liturgyguide.ui

import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.sp
import android.util.Log
import org.junit.Assert.assertEquals
import kotlin.math.roundToInt

/** Check the rendered text path against the native density used by the layout predictor. */
internal fun assertNativeTextMetrics(actual: TextLayoutResult, native: Density, diagnosticNative: Density? = null) {
    val input = actual.layoutInput
    // Compose 1.7.3 String semantics rebuilds the paragraph and drops minWidth.
    // Use the same paragraph width so centered glyph positions are comparable;
    // density, font metrics, line wrapping and every extent remain independent.
    val paragraphWidth = actual.multiParagraph.width.roundToInt()
    fun predict(density: Density) = TextMeasurer(input.fontFamilyResolver, density, input.layoutDirection, cacheSize = 0)
        .measure(text = input.text, style = input.style, overflow = input.overflow,
            softWrap = input.softWrap, maxLines = input.maxLines, placeholders = input.placeholders,
            constraints = input.constraints.copy(minWidth = paragraphWidth, maxWidth = paragraphWidth))
    val predicted = predict(native)
    fun metrics(result: TextLayoutResult) = (0 until result.lineCount).joinToString { line ->
        "$line:${result.getLineStart(line)}..${result.getLineEnd(line)} " +
            "${result.getLineLeft(line)},${result.getLineRight(line)},${result.getLineTop(line)},${result.getLineBottom(line)}"
    } + " baselines=${result.firstBaseline}/${result.lastBaseline}"
    fun conversion(label: String, density: Density) = "$label scale=${density.fontScale} bits=${density.fontScale.toRawBits().toString(16)} " +
        listOf(12.sp, 28.sp, 39.2.sp).joinToString { unit -> with(density) { "$unit=${unit.toDp()}/${unit.toPx()}px" } }
    val diagnostic = diagnosticNative?.let { alternative ->
        "\n" + conversion("actual input", input.density) + "\n" + conversion("original expected", native) +
            "\n" + conversion("independent product expected", alternative) +
            "\nstyle=${input.style} constraints=${input.constraints} paragraphWidth=$paragraphWidth size=${actual.size}" +
            "\nactual=${metrics(actual)}\noriginal prediction=${metrics(predicted)}\nproduct prediction=${metrics(predict(alternative))}"
    }.orEmpty()
    val message = "Native text measurement: ${input.text} at ${native.fontScale}" + diagnostic
    if (diagnosticNative != null) Log.i("FeoriaFontMetricDiagnostic", message)
    assertEquals(message, predicted.lineCount, actual.lineCount)
    for (line in 0 until actual.lineCount) {
        assertEquals(message, predicted.getLineLeft(line), actual.getLineLeft(line), 1f)
        assertEquals(message, predicted.getLineRight(line), actual.getLineRight(line), 1f)
        assertEquals(message, predicted.getLineTop(line), actual.getLineTop(line), 1f)
        assertEquals(message, predicted.getLineBottom(line), actual.getLineBottom(line), 1f)
    }
    assertEquals(message, predicted.firstBaseline, actual.firstBaseline, 1f)
    assertEquals(message, predicted.lastBaseline, actual.lastBaseline, 1f)
}
