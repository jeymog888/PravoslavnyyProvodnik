"""Root-only orchestration of existing strict native observer, no bypass or retries."""
from pathlib import Path
import subprocess,json,hashlib
run=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/verification/v0.6/s35a-font-reader-native-r2')
def call(*args):
 p=subprocess.run(['python3','/private/tmp/feoria-v06-native.py',*map(str,args)],capture_output=True,text=True)
 with (run/'root-driver.log').open('a') as f:f.write(json.dumps(list(map(str,args)),ensure_ascii=False)+'\n'+p.stdout+p.stderr+'\n')
 assert p.returncode==0,p.stdout+p.stderr
 print(args[0],p.stdout if args[0] in ['show','prefs','scroll'] else 'PASS',flush=True)
 return p.stdout

def tap(case,selector,expected):call('tap',run,case,json.dumps(selector,ensure_ascii=False),json.dumps(expected,ensure_ascii=False))
def scroll(case,direction,expected):call('scroll',run,case,direction,json.dumps(expected,ensure_ascii=False))
def capture(case):call('capture',run,case)
def show(case):return call('show',run,case)
def prefs():return call('prefs',run)
def setup(*args):call('setup',run,*args)
def fixture(kind,theme,size):
 p=subprocess.run(['python3','/private/tmp/feoria-v06-reader-fixture.py',str(run),kind,theme,str(size)],capture_output=True,text=True)
 with (run/'root-driver.log').open('a') as f:f.write(f'fixture {kind} {theme} {size}\n'+p.stdout+p.stderr+'\n')
 assert p.returncode==0,p.stdout+p.stderr
 print('fixture',kind,theme,size,'RECORDED',flush=True)
def resume(case,expected):
 for i in range(2):scroll(case,'up',[{'text':'Служба'}])
 tap(case,{'text':'Сохраненное чтение'},expected)
