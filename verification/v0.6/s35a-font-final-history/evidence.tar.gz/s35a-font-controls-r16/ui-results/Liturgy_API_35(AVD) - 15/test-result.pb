
�
�
ReaderAccessibilityTestru.liturgyguide.ui7aSingleTextRetainsItsFullTitleAndTheClarificationAction2��������:�������-"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aSingleTextRetainsItsFullTitleAndTheClarificationAction.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderAccessibilityTestru.liturgyguide.uiAscriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu2�������E:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-scriptureAndAnEmptyTextStageKeepClarificationWithoutALanguageMenu.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable2������ۂ:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowScheduleKeepsBothDayLabelsOnOneLineAndSelectable.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderAccessibilityTestru.liturgyguide.uiAaTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize2��������:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallNarrowScreenKeepsReadableActionsWithoutReducingThePrayerSize.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderAccessibilityTestru.liturgyguide.uiLlargeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent2�������:�����ǫK"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-largeTextNavigationLeavesSpaceForChurchAndSettingsWithoutScalingTheirContent.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.uiHlandscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize2�������_:���������
�java.lang.AssertionError: Native text measurement: Он рожден от Отца прежде всех времен. at 1.69 expected:<772.04297> but was:<763.0664>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:577)
at ru.liturgyguide.ui.NativeFontAssertionsKt.assertNativeTextMetrics(NativeFontAssertions.kt:24)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-kncR6DU(ReaderAccessibilityTest.kt:422)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-kncR6DU$default(ReaderAccessibilityTest.kt:415)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:111)
java.lang.AssertionError�java.lang.AssertionError: Native text measurement: Он рожден от Отца прежде всех времен. at 1.69 expected:<772.04297> but was:<763.0664>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:577)
at ru.liturgyguide.ui.NativeFontAssertionsKt.assertNativeTextMetrics(NativeFontAssertions.kt:24)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-kncR6DU(ReaderAccessibilityTest.kt:422)
at ru.liturgyguide.ui.ReaderAccessibilityTest.assertReadingSpaceAndScale-kncR6DU$default(ReaderAccessibilityTest.kt:415)
at ru.liturgyguide.ui.ReaderAccessibilityTest.landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize(ReaderAccessibilityTest.kt:111)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-landscapeKeepsModeChoicesReadableAndLeavesSpaceForTheRequestedPrayerSize.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui6aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea2������ԫ:�������5"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-aTallScreenAtTheHeaderWidthBoundaryKeepsItsReadingArea.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderAccessibilityTestru.liturgyguide.uiBnarrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase2�������9:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderAccessibilityTestru.liturgyguide.uiAordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed2��������:������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-ordinaryFooterKeepsSeparateTargetsAtTheNarrowWidthAndFastestSpeed.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
|
ReaderAccessibilityTestru.liturgyguide.ui1ordinaryNavigationKeepsThreeColumnsAndWholeLabels2��������:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-ordinaryNavigationKeepsThreeColumnsAndWholeLabels.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderCompositionFlowTestru.liturgyguide.uiDcontrolsOpenAndDismissNeitherPauseLivePlaybackNorResetManualBrowsing2�������5:������ǣ"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderCompositionFlowTest-controlsOpenAndDismissNeitherPauseLivePlaybackNorResetManualBrowsing.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
ReaderPlatformFontTestru.liturgyguide.uiDnativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation2��������:�������s"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderPlatformFontTest-nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain