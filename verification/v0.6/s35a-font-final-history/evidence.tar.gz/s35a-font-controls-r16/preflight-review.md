# R16 selected mode visual correction

ACCEPT для целевых проверок. NOT_RUN этим reviewer, новый native visual PASS не заявляется

Все 20 SHA/bytes совпали с freeze aggregate 5b4cae6ba8165173846be0881d2b6413036d0e640c0dea9c9d7dbfc9bfbaa053. Побайтное сравнение с R15 source-freeze подтвердило ровно два измененных файла: ServiceScreen.kt и ReaderTestControls.kt. Оба delta прочитаны полностью

ReaderControlAction теперь рисует selected mode на full-row secondaryContainer с onSecondaryContainer. Остальные mode labels используют onSurface, обычные действия primary. Native bodyLarge и min48dp сохранены. Text получает остаток ширины через weight; все три режима резервируют одинаковые12dp gap+24dp slot. Check рисуется только selected, contentDescription=null, отдельного click target нет. Для selection=null slot не добавляется

onClick, enabled, IDs, contentDescription, selected/Role.Tab, внешние owner keys/guards и закрытие sheet не изменены. Переход от fillMaxWidth к weight не уменьшает доступную ширину обычных controls, потому что у них отсутствуют другие дочерние элементы

assertReaderMode сохраняет прежние text/48dp/selected/enabled проверки и дополнительно требует displayed marker у выбранного mode либо отсутствие у невыбранного в chooser. Существующие вызовы helper проверяют selected=true после переключения, но вызовов selected=false не найдено: новая отрицательная ветка пока не исполняется. Root уведомлен: достаточно одного явного unselected assertion после смены mode. Это небольшой пробел покрытия, не дефект production delta. Наличие icon semantics само по себе не доказывает контраст background или painted glyph, поэтому native кадр остается обязательным

Очевидных compile blockers не найдено: Color и filled icons уже импортированы, weight вызывается внутри RowScope TextButton. Точная доступность label после вычета36dp должна подтвердиться целевыми тестами/PNG без cap или ослабления bounds

Крупный разрыв заголовка "Управление чтением" остается открытой полировкой этапа5. Исходный controls PNG REJECT не переименовывается в PASS

Source/test edits, Gradle/adb reviewer не выполнял

## Final negative-marker coverage delta

ACCEPT окончательного R16 freeze aggregate 19cf57f8466e79988de3bb6a1d44d770c9070d2287151c152e3324e5d2f6577d. Все 20 SHA/bytes повторно сверены. ReaderAccessibilityTest.narrowLargeTextKeepsNamesReadableAndCancellationPreservesThePhrase отличается от R15 ровно добавлением assertReaderMode("original", selected = false) после meaning selected=true и перед возвращением Original. Таким образом тест действительно исполнит отрицательную проверку отсутствия marker, а не только содержит неиспользуемую ветку helper. Прежний пробел покрытия закрыт до запуска; прочие рассмотренные изменения прежние. Новый visual PASS еще требует PNG
