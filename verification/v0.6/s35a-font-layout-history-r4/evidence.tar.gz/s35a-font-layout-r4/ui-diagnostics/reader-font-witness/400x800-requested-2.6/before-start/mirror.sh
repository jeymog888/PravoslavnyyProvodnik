#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/400x800-requested-2.6/before-start/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
