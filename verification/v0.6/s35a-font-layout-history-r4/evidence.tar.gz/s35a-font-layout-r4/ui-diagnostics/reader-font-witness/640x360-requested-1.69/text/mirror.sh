#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r4/reader-font-witness/640x360-requested-1.69/text/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
