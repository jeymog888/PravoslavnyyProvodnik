# Независимое review root r4

ACCEPT для запуска только 3 UI методов / 21 case. Новый результат пока NOT RUN, visual gate остается открытым

Все 9 SHA256/bytes совпали с /private/tmp/feoria-v06-font-layout-freeze-r4-root.json. Aggregate 80abca816e651a18804aed50bb657fc9714baeb43d50f4902ecf8e3ee04fde66, linked delta 3301a5b89dab1ed0832ffe3571f6f9d0ff0edfe2e9be625eb5810987aff5bf37 также совпали. От r3 изменены ровно ReaderChromeLayout и ReaderFontLayoutWitnessTest, остальные 7 файлов неизменны

Блокеров в точном delta не найдено

- SIDEBAR ограничен w >= h реальной доступной области
- Все mode labels проверяются с chooserStyle labelLarge.merge(bodySmall), что учитывает унаследованный Medium от TextButton. Такой же стиль используется для измерения высоты chooser
- Compact primary samples и оба direct samples проверяются на одной естественной строке без maxLines=1/ellipsis. Ширины соответствуют компонентам: inner-26, inner-12, inner-56dp
- Прежние ограничения ширины поля240dp, высоты120dp и полной высоты панели сохранены. Fallback не выдает fitsReadingBudget=false за успешное размещение
- Witness добавляет запрет portrait SIDEBAR и однострочность реальных primary/mode/direct labels в SIDEBAR, сохраняя все прежние glyph/bounds/overlap/48dp/28sp проверки
- ReaderPresentationTest и его production presenter неизменны относительно r3; повторять9 unit ради этого delta не требуется

После запуска нужен личный просмотр новых PNG. Прямоугольные bounds и одна строка не являются самостоятельным доказательством отсутствия clipping по скругленной форме. R3 numerical PASS и его visual REJECT сохраняются отдельно

Gradle/adb не запускались, repo не менялся
