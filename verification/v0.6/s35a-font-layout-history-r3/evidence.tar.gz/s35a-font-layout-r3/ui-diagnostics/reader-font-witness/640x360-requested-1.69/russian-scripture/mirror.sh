#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/640x360-requested-1.69/russian-scripture/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
