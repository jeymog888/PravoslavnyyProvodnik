#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r3/reader-font-witness/400x800-requested-2.6/text/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
