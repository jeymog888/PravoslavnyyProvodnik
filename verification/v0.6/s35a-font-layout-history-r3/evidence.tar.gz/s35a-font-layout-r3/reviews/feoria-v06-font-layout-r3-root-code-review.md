# Независимое review 3.5a root r3

ACCEPT для следующего диагностического запуска ReaderPresentationTest + 3 UI метода / 21 case. Статус геометрии и выполнения тестов: NOT RUN. Это не приемка всего этапа 3.5a

Сверены все 9 файлов по SHA256 и bytes, aggregate e258f2e655d0ff6b55d8ef901c09ec9c82b4f494dc907ddac15b1a328e231489. Сверен linked r2 delta SHA256 53f44f7190fe084b9e09f499db82c5d18058078f0ed01ac32b59cedc9d923158. Прочитан весь delta, новый NativeFontAssertions, измененные witness проверки, участки runtime с provider/controls/details/footer. Удаленные AppTextDensity/LinearStressDensity не имеют оставшихся ссылок в app/src

Блокирующих статических дефектов в этой порции не найдено

- MainActivity берет внешний LocalDensity до собственного provider и один раз создает штатный Density(density, systemScale * appFactor). Нет двойного множителя, уменьшения SP или подмены физического density. Прежний custom converter и его неподходящие unit expectations удалены, r2 история сохранена
- NativeFontAssertions сравнивает реальные line count, left/right/top/bottom и baselines с TextMeasurer на той же строке, style, resolver, constraints, overflow, softWrap, maxLines и placeholders. Это содержательная проверка совпадения renderer и predictor, а не только metadata fontScale. Допуск 1 px прежнего порядка. Отдельные completeLayout/visible bounds/120dp/48dp/28sp/39.2sp проверки сохранены
- Witness честно назван requested font scale. Все 7 состояний снимаются до assertions, mirror только при explicit diagnostics=true/run, пути ограничены, timeout и отсутствие перезаписи назначения сохранены. Добавленный Original + Russian Scripture проверяет существующий language Header, новые доступные details, сохранение preferred Original и неизменность принятого context/offset/speed
- Перенос compact provenance и отсутствия звука соответствует отдельно согласованному продуктовому решению. Полный status остается в accessible state и явно доступном controls sheet, отсутствие звука также имеет текст там. Normal видимое отсутствие звука сохранено. Сокращение fixed status не притворяется успешным восстановлением или фактическим ходом службы
- Исправление saved/approx независимыми условиями сохраняет оба факта; новый unit regression действительно задает restored=true и isApproximate=true и проверяет полный/compact status
- stage title сохраняется без caps/ellipsis, изменен только вертикальный padding. Stable transport samples, owner/generation guards, key identity, visible-line anchor и пути seek/write не менялись в r3 delta. Direct secondary и Return продолжают занимать отдельные зарезервированные места

Ограничения, которые этот запуск не закрывает: реальная системная 200% с настройками приложения 1/1.15/1.3, все длинные имена этапов, прежние UI suites на новом runtime, конечные native PNG, состояние с активным Play/Return и окончательная доступность всех дополнительных поверхностей. Поле fitsReadingBudget=false не считается успехом. Нельзя переносить старые 6 unit PASS на новую модель либо называть requested2.6 пропорциональным увеличением glyph

Gradle/adb не запускались, repo/source/tests не изменялись
