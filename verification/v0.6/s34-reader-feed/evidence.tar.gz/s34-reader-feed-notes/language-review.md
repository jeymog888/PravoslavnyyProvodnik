# Узкий review language reflow 3.4

Вывод: подтвержден конкретный пробел в обещании сохранять просматриваемое место. manual=true подавляет собственное следование к accepted reading, но само по себе не сохраняет видимую canonical Line при уменьшении ее высоты. Смена первого видимого элемента в этом случае - нормальное поведение Compose; для принятого продуктового контракта нужна небольшая компенсация viewport

## Точное локальное подтверждение

Лично разобран cached Foundation 1.7.3 classes.jar:
/private/tmp/liturgy-android-toolchain/gradle-home/caches/transforms-4/57091831924c5ba8a5216e782a279c14/transformed/foundation-release/jars/classes.jar
SHA-256 30ad4cfbb0cd76c75210223803d6d290eb80ee1183aa2608561be0614bab73e9

Созданы только read-only bytecode dumps в /private/tmp:
- feoria-v06-language-LazyListMeasure-javap.txt
- feoria-v06-language-LazyListScrollPosition-javap.txt

LazyListMeasureKt.measureLazyList:
- bytecode 290-331 берет прежние firstVisibleItemIndex/firstVisibleItemScrollOffset и вычитает текущий scrollDelta. При простом remeasure delta может быть нулевым; прежний offset остается
- bytecode 498-501 устанавливает currentMainAxisOffset = -currentFirstItemScrollOffset
- bytecode 596-646 измеряет элемент заново, добавляет его новый mainAxisSizeWithSpacings; если конец элемента остается не дальше minOffset и это не последний элемент, присваивает currentFirstItemIndex = index+1 и уменьшает прежний offset на новый размер элемента
- дополнительная нормализация при before-content padding, bytecode 995-1039, также пропускает элементы, чей размер уже покрыт offset

LazyListScrollPosition.updateScrollPositionIfTheFirstItemWasMoved, bytecode 0-31, использует lastKnownFirstItemKey для поиска индекса при перестановке. Это не clamp offset при изменении высоты. updateFromMeasureResult, bytecode 0-17 и 101-121, принимает новый первый key/index/offset из результата измерения. Поэтому стабильный key не заставляет укоротившуюся Line остаться первой

Пример механизма, не измерение приложения: старый элемент имеет размер500px и offset400px. После сокращения новый размер300px. Нулевой scroll delta не спасает anchor: layout нормализует первый элемент к следующему с остаточным offset около100px, с учетом spacing/content padding

В actual assets communion, молитва "Верую, Господи, и исповедую", третья Line действительно имеет original87 и translation59 символов: "Еще верую, яко сие есть самое пречистое Тело Твое, и сия есть самая честная Кровь Твоя." -> "Верю, что это Твое пречистое Тело и Твоя драгоценная Кровь." Это хороший кандидат native/UI сценария, но отношение символов0.678 само по себе не доказывает отношение measured height при конкретном шрифте/ширине

## Минимальный контракт исправления

Только при явной смене Original/Russian во время manual browsing захватить до изменения языка owner + стабильный key просматриваемого элемента/Line. После reflow оставить этот semantic anchor видимым. Не вызывать player.seekLine, pause, play, accept и не сбрасывать manual в automatic follow. Accepted Text, offset, speed, date и writer count сохраняются

Самый простой допустимый вариант - сохранить тот же anchor key и выровнять его начало в viewport при смене языка. Это осознанное восстановление смыслового места с потерей лишь внутристочного пиксельного offset; его нужно так и назвать в контракте. Не требуется восстанавливать точную высоту буквы или пропорцию строк. Более сложный clamp старого offset по измеренному новому размеру возможен, но не обязателен для минимального scope. Anchor может быть Header, если человек просматривал длинную заметку; нельзя автоматически заменять его accepted Line

Отложенный запрос должен проверять owner и актуальность именно этой смены языка. Новый drag, явный выбор Line/Play/Return или следующий language request отменяет предыдущую компенсацию, чтобы старый anchor не перехватил более новое намерение. Программное восстановление viewport не должно распознаваться как пользовательский drag и писать pause

## Минимальная проверка

1. Открыть communion Original, принять другую Line, затем настоящей прокруткой уйти к нижней части указанной длинной Line. Зафиксировать ее key, реальный old offset/высоту и accepted state/writer count
2. Выбрать Russian. Проверить фактическое уменьшение измеренной высоты и что прежний offset для нового размера был бы избыточен; если actual fixture этого не создает на выбранном профиле, использовать явную синтетическую длинную/короткую пару в той же runtime-ленте, не ослаблять условие
3. Та же просматриваемая Line остается видимой, accepted другая Line не принимается/не центрируется. State/context/speed/offset и writer count прежние, manual browsing сохраняется
4. Отдельно owner replacement или новый drag до завершения reflow отменяет прежний запрос. Это viewport-тест, не новая проверка engine

Обычный перенос текста внутри той же видимой Line допустим. Полный уход просматриваемой Line и незапрошенный показ следующей из-за сохраненного слишком большого offset не соответствует обещанному semantic anchor. Scope ограничить сменой языка; остальные controls не расширять

Gradle/adb не запускались, source/tests не менялись. Конкретный pixel failure на эмуляторе reviewer не воспроизводил
