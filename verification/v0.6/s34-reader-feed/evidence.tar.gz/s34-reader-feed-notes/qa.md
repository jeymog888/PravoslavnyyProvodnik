# QA реализации 3.4

SOURCE FREEZE. Только unit/androidTest: 11 файлов (3 новых, 8 обновленных)

Это завершенная статическая подготовка проверок, не отчет о выполнении. Gradle, adb, git и harness не запускались. Production, assets, historical fixtures и goldens не изменялись

## Новый контракт и проверки

- `ReaderFeedTest`: 8 unit-проверок по настоящим packaged assets и Factory/Plan. Весь порядок Header/Line/Continuation для 8 и 9 ноября, единственность ключей, точный target по canonical ID, соседняя фраза только внутри этапа, отсутствие Original у Scripture-only, честные подписи типа текста и языка, идентичные слова с разными IDs, metadata без дополнительных строк, фактическое пересечение Text с viewport
- `ReaderFeedFlowTest`: 15 UI-проверок с `withCiFailureDiagnostics`, настоящим ServicePlayerState и управляемыми монотонными часами/отказом writer. Ниже указаны свидетельства каждого обязательного условия
- `FeedTestNodes`: один небольшой helper строит только canonical tags. Разрешение accepted track из сохраненного bookmark используется лишь прежними интеграционными проверками, а новые проверки live pause читают настоящий player

| Условие | Проверяемое свидетельство |
| --- | --- |
| Drag через track boundary | Настоящий swipe без предварительного tick, ровно 492 quarter-ms после boundary, paused live state, 2 writes, отсутствие обратного скачка; Return без записи |
| Drag через stage boundary | Pause материализует новый этап, старой Continuation нет, принятая новая Line видна, 2 writes и неизменный context |
| Только успешное действие фокусирует | Failed Line после boundary: 492 offset/3 writes, прежняя просматриваемая Line и ее bounds; rejected Play и selectTrack: прежние полные state/context/speed, точные 1/2 writes и отсутствие focus |
| Same-track explicit choice | Выбор уже принятого track возвращает к текущей Line без seek/write и без увеличения owner focusRequest |
| Owner identity | Captured Line/Return/next/previous после replacement на другую дату с теми же canonical IDs и завершившейся recomposition не меняют новый playing state/writer/viewport |
| Return только viewport | Ненулевой offset 1234, точное равенство полного чтения и отсутствие write. Частично видимая настоящая длинная фраза не включает Return. Play из другого track возвращает к прежнему offset и затем продолжает время |
| Ранний drag | Экран добавляется при manual test clock, до достижения выбранной Line выполняется реальный swipe, затем Return остается доступен и возвращает без записи |
| Геометрия Return | Normal narrow 320x800/1.3 и compact 320x640/2.6: >=120dp чтения, >=48dp видимая Return/primary, неизменные bounds viewport и primary при show/hide и ожидании, длинное название следующего этапа |
| Mixed Original | Accepted Scripture сохраняет русский Text и явную подпись, соседняя молитва сохраняет оригинал, preference true не переписывается; отдельный Scripture-only fixture выключает Original |
| Manual viewport + язык + Meaning | После реального swipe смена Original/Text не принимает просматриваемую Line и не переносит к accepted; видимый текст остается доступен. Meaning описывает accepted track, после явного tap описывает новый |
| Не-Text | BeforeStart/Wait/Missing/End фокусируют Continuation и не имеют Return. Большой tick на паузе не двигает; старую Line можно принять только явным tap, последняя Line имеет disabled next |

## Изменения прежних suites

| Suite | Что изменено |
| --- | --- |
| ArrivalFlowTest | 2 локальных индекса заменены canonical IDs принятого чтения |
| CompactReaderMatrixTest | Canonical Line и stage-wide supportsOriginal, прежние font/geometry/state assertions сохранены |
| ExpandedContentFlowTest | Feed context/speaker/language tags привязаны к реальному track/line, Meaning note остается прежней; metadata не принимают позицию |
| GuideNavigationTest | Canonical Line selectors и маленький acceptedTrack helper, жизненный цикл/дату/bookmark/полную видимость не ослаблял |
| ManualMomentFlowTest | Canonical selectors; landmarks используют свой expectedTrack, остальные сценарии настоящий creed |
| ReaderAccessibilityTest | Canonical selectors и Mixed Original доступен по всему этапу; >=120dp/>=48dp, настоящий font scale и полная видимость прежние |
| SavedReadingTest | Canonical IDs реального второго creed track, прежние рестарт/нормализация/bookmark/speed/offset без изменений |
| UnifiedPlayerFlowTest | Canonical selectors и честные mixed-language expectations, все точные времена/offset/live pause/date сохранены |

`ReaderStateFlowTest` и `Published05PlaybackIntegrationTest` не менялись. Две строки `lyric_line_` в Published05 - настоящие historical preference keys, они намеренно сохранены

## Самопроверка и исправления

- При миграции selector найдено неверное использование creed в цикле landmarks. Исправлено на expectedTrack конкретного этапа до freeze
- По замечанию parent перепроверены JSON и Factory: в текущей anaphora 7 headers / 22 lines, а не 8 headers из раннего proposal. Исправлены название unit и точное ожидание, assets не трогались
- В failed Line fixture выбран реальный boundary track1 -> track2 с короткими заголовками. Это отделяет ложный focus от допустимого изменения высоты header при track0 -> track1. Строгие bounds, offset 492, 3 writes и live state сохранены
- BeforeStart проверяется через настоящий preparation Wait: отдельного PlaybackSegment.BeforeStart в engine нет
- Перечитаны все 8 existing diffs и целиком новые tests/helpers. Устаревшие UI selectors lyric_line_i/prayer_speaker_i/original_unavailable/language_note/next_track не используются. Canonical keys в preferences не переименованы

## Запуск на стороне root

Предложенный набор: ReaderFeedFlowTest + 8 измененных suites + ReaderStateFlowTest + Published05PlaybackIntegrationTest. Статически это 117 UI-методов; фактическое число/результат должен подтвердить run. Unit: ReaderFeedTest (8 новых) вместе с обязательным общим набором root. Никакие PASS здесь не заявлены

Реальные жесты, ранний кадр и точная геометрия пока не исполнены: это тестируемые риски, не подтвержденная приемка. При FAIL нужны исходные diagnostics без retry или ослабления assertions до установленной причины

## Freeze

Manifest: `/private/tmp/feoria-v06-reader-feed-qa-freeze.json`
SHA256 manifest: `417993778af48d189a0ee93e54e759fa430f38103028464d3b68b92ae07b9336`

После этого freeze никаких source/test изменений без отдельного разрешения parent/root

| Файл | SHA256 |
| --- | --- |
| `app/src/androidTest/java/ru/liturgyguide/ui/ArrivalFlowTest.kt` | `9405d0299a8e8f0cfd1c59e5ddce7a8196aea7922cea047fe05f5a668a701317` |
| `app/src/androidTest/java/ru/liturgyguide/ui/CompactReaderMatrixTest.kt` | `049bf0dd07beb6785c28c0ef267954c09da867903f47a04d3160de7bc9f6bef7` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ExpandedContentFlowTest.kt` | `e0eefbcbe5b9192a687e1361754f118603ffc5dc15adfabe716d1c097c97c771` |
| `app/src/androidTest/java/ru/liturgyguide/ui/FeedTestNodes.kt` | `414104f976e2318b20a94fdc76be73f9602d0aaf4e2291f075b0a65821cfe55d` |
| `app/src/androidTest/java/ru/liturgyguide/ui/GuideNavigationTest.kt` | `d7f5deaa2715af1e0bb6a223f2c7c8c1dddb87a12e3150c228f9619214c3ed88` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ManualMomentFlowTest.kt` | `a2c8e69d92e11c6d70d5a1bdb6e2a185eaf6d2f1ea18b9db19b45de1e9aeafb9` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderAccessibilityTest.kt` | `e273a8d1b9a3dee1412a66969c6a48c9e132cffc4f7100dee0ead5eaf5e23b51` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderFeedFlowTest.kt` | `28367dde053965ec332a7a005fa1d92d38c831bc7bf291e28dcd3bca88bd1f56` |
| `app/src/androidTest/java/ru/liturgyguide/ui/SavedReadingTest.kt` | `426ce879cafcbba1072cc50b84472531e20481256df4f52c59dcac460020036a` |
| `app/src/androidTest/java/ru/liturgyguide/ui/UnifiedPlayerFlowTest.kt` | `2bb34e3e0d64cbfb9cb416bd8d9f03e37f800dd1efd31f4409e2ccb26457b32c` |
| `app/src/test/java/ru/liturgyguide/ui/ReaderFeedTest.kt` | `2aa84fba27e4c5fe1293227cac18a8a5088b5be260c1a46917f7aad35a9ea436` |

## Разрешенная узкая language reflow дельта после исходного freeze

Изменен только ReaderFeedFlowTest: добавлены 2 метода, теперь 17 новых UI-проверок. Остальные 10 QA-файлов побайтно соответствуют before-language manifest. Исходный freeze выше сохранен как история

Явный synthetic long/short fixture в настоящих Factory/Plan/ServiceScreen измеряет обе высоты и расстояние до следующей Line. Настоящий жест создает oldOffset больше нового измеренного item + spacing. Проверяется сохранение canonical anchor без принятия позиции и без записи. Второй метод отменяет pending restore новым реальным delta за 2 ms до кадра и отдельным owner replacement до кадра, с теми же canonical IDs. Local InputDispatcher bytecode подтвердил, что обычный swipe сам продвигает test clock, поэтому добавлен строгий свидетель elapsed <16 ms

Gradle/adb не запускались. Root/Astra приняли static review, фактический run остается за root

Предыдущий SHA256 теста: `28367dde053965ec332a7a005fa1d92d38c831bc7bf291e28dcd3bca88bd1f56`

Новый SHA256 теста: `c8d2a6c683c7f796f8bd2ad3c3ba49de2b88491d7b00ce50687ae94118dd1223`

Новый SHA256 существующего QA manifest: `9810adbbb0ee75fca01e640ad7ceccea12de0abfef5adc292f7db164ff55e035`

Повторный SOURCE FREEZE: дальнейшие изменения только по отдельному разрешению
