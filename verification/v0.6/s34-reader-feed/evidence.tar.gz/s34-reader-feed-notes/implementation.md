# Реализация 3.4 - лента текущего этапа

Runtime и тестовые файлы завершены. Объявлен общий SOURCE FREEZE. Gradle/adb не запускались, результатов тестов эта записка не заявляет

## Граница

База 23c555efd41eb8de636c793e51f0334739ee76c5. Runtime меняет только ServiceScreen.kt и новый ReaderFeed.kt. Engine/store/assets, canonical IDs, fingerprint и формула времени не изменены. Шрифты и старые caps не менялись, keep-awake и микрофон не добавлялись

## Поведение

- ReaderFeed строит Header/Line/Continuation из всех tracks только принятого stage, с постоянными canonical keys. Только actual Text выделяется; retainedText остается для смысла. Prev/next phrase пересекают границы tracks внутри stage, но не этапа или барьера
- Header показывает полное название без нового ограничения строк, тип полного текста/фрагмента, язык и локальную заметку. Speaker не кликабелен. Только нажатие Line вызывает seek
- Original доступен по всему stage, каждая Line отдельно выбирает доступный язык. Accepted Scripture получает "По-русски" в существующей шапке, его Header сохраняет точное название перевода. Meaning остается о принятом track, global preference не перезаписывается при Scripture
- ReaderViewport содержит только временный owner generation+fingerprint+stage, LazyListState, manual intent, focus request и геометрию. Принятой позиции/часов в нем нет. Новый track сохраняет тот же viewport; новый stage/owner заменяет его
- NestedScrollConnection.onPreScroll(UserInput) синхронно отмечает ручной просмотр и отменяет focus job до pause и до первого потребленного delta. Остальные delta/fling не пишут повторно. Pause может материализовать уже прошедшую границу, но ее focusRequest подавляется ручным просмотром
- Play/seek/selectTrack возвращают viewport только после true. Same-track selection тоже имеет местный explicit focus. Перед seek ручной intent подавляет boundary focus, если writer откажет. Отложенное следование повторно проверяет owner/manual после кадра
- Return проверяет пересечение bounds именно Text, а не speaker/header; длинная частично видимая Line считается видимой. Return вызывает только локальный focus, без методов player/writer. Для Wait/Missing/BeforeStart/End Return отсутствует, цель следования - единственная Continuation
- Feed subtree, Return и новые prev/next phrase ограничены key(owner), primary сохраняет key(generation). Старые captured semantic wrappers не обновляют callback на нового владельца после recomposition
- Return занимает место вторичных controls. Normal slot измеряет max навигационной строки и Return в обоих режимах. Compact Return144dp заменяет3x48dp, сохраняя primary width, а слот резервирует естественную высоту Return. Probes не интерактивны, не размещаются и очищают semantics; скрытых действий и новых caps нет

## Самопроверка и найденные дефекты

1. При первом черновике отмена initial animateScroll настоящим drag оставляла initiallyFocused=false навсегда и скрывала Return. Исправлено до freeze: browse разрешает Return после уже состоявшегося layout, сохраняя запрет ложного Return до него. Root независимо подтвердил тот же риск
2. Root подтвердил, что замена многострочной navigation row коротким Return меняла viewport и могла образовать цикл видимости. Исправлено измерением обеих естественных высот. Аналогичная compact проверка сохраняет ширину primary и max высоты. Никаких новых ограничений font scale
3. Astra раннее review указало reused semantic wrapper у новых adjacent buttons. Добавлены owner keys каждому, как feed/Return. QA добавляет поздние действия после завершившейся recomposition
4. Root заметил отсутствие типа полного текста/фрагмента у соседнего Header. Тип соединен с существующей строкой языка, без новой постоянной панели

Полный runtime перечитан: boundary на same stage и новый stage, ошибка writer после pause, same-track no focusRequest, Meaning return, пустой stage, Scripture-only fallback, stale coordinates и owner replacement. git diff --check чистый. Реальная geometry и input подтверждаются только последующим root запуском

## Финальный review и SOURCE FREEZE

Перечитаны все 8 existing UI diffs, новый helper, все 8 unit и 15 UI методов. QA manifest 11 файлов проверен по SHA и размеру. Общий manifest содержит 13 файлов: 2 runtime + 11 test. Изменений вне этого списка нет

Предложенный root набор 117 UI методов: ru.liturgyguide.ui.ReaderFeedFlowTest, ArrivalFlowTest, CompactReaderMatrixTest, ExpandedContentFlowTest, GuideNavigationTest, ManualMomentFlowTest, ReaderAccessibilityTest, SavedReadingTest, UnifiedPlayerFlowTest, ReaderStateFlowTest, Published05PlaybackIntegrationTest. Первые 9 содержат новые или измененные проверки; последние 2 сохраняют state/migration договоренности. Unit добавлены 8 ReaderFeedTest; фактические результаты должен получить root. Diagnostics при запуске требуют оба feoriaCiDiagnostics=true и feoriaCiDiagnosticsRun

Самопроверка QA исправила неверный expected count из раннего proposal: настоящая anaphora имеет 7 Header / 22 Line. Failed Line fixture изолирует focus на boundary двух коротких заголовков, сохраняя точные bounds/492 offset/3 writes. Historical assets/goldens не менялись

Root и Astra отдельно оценивают точный manual language reflow случай с существенно разной длиной оригинала и перевода. По указанию root реализация не расширяется до конкретного решения reviewer. Текущий freeze не означает приема этого риска

- Manifest: /private/tmp/feoria-v06-reader-feed-freeze.json
- Полный diff, включая новые файлы: /private/tmp/feoria-v06-reader-feed.diff
- QA: /private/tmp/feoria-v06-reader-feed-qa.md
- Aggregate SHA-256: `d87ff56db4fb6dc840ee98b4f41baa8e6879106e138eb31b34866da49fb72d8d`

После freeze implementer и QA не меняют source/tests без отдельного разрешения root. Gradle/adb/commit не выполнялись, PASS не заявлен

## Final language delta - supersedes the earlier pending review

Root and Astra accepted the narrow language correction and both new tests. Only ServiceScreen.kt and ReaderFeedFlowTest.kt differ from the preserved before-language freeze; the other 11 files are byte-identical. All 13 SHA/byte sizes and the complete QA manifest were verified. Explicit manual language changes retain the semantic key at offset 0, and later user input cancels the pending restoration without player calls/writes. The two tests use an explicitly synthetic measured shrink fixture and pre-frame cancellation witnesses. Final count: 8 new unit methods, 17 new UI methods, 119 proposed targeted UI methods. No Gradle/adb execution or PASS claim. Final aggregate SHA-256: 3e8e44877ed2b6e0e491d9d3abde708aa7b2bf4332405192506aff2bb57a610f
