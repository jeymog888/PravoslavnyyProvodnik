# Root review 3.4 перед уточнением смены языка

Прочитаны оба runtime файла, новый unit, новый UI suite, canonical helper и полный diff всех 8 измененных existing suites. Проверены все 13 SHA/bytes и точное множество измененных файлов по freeze d87ff56db4fb6dc840ee98b4f41baa8e6879106e138eb31b34866da49fb72d8d. Gradle/adb для 3.4 еще не запускались, PASS не заявляется

Порядок feed и адреса соответствуют actual плану; stage/owner key, synchronous drag до pause, успешный explicit focus, viewport-only Return, Scripture fallback и retained-only Meaning логически согласованы. Root лично разобрал normal max-height probes и compact 144dp replacement трех 48dp controls; probes не интерактивны и не размещаются. Геометрия пока требует исполнения tests

До freeze закрыты обнаруженные в раннем ревью: отмена первого focus скрывала Return навсегда, height смены secondary могла вызвать цикл viewport, adjacent semantic wrappers могли сменить callback нового owner, Header не показывал тип соседнего фрагмента. Новые тесты проверяют реальные жесты/offset 492/state/writes/geometry и old Line/Return/next/previous после recomposition. Rejected Play/selectTrack и same-track focus включены без ослабления исходных assertions. Изменения прежних suites в основном canonical selectors; Mixed Original expectation осознанно stage-wide. Рестарт/дата/темп/bookmarks/offset/lifecycle и 120dp/48dp сохранены

Проверка фактических assets подтвердила 7 anaphora texts и 22 lines, а не 8 из раннего proposal. Ожидание исправлено; контент не менялся

Единственный дополнительный hold перед запуском - manual language shrink. Root лично прочитал exact LazyListMeasure bytecode 596-646 и key repair LazyListScrollPosition: меньший элемент может быть пропущен старым offset. Принят минимальный контракт сохранить видимый semantic key и выровнять к его началу после языка, без player/write и без отключения manual; новый пользовательский intent/owner отменяет запрос. Разрешена узкая runtime/UI delta с сохранением исторического freeze. После нее нужны точное review delta и независимое окончательное Astra review, затем root build/test
