#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380" "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s34-reader-feed-r2/first-failure-1794188438380.export.txt"
exit "$result"
