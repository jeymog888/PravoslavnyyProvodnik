# 3.5a R9 navigation code review

ACCEPT для предложенной сборки и целевых UI. NOT_RUN этим reviewer. Геометрия и новая native визуальная приемка еще не заявляются

Окончательный freeze /private/tmp/feoria-v06-font-navigation-freeze-r9-root.json, aggregate 070297b19228567213c76b09fe6d93d9367e4861dfcf9fef57bda8379b0b484e. Все 19 текущих файлов сверены по SHA/bytes, linked delta SHA cfe4c64e8b43b8001e8c241501e402f154a641d79f5f1ce508d7e638266c1f6f совпал. Прочитан весь delta шести файлов и контекст двух тестов

Runtime соответствует принятому ограниченному контракту

- FeoriaBrand - единый Canvas artwork. Только измерение artwork использует fontScale1; нет provider вокруг пользовательского текста. Native density сохранена, оба слова измерены целиком без wrap, графика пропорционально уменьшается при недостатке ширины. Единое русское accessible имя сохранено. Реальная полнота painted glyph потребует нового PNG, semantics bounds сами по себе ее не доказывают
- Nav - прежний native labelMedium/12sp без maxLines cap, ru locale, auto hyphenation, centered text. Колонки имеют общий верх icon row и одинаковую естественную высоту, selectableGroup/Role.Tab/selected сохранены. Поведение callback не меняется
- Main Church/Settings при showBack=false имеют полный heading первым LazyColumn item с прежним headlineLarge и явной heading semantics. Нет дублирующего fixed title или нового adaptive predictor. При showBack=true PageHeader остается прежним. Данные, выбор храма, draft, reading и writer не меняются
- Reader layout, converter и playback остаются точными R6. Нет оснований повторять полный unit набор ради этой визуальной правки после R7 435 PASS; компиляция и запланированные UI нужны

Проверки содержательны: nav полные glyph/visible bounds, native12sp и native curve metrics, не более двух естественных строк только в конкретном 320dp/2.6 oracle, без isolated single letter; >=48dp targets, общая icon top и непересечение. У обоих screens >=300dp сохранено. Heading полностью readable и действительно внутри scroll ancestor. Platform проходит font cycles/recreation, возвращается к title и выбранной строке, сравнивает размер и видимость logo без подмены native text oracle

Найдены и исправлены root до запуска два blockers исходного freeze

1. После scroll к settings_title прямой lookup text_size мог обращаться к уже не composed item. Добавлен parent settings_content.performScrollToNode до lookup и прежнего performScrollTo/assertIsSelected
2. DpRect.width/height нового brandSize требовали imports. Cached Compose1.7.3 javap подтвердил extensions в DpKt, а не члены DpRect. Явные imports добавлены

Оба исправления перечитаны в финальном файле. Assertions не ослаблены, production delta не расширен. Очевидных оставшихся ошибок компиляции или поведения не найдено

После target UI нужны actual OS2 Platform и новые native nav кадры. Старые native nav REJECT и R6 FAIL сохраняются. Результаты старых reader PNG не превращаются в доказательство новых nav экранов

Source/test edits, Gradle и adb reviewer не выполнял
