# R9 centered navigation failures

Вердикт: ACCEPT runtime-направления Text(title, Modifier.fillMaxWidth(), ...), но одного этого изменения недостаточно для корректности текущего NativeFontAssertions. Нужна явная одинаковая paragraph width в oracle, без снятия line/glyph/bounds проверок

R9 UI XML лично прочитан: 48 методов, 46 PASS, 2 FAIL

- ReaderAccessibilityTest:212/274/402: "Храм", TextLayoutResult.size 204x96, reconstructed lineRight выходит за size.width
- ReaderPlatformFontTest:79/209, NativeFontAssertions:18: "Служба" при native1.0, predictedLeft0, actualLeft108

Причина согласуется с уже доказанным механизмом cached Compose1.7.3. При TextAlign.Center ширина synthesized semantics paragraph теперь влияет не только на didOverflowWidth, но и на lineLeft/lineRight. Короткий реальный String Text shrink-wrap, Column центрирует сам node. Semantics восстанавливает MultiParagraph при maxWidth родителя, сохраняя прежний узкий layoutSize. Поэтому glyph extents в восстановленном paragraph нельзя автоматически считать реальным clipping данного рисунка

Лично перечитан /private/tmp/feoria-v06-font-ParagraphLayoutCache-javap.txt:619-717. slowCreateTextLayoutResultOrNull offsets66-80 обнуляет minWidth/minHeight через Constraints.copy mask10, сохраняя maxWidth/maxHeight; offsets114-117 передает эти constraints в TextLayoutInput, offsets142-164 создает широкий MultiParagraph, offset166 берет прежний layoutSize

Отсюда важное ограничение: fillMaxWidth сделает реальный Text node равным ячейке и исправит несоответствие line extents и node bounds, но semantics все равно отдаст input.minWidth0. Текущий NativeFontAssertions использует input.constraints без нормализации, а TextMeasurer снова shrink-wrap короткую строку

Дополнительно лично прочитан cached TextMeasurer$Companion через javap из /private/tmp/feoria-ui-text-1.7.3.jar. Offsets173-200: если minWidth != maxWidth, paragraph width выбирается ceil(maxIntrinsicWidth).coerceIn(min,max). Поэтому predictedLeft0 при centered short text может остаться после одного fillMaxWidth

Минимальный корректный oracle: сравнивать native TextMeasurer при той же ширине paragraph, что actual.multiParagraph.width, то есть фиксировать minWidth=maxWidth этой шириной, сохранив text/style/placeholders/resolver/native density и остальные constraints. Оставить все нынешние lineCount, lineLeft/right/top/bottom, baseline, native conversion, visible/unclipped bounds, 48/300 assertions. Это выравнивание пространства размещения, не ослабление проверки масштаба glyph

Для новых full-width centered nav labels дополнительно проверить actual.size.width == actual.multiParagraph.width: тогда проверяемые позиции совпадают с реальной шириной node. Не заменять geometry на ненадежный hasVisualOverflow и не увеличивать допуски

Никаких исходников или тестов не менял, Gradle/adb не запускал. Это статически подтвержденный механизм и preflight коррекции; PASS следующего запуска не заявляется. R9 FAIL сохраняется
