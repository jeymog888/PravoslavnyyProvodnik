#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r9/first-failure-1794202654404.export.txt"
exit "$result"
