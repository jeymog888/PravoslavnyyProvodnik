# Независимый разбор 3.5a r2

Вердикт: REQUEST_CHANGES для текущего runtime, ACCEPT_WITH_CONDITIONS для перехода на штатный Density и следующей диагностической реализации compact layout

Это read-only проверка. Gradle/adb не запускались, исходники не менялись. Текущий r2 остается FAIL: 11/18 cases PASS, 3 UI метода, 2 FAIL. Лично просмотрены новые PNG text для всех трех профилей; все 18 кадров не объявляются лично принятыми

## Доказанные причины

1. В 320x640 у Text/Wait/End реальное поле чтения 66.2857 dp вместо 120 dp. Двухстрочное имя этапа занимает 120 dp текста, вместе с внешним padding 128.38 dp. Следующая строка выбора режима около 54.86 dp. Зарезервированный статус до трех строк остается высоким даже когда видимый paused status имеет две строки. Это реальный недостаток высоты, не ложный hasVisualOverflow
2. В 640x360 у Text/Wait/Before/End выбран COMPACT и поле 55.619 dp. SIDEBAR отвергается рассчитанной высотой панели. Missing/Meaning уже выбирают SIDEBAR и имеют поле около 251.43 dp. Поэтому нужно исправлять расчет и состав компактной панели, а не растягивать body поверх footer
3. В 400x800 все шесть cases PASS. Это не доказательство корректности custom converter: при 2.6 текущая Compose factory обычно возвращает линейную ветку и ошибочно разные пути здесь совпадают
4. Главная интеграционная ошибка: AppTextDensity и LinearStressDensity корректны при прямом вызове их методов, но фактический Text в Compose 1.7.3 не сохраняет эти overrides. TextStringSimpleNode.measure получает MeasureScope и передает именно его как Density в ParagraphLayoutCache. TextAnnotatedStringNode делает то же для MultiParagraphLayoutCache. NodeCoordinator копирует только density/fontScale из LayoutNode. Цепочка MeasureScopeWithLayoutNode -> MeasureScope -> IntrinsicMeasureScope -> Density наследует default SP-конверсию FontScaling, которая вновь строит converter по metadata fontScale. TextMeasurer получает переданный LocalDensity непосредственно. Следовательно renderer и предварительный расчет используют разные функции

Это объясняет непригодность линейной экстраполяции: реальный title "Символ веры" при профиле 1.69 имеет lineRight 435.46875 px, при 2.6 - 780.0469 px. Отношение около 1.79, а не 2.6/1.69. Разницу нельзя исправлять дополнительным runtime padding. Замена String на AnnotatedString или добавление onTextLayout не устраняет потерю converter

Проверенные bytecode файлы:
- /private/tmp/feoria-v06-font-TextStringSimpleNode-javap.txt, метод measure и getLayoutCache(Density)
- /private/tmp/feoria-v06-font-TextAnnotatedStringNode-javap.txt, строки 734-746, measure передает MeasureScope
- /private/tmp/feoria-v06-font-NodeCoordinator-javap.txt, getDensity/getFontScale; преобразований SP/DP не переопределяет
- /private/tmp/feoria-v06-font-LookaheadCapablePlaceable-javap.txt и /private/tmp/feoria-v06-font-MeasureScopeWithLayoutNode-javap.txt
- /private/tmp/feoria-v06-font-TextPaintExtensions-javap.txt, SP -> Density.toPx -> setTextSize
- /private/tmp/feoria-v06-font-scaling/androidx.compose.ui.unit.FontScaling.txt и DensityKt.txt

Foundation и ui-text classes.jar сверялись с actual cached 1.7.3 AAR в предыдущем bytecode review. Шесть unit методов доказывают прямую математику AppTextDensity, но не ее применение настоящим Text. Их прежний PASS не является приемкой production pipeline

## Пересмотр внутреннего контракта масштаба

Лично открыт первичный источник Android: https://developer.android.com/develop/ui/compose/accessibility/scalable-content, раздел Font scaling, обновление 2026-10-22. Он рекомендует Density(parent.density, parent.fontScale * factor) и прямо предупреждает, что изменение factor не означает пропорциональный рост glyph. Это соответствует обычному пути Compose и не требует пользовательского обещания численного коэффициента

Принимаю этот вариант с условиями. Новая модель C_(S*A)(sp) не равна прежней A*P_S(sp). Отказ от прежней формулы должен быть явно записан как исправление внутреннего плана, а старые линейные assertions и название linear у профилей сняты с доказательной базы. Настройки "Обычный", "Крупный", "Очень крупный", сохраненные preferences и исходные SP остаются прежними

Необходимо сохранить:
- Один native Density с неизменным физическим density и fontScale S*A, одинаковый для TextMeasurer и реального Text, без вторичного умножения A, компенсации SP или caps
- Реальное сравнение измеренного Text и TextMeasurer при одинаковом style/font resolver/width, включая fontSize и lineHeight. Проверка только значения metadata fontScale недостаточна
- Реальные system 200% с A=1/1.15/1.3, прежние три geometry profiles, 28sp reading, 120dp body, 48dp targets и отсутствие скрытых строк
- Фактические glyph extents/ellipsis/maxLines/visible bounds вместо известного ложного semantics hasVisualOverflow. Precision fields сохранить
- Проверку Dialog/Sheet/Popup и возврата к экрану после изменения настройки, без потери чтения

Особенность cached Compose 1.7.3 выше 2.0 и зависимость интерполяции от factory cache остаются. Штатный путь их не исправляет. Нельзя называть результат A-кратным увеличением или считать 2.3/2.6 гладким продолжением кривой 2.0. Измерять текущий renderer, не заменять его самодельным линейным oracle

## Минимальный продуктовый вариант

NIGHT_PLAN 3.5a требует доступности вторичных сведений без уменьшения SP, а не постоянной фиксации всей provenance над кнопками. Поэтому допустимо оставить полное текущее имя этапа, reading 28sp, live pause/transition, primary и прямой подписанный будущий микрофон, а "сохранено" перенести из COMPACT/SIDEBAR status в явно доступные подробности и полную accessible status. Normal остается прежним. Это конкретное осознанное изменение прежнего требования always-visible restored

Для 320 текущий дефицит около 53.7 dp. Одна естественная строка status около 54.86 dp: сокращение максимального transport sample с трех строк до двух уже дает около 121 dp. Это кандидат, не подтвержденный fit. Root вариант переноса "Без звука" в подписанное Управление с полной accessible state также допустим для stress, поскольку действие "Двигать текст" остается явно названным. Меньшие вертикальные padding допустимы при сохранении реальных 48dp targets

Строгие условия к предложенным коротким статусам:
- "Пауза · примерно" нельзя заранее считать одной строкой при 2.6; измерять все transport samples на фактической ширине
- Снятие "по-русски" нельзя обосновывать тем, что chooser уже показывает "По-русски": при Original + Scripture fallback он показывает "Оригинал". Русский текст должен иметь честную явную подпись в своем Header и доступных подробностях, сохраненный выбор Original не меняется. Нужен именно mixed-case check
- Meaning/Missing/End сохраняют полное объяснение состояния в body/details и accessible status; отсутствие текста не превращается в свидетельство завершения реальной службы
- Если shortTitle переносится в три строки, проверить его фактическую высоту и все fixed controls совместно. Ни номер вместо имени, ни обрезание, ни уменьшение SP не считаются решением
- Stable max height paused/playing и Return slot, owner guards, visible-line anchor/cancellation, no-write browsing остаются без изменения

Итог: разрешить следующую минимальную реализацию native Density + компактного состава вторичных сведений. Приемка геометрии остается NOT RUN до нового witness, текущие r1/r2 FAIL сохраняются
