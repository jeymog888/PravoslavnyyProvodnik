# Compose 1.7.3 - разбор overflow из semantics

Найден конкретный механизм, объясняющий системность r1: short single-line Text может получать didOverflowWidth=true в синтезированном GetTextLayoutResult даже при полностью помещающихся буквах. Это пока вывод по bytecode и рисунку r1, точный численный witness должен подтвердить его для каждого спорного случая. Нет разрешения ослабить истинные clipping/120dp/48dp проверки

## Проверенные первичные локальные артефакты

- ui-text-android 1.7.3 classes.jar SHA 633f4048e469bcfea4c4de1ec7f98a28e816cb991b99b9b4874316adb827be32. /private/tmp/feoria-ui-text-1.7.3.jar побайтно по SHA совпадает с classes.jar внутри cached ui-text-release.aar
- foundation-android 1.7.3 classes.jar SHA 30ad4cfbb0cd76c75210223803d6d290eb80ee1183aa2608561be0614bab73e9. /private/tmp/feoria-foundation-1.7.3.jar совпадает с classes.jar cached foundation-release.aar
- javap запускался локальным JDK17, не Gradle/adb. Сохранены /private/tmp/feoria-v06-font-{ParagraphLayoutCache,TextStringSemantics,AndroidParagraph,MultiParagraph,TextLayout,TextMeasurer,ParagraphKt}-javap.txt; TextLayoutResult ранее сохранен в /private/tmp/feoria-TextLayoutResult-javap.txt

## Цепочка по bytecode

1. TextStringSimpleNode$applySemantics$1.invoke вызывает ParagraphLayoutCache.slowCreateTextLayoutResultOrNull (offset69). Это именно GetTextLayoutResult быстрых обычных Text
2. ParagraphLayoutCache-javap:619-717: slowCreate берет существующий density, prevConstraints, обнуляет minWidth/minHeight, оставляя maxWidth/maxHeight (copy mask10). Создает новый MultiParagraph при этих constraints, но TextLayoutResult.size берет из прежнего layoutSize (offset166)
3. Реальный быстрый Paragraph layout использует ограниченную intrinsic ширину. В пути повторного measure bytecode явно вычисляет min(maxIntrinsicWidth, paragraph.width), ceilToIntPx и constrain. Поэтому короткая строка может иметь size.width намного меньше prevConstraints.maxWidth
4. MultiParagraph constructor offset325-330 записывает width = constraints.maxWidth.toFloat. TextLayoutResult.didOverflowWidth строго сравнивает size.width < multiParagraph.width. Ни glyph bounds, ни getLineRight в этом флаге не проверяются. hasVisualOverflow - OR этого флага и didOverflowHeight
5. Отсюда ожидаемый случай: size.width=807px, input.maxWidth/multiParagraph.width=1008px, lastLineRight<=807px, height помещается. Флаг width=true отражает ширину контейнера нового semantics paragraph, а не потерю букв. Конкретные1008/807 - проверяемая гипотеза по сохраненным r1 bounds, не уже снятая пара mpWidth/size

Это согласуется с наблюдением: одна короткая строка часто true, многострочная при полном maxWidth часто false. Одного совпадения рисунка недостаточно для изменения assertion без точных полей

## Почему Float epsilon высоты менее вероятен

AndroidParagraph.getHeight вызывает TextLayout.getHeight():Int и только затем i2f. TextLayout.getHeight складывает целые Android Layout height/lineBottom, topPadding, bottomPadding, lastLineExtra. MultiParagraph складывает эти целочисленные высоты как Float; для небольших обычных экранных размеров суммы целых представлены точно. Width также приходит из Int constraints. Поэтому гипотеза112.00001px вместо112px для этого Android пути не поддерживается bytecode как основное объяснение

LinearStressDensity делает только SP<->DP, не изменяет paragraph Int rounding. Его положительные конечные density/fontScale и явная линейность сохранены. Он не доказывает настоящее platform200%, но не объясняет описанную подмену ширины semantics

## Поля следующего precision witness

Для каждого текста записать: полный текст/style, node visible/unclipped bounds и actual root position; TextLayoutResult.size; input constraints min/max обеих осей; multiParagraph.width/height; didOverflowWidth, didOverflowHeight, hasVisualOverflow; lineCount/didExceedMaxLines; по каждой строке start/end/visibleEnd, left/right/top/bottom, ellipsis; maxIntrinsicWidth/minIntrinsicWidth. Разницы mpWidth-sizeWidth и mpHeight-sizeHeight записывать численно без округления до dp. При подозрении на epsilon добавить Float.toRawBits/hex

## Строгий геометрический критерий

Фиксированные controls/title/status должны сохранять проверку полного node visible против unclipped по обеим осям, прежние допуски и pairwise no-overlap, а targets >=48dp. Реальный reading viewport >=120dp не зависит от TextLayoutResult

Для текста сохраняются отсутствие didExceedMaxLines и ellipsis каждой строки, покрытие полного текста строками, lineLeft>=0/lineRight<=actual text layout width и lineTop>=0/lineBottom<=actual text layout height с уже существующим допуском1px, отсутствие взаимного наложения строк. Эти границы проверяются также в root coordinates относительно видимой области для fixed текста. Для scrollable текста действует ранее принятая последовательная доступность строк, а не требование всего элемента сразу

Допустимая классификация semantics width artifact только после precision подтверждения: didOverflowWidth=true, multiParagraph.width равен исходному maxWidth, размер узла уже (shrink-wrapped), реальные line extents полностью внутри него, didOverflowHeight=false, текст полный/noellipsis/noMaxLines и node не обрезан. Здесь бессодержательный assertFalse(hasVisualOverflow) можно заменить указанным доказательством; нельзя просто удалить все overflow проверки или добавить произвольную погрешность к флагу

didOverflowHeight, реальные выходы line extents и несовпадение полного текста не подпадают под это исключение. Если они обнаружены, это отдельный отказ, требующий причины. Runtime padding или SP не менять ради одного реконструированного semantics-флага. Root и implementer уведомлены

Repo не менял, Gradle/adb не запускал. Bytecode-механизм установлен, точное применение к r1 ожидает новых полей

## Подтвержден уже принятый критерий из HEAD

Лично прочитан git show 2aef9c6:app/src/androidTest/java/ru/liturgyguide/ui/ReaderAccessibilityTest.kt, assertReadable около354. Он прямо документирует Compose1.7.3 String Text semantics с более широким MultiParagraph и проверяет реальные line extents вместо неиспользованной paragraph width. Сохраняются didExceedMaxLines, ellipsis, четыре line extents с1px, полный visible/unclipped node с1px

Новый ReaderFontLayoutWitnessTest.completeLayout уже содержит эти line checks плюс отсутствие перекрытия соседних строк; readable отдельно сохраняет node bounds. Следовательно ACCEPT узкой test-only коррекции: удалить только ненадежный assertFalse(layout.hasVisualOverflow), оставить все эти проверки без изменения допусков. Это восстановление уже принятого оракула с независимо проверенным bytecode основанием, не ослабление полноты отображения и не runtime padding

Отдельный build ради повторного установления известного механизма не нужен. Precision fields оставить в следующем согласованном diagnostic для объяснения конкретных случаев. Действительные нулевые/86dp viewport и цель40dp не затрагиваются этой коррекцией, их отказы остаются реальными

Эта подтвержденная существующая проверка снимает необходимость ждать отдельного precision-only запуска перед исправлением оракула; более ранняя осторожная формулировка выше описывала состояние до обнаружения принятого прецедента
