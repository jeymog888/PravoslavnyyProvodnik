#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r2/reader-font-witness/400x800-linear-2.6/wait/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
