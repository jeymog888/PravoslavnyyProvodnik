package ru.liturgyguide.ui

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit

/** Scale the platform's actual conversion, not the input of its nonlinear font curve. */
@Immutable
internal class AppTextDensity(private val parent: Density, private val appFactor: Float) : Density {
    init { require(appFactor.isFinite() && appFactor > 0f) }

    override val density: Float get() = parent.density

    // Metadata for layout choices only. Never construct a converter from this product.
    override val fontScale: Float get() = parent.fontScale * appFactor

    override fun TextUnit.toDp(): Dp = with(parent) { this@toDp.toDp() } * appFactor
    override fun Dp.toSp(): TextUnit = with(parent) { (this@toSp / appFactor).toSp() }

    // Density's default SP/PX and rounding methods dispatch through these overrides.
    // Do not delegate Density to parent: delegated convenience methods would bypass them.
}
