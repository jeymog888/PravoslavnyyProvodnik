package ru.liturgyguide.ui

import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import org.junit.Assert.*
import org.junit.Test

class AppTextDensityTest {
    @Test fun `each app setting preserves an explicitly linear parent including its inverse`() {
        val parent = LinearParent(density = 2f, fontScale = 2f)
        val expected = listOf(Triple(1f, 48f, 96f), Triple(1.15f, 55.2f, 110.4f), Triple(1.3f, 62.4f, 124.8f))
        for ((factor, dp, px) in expected) {
            val wrapped = AppTextDensity(parent, factor)
            assertEquals(2f, wrapped.density, 0f)
            assertEquals(2f * factor, wrapped.fontScale, .00001f)
            with(wrapped) {
                assertEquals(dp, 24.sp.toDp().value, .0001f)
                assertEquals(px, 24.sp.toPx(), .0001f)
                assertEquals(24f, dp.dp.toSp().value, .0001f)
                assertEquals(24f, px.toSp().value, .0001f)
            }
        }
    }

    @Test fun `nonlinear parent is scaled after conversion on both sides of its breakpoint`() {
        val parent = NonlinearParent()
        // Independent oracle: f(s)=2s through 20sp; f(s)=40+1.25(s-20) afterwards.
        // The last column is a real paragraph lineHeight input, not a fontScale multiplier.
        val sizes = listOf(12f, 20f, 24f, 32f, 39.2f)
        val expected = listOf(
            1f to listOf(24f, 40f, 45f, 55f, 64f),
            1.15f to listOf(27.6f, 46f, 51.75f, 63.25f, 73.6f),
            1.3f to listOf(31.2f, 52f, 58.5f, 71.5f, 83.2f))
        for ((factor, values) in expected) with(AppTextDensity(parent, factor)) {
            sizes.zip(values).forEach { (sp, dp) ->
                assertEquals("$sp sp at app factor $factor", dp, sp.sp.toDp().value, .0001f)
                assertEquals(sp, dp.dp.toSp().value, .0001f)
            }
        }
        with(AppTextDensity(parent, 1.3f)) {
            assertEquals(58.5f, 24.sp.toDp().value, .0001f)
            assertEquals(117f, 24.sp.toPx(), .0001f)
            assertEquals(24f, 58.5.dp.toSp().value, .0001f)
        }
    }

    @Test fun `SP PX convenience methods and rounding dispatch through the wrapped conversions`() {
        with(AppTextDensity(NonlinearParent(), 1.15f)) {
            assertEquals(103.5f, 24.sp.toPx(), .0001f)
            assertEquals(104, 24.sp.roundToPx())
            assertEquals(127, 32.sp.roundToPx())
            assertEquals(24f, 103.5f.toSp().value, .0001f)
            assertEquals(20f, 92.toSp().value, .0001f)
            assertEquals(20f, 92f.toSp().value, .0001f)
        }
        with(AppTextDensity(NonlinearParent(), 1.3f)) {
            assertEquals(24f, 117.toSp().value, .0001f)
            assertEquals(24f, 117f.toSp().value, .0001f)
            assertEquals(117, 24.sp.roundToPx())
        }
    }

    @Test fun `app font factors do not change DP PX or physical target rounding`() {
        for (factor in listOf(1f, 1.15f, 1.3f)) with(AppTextDensity(NonlinearParent(), factor)) {
            assertEquals(96f, 48.dp.toPx(), 0f)
            assertEquals(6.5f, 3.25.dp.toPx(), 0f)
            assertEquals(7, 3.25.dp.roundToPx())
            assertEquals(-6, (-3.25).dp.roundToPx())
            assertEquals(48f, 96.toDp().value, 0f)
            assertEquals(3.25f, 6.5f.toDp().value, 0f)
        }
    }

    @Test fun `Em and Unspecified retain the actual parent failure contract in all SP conversion paths`() {
        val parent = Density(density = 2f, fontScale = 1f)
        val wrapped = AppTextDensity(parent, 1.3f)
        for (unit in listOf(2.em, TextUnit.Unspecified)) {
            val operations: List<(Density) -> Any> = listOf(
                { density -> with(density) { unit.toDp() } },
                { density -> with(density) { unit.toPx() } },
                { density -> with(density) { unit.roundToPx() } })
            operations.forEach { operation ->
                val expected = runCatching { operation(parent) }.exceptionOrNull()
                val actual = runCatching { operation(wrapped) }.exceptionOrNull()
                assertNotNull("The real parent must reject $unit", expected)
                assertNotNull("The wrapper must not invent a numeric value for $unit", actual)
                assertEquals(expected!!::class.java, actual!!::class.java)
                assertEquals(expected.message, actual.message)
            }
        }
    }

    @Test fun `switching parent and app settings has no conversion history or cumulative scaling`() {
        val nonlinear = NonlinearParent()
        val linear = LinearParent(density = 3f, fontScale = 1.5f)
        val first = AppTextDensity(nonlinear, 1.3f)
        assertEquals(58.5f, with(first) { 24.sp.toDp().value }, .0001f)
        val changes = listOf(
            Triple(linear, 1f, 36f), Triple(nonlinear, 1.15f, 51.75f),
            Triple(linear, 1.3f, 46.8f), Triple(nonlinear, 1f, 45f), Triple(nonlinear, 1.3f, 58.5f))
        for ((parent, factor, expectedDp) in changes) {
            val current = AppTextDensity(parent, factor)
            assertEquals(expectedDp, with(current) { 24.sp.toDp().value }, .0001f)
            assertEquals(24f, with(current) { expectedDp.dp.toSp().value }, .0001f)
        }
        assertEquals(140.4f, with(AppTextDensity(linear, 1.3f)) { 24.sp.toPx() }, .0001f)
        assertEquals(58.5f, with(first) { 24.sp.toDp().value }, .0001f)
        assertEquals(117f, with(first) { 24.sp.toPx() }, .0001f)
    }

    private class LinearParent(override val density: Float, override val fontScale: Float) : Density {
        override fun TextUnit.toDp(): Dp {
            check(type == TextUnitType.Sp)
            return (value * fontScale).dp
        }
        override fun Dp.toSp(): TextUnit = (value / fontScale).sp
    }

    /** Deliberately explicit nonlinear oracle; it does not use Android's cached factory. */
    private class NonlinearParent : Density {
        override val density = 2f
        override val fontScale = 2f
        override fun TextUnit.toDp(): Dp {
            check(type == TextUnitType.Sp)
            return (if (value <= 20f) 2f * value else 40f + 1.25f * (value - 20f)).dp
        }
        override fun Dp.toSp(): TextUnit = (if (value <= 40f) value / 2f else 20f + (value - 40f) / 1.25f).sp
    }
}
