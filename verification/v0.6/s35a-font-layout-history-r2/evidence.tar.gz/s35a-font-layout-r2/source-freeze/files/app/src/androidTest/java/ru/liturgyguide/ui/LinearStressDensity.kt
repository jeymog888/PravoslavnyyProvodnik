package ru.liturgyguide.ui

import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnitType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Synthetic linear stress profile, deliberately distinct from Android's real nonlinear parent. */
internal class LinearStressDensity(override val density: Float, override val fontScale: Float = 1f) : Density {
    init { require(density.isFinite() && density > 0f && fontScale.isFinite() && fontScale > 0f) }

    override fun TextUnit.toDp(): Dp {
        check(type == TextUnitType.Sp) { "Only Sp can convert to Px" }
        return (value * fontScale).dp
    }

    override fun Dp.toSp(): TextUnit = (value / fontScale).sp
}
