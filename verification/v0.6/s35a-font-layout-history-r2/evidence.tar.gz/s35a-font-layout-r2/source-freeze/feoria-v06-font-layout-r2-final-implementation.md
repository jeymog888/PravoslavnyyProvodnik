# 3.5a corrective diagnostic iteration

r1 remains recorded as 6 wrapper unit PASS and 3 UI methods FAIL across 18 attempted state/profile cases. This r2 is not a release or stage acceptance

Changed runtime

- Compact: full-width stage heading at the original 18sp/25sp, then explicit 48dp Back and menu with one selected-mode chooser between them. At 320dp the stage text receives 270dp, without an added gap
- Full-width compact primary, then a separate signed direct action with its future microphone label measured and a permanent 48dp Return/Pause slot. Status retains saved and approximate facts; a 24dp soundless icon uses a measured 8dp gap
- Sidebar: selected-mode chooser inside the panel, rather than requiring three tabs above the reading area. Normal three-tab composition remains
- Missing uses visible "Прочитано" with the existing full action description and body explanation. BeforeStart while playing uses "Переход"; the visible stage heading already says "До начала", and full accessibility status is unchanged
- Layout measurement follows these exact widths, gaps and natural heights. No font reduction or density change was added. StableReaderText probes and viewport/owner/cancellation behavior are unchanged

Witness correction

- Each completed PNG/JSON pair is copied before instrumentation teardown into the existing shell-owned run directory, validated with cmp and a completion marker. The r1 external-path loss cannot be hidden by a later successful capture
- JSON now records precise paragraph dimensions, layout constraints, line geometry and overflow flags
- The known Compose 1.7.3 String semantics MultiParagraph width artifact is handled by the existing ReaderAccessibilityTest oracle: actual line extents, line limit, ellipsis, visible bounds and overlap remain strict. Only the redundant hasVisualOverflow assertion was removed

Self-review

Read the exact four-file delta. All original font sizes and owner/generation checks remain; no engine, state, assets or time calculations changed. The real r1 body collapse and 40dp menu target are corrected in composition. Actual fit is still unproven until root runs the 18 physical witness cases. The earlier communicated 32.2dp arithmetic estimate was an error; the same stated quantities leave 132.2dp, before actual wrapping and rounding

Validation

Static diff check passed. QA reviewed the mirror API and public Compose baseline API. No Gradle or adb was run by implementer or QA. The six numeric tests are unchanged from r1. Actual Android parent 200% coverage, dependent suite adaptation and native acceptance remain pending

SOURCE FREEZE after this manifest. Only root may authorize further changes

Final root review correction: witness mirroring is opt-in. With feoriaCiDiagnostics=true an explicit valid run and completed mirror are mandatory; ordinary test runs retain external capture and geometry checks without a pre-created shell directory. This fixes the unconditional-mirror regression before r2 execution
