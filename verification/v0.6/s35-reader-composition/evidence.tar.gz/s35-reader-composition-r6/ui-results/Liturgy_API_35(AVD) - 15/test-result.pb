
	�
�
CompactReaderMatrixTestru.liturgyguide.ui=epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle2�����ɐ�:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-epistleAt412DpRetainsTheRequestedClarifyScaleAndTheWholeTitle.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
CompactReaderMatrixTestru.liturgyguide.uiJacceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid2��������:�����"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-acceptingTheSameReadingRefreshesControlsWhileCapturedOldActionsStayInvalid.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
CompactReaderMatrixTestru.liturgyguide.ui>readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause2��������:�����ʬt"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-readingDetailsUseTheAcceptedDateAndTheStageMaterializedByPause.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui:staleDetailsActionCannotPauseOrDescribeAReplacementReading2�������x:������ǣ"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-staleDetailsActionCannotPauseOrDescribeAReplacementReading.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.ui=nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement2�����߸�:�������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-nextStageUsesTheCurrentlyDisplayedStageAfterAutomaticMovement.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiMallEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice2�����Ɲ�:�������&�
�java.lang.AssertionError: Clipped node: Херувимская: до Великого входа; visible=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=443.42856.dp) full=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=446.09525.dp)
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.assertTrue(Assert.java:42)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertReadable(CompactReaderMatrixTest.kt:311)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertTrackHeader(CompactReaderMatrixTest.kt:289)
at ru.liturgyguide.ui.CompactReaderMatrixTest.allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice(CompactReaderMatrixTest.kt:50)
java.lang.AssertionError�java.lang.AssertionError: Clipped node: Херувимская: до Великого входа; visible=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=443.42856.dp) full=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=446.09525.dp)
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.assertTrue(Assert.java:42)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertReadable(CompactReaderMatrixTest.kt:311)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertTrackHeader(CompactReaderMatrixTest.kt:289)
at ru.liturgyguide.ui.CompactReaderMatrixTest.allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice(CompactReaderMatrixTest.kt:50)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenPortraitStageNamesRemainWholeWithLargeTextAndAnApproximationNotice.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
CompactReaderMatrixTestru.liturgyguide.uiFlongTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale2�������8:���������
�java.lang.AssertionError: Clipped node: Херувимская: после Великого входа; visible=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=443.42856.dp) full=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=446.09525.dp)
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.assertTrue(Assert.java:42)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertReadable(CompactReaderMatrixTest.kt:311)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertTrackHeader(CompactReaderMatrixTest.kt:289)
at ru.liturgyguide.ui.CompactReaderMatrixTest.longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale(CompactReaderMatrixTest.kt:109)
java.lang.AssertionError�java.lang.AssertionError: Clipped node: Херувимская: после Великого входа; visible=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=443.42856.dp) full=DpRect(left=24.0.dp, top=195.80952.dp, right=296.0.dp, bottom=446.09525.dp)
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.assertTrue(Assert.java:42)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertReadable(CompactReaderMatrixTest.kt:311)
at ru.liturgyguide.ui.CompactReaderMatrixTest.assertTrackHeader(CompactReaderMatrixTest.kt:289)
at ru.liturgyguide.ui.CompactReaderMatrixTest.longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale(CompactReaderMatrixTest.kt:109)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-longTrackNamesWrapAndLanguageChangesKeepTheCanonicalPhraseAndFullScale.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
CompactReaderMatrixTestru.liturgyguide.uiAallEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace2��������:�����؈2"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-allEighteenLandscapeNamesKeepFullAccessibleContextAndReadingSpace.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
CompactReaderMatrixTestru.liturgyguide.uiBcompactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized2�������?:������ƹ"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.CompactReaderMatrixTest-compactSavedReadingExposesItsDateWithoutPretendingToBeSynchronized.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain