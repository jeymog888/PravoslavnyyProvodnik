from pathlib import Path
import json, subprocess, sys
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
run=repo/'app/build/verification/v0.6/s35-reader-composition-native-r2'
case='gospel-original-light'
def call(script,*args):
 subprocess.run([sys.executable,'/private/tmp/'+script,*map(str,args)],check=True)
def tap(selector,expected):
 call('feoria-v06-native.py','tap',run,case,json.dumps(selector,ensure_ascii=False),json.dumps(expected,ensure_ascii=False))
call('feoria-v06-reader-fixture.py',run,'text','light',0)
call('feoria-v06-native.py','show',run,case)
tap({'text':'Сохраненное чтение'},[{'text':'Миром Господу помолимся','checked':True}])
tap({'content-desc':'Порядок службы'},[{'text':'Чтение Евангелия'}])
tap({'text':'Чтение Евангелия'},[{'content-desc':'Действия со службой'}])
tap({'content-desc':'Действия со службой'},[{'text':'Тексты этапа'}])
tap({'text':'Тексты этапа'},[{'text':'Тексты этого этапа'},{'text':'От Матфея 8:23-27'}])
tap({'text':'От Матфея 8:23-27'},[{'text':'На паузе · по-русски'}])
call('feoria-v06-native.py','capture',run,case)
print('Gospel captured; personal image review still required')
