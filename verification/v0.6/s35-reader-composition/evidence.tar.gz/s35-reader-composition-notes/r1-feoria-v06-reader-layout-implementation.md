# Композиция читателя 3.5

Runtime и тестовые изменения готовы к независимой проверке. Gradle/adb/commit implementer и QA не выполняли. База 21c284b7bdf9ff6c45bc8c85fdadff124e1f26e2

Изменены только ServiceScreen.kt и небольшой readerVisibleStatus в ReaderPresentation.kt. ReaderFeed, canonical ID/индексы, plan/engine/store/assets и формула времени не менялись. Все существующие font caps, 20sp/28sp и формула текста остаются до отдельного этапа 3.5a

## Композиция

- Короткая шапка содержит Back, видимое название этапа/Порядок и Действия. Три режима остаются видимыми. В landscape они стоят в одном ряду с переносимым shortTitle, без ellipsis/numeric-only. Постоянные дата/track header/top notices удалены
- Выбор текста доступен через Действия -> Тексты этапа, с прежним sheet/bookmarks. Дата, полный этап/текст/основание и миграционная заметка остаются в Открытом чтении
- Одна reader_surface содержит feed или Meaning. Progress больше не отдельная карточка. Meaning - заголовки, текст и интервалы на одной поверхности. Все cues, context, day-note и source disclosure сохранены. Неактивные фразы onSurface, текущая отличается весом и маркером
- Миграционная заметка встроена в первый Header этапа либо Continuation без tracks, а в Meaning - в начало прокручиваемого содержания. Она не занимает фиксированную область, не перемещается между Header на track boundary и не меняет feed indices. Preview уже объясняет восстановление; постоянно держать заметку над текущей фразой не требуется
- Footer содержит один primary, видимый live status и подписанное Управление. Status сохраняет основание сохраненного/примерного места, а actual Text с mixed Original показывает по-русски. Без звука сохраняется. Дата в Missing остается точной
- Прямой secondary Уточнить делит заранее измеренный slot с Return; оба варианта резервируют max естественных высот без скрытых действий. В BeforeStart playing этот slot занимает обязательная Pause. Коррекция во всех состояниях также доступна в Управление -> Уточнить место через тот же callback
- Управление открывает sheet без pause/write/сброса manual viewport. Там прежние prev/next phrase, темп и stage transitions в допустимых состояниях. Порядок и уточнение доступны всегда. Все item keys стабильны при Text->Wait; owner keys и generation guards сохранены. Темп не требует новой паузы

## Самопроверка

Реальный дефект черновика: previousStage повторно проверял stage owner после обязательной pause и мог отменить допустимый явный переход, если pause материализовала boundary. Исправлено: owner проверяется до pause, generation после нее, аналогично существующему nextStage. Позицию по-прежнему меняет только явный action

Еще исправлена лишняя оговорка по-русски для Meaning/Wait: она относится только к actual Text с выбранным Original. По раннему root review добавлены стабильные keys в меняющий состав controls list; по решению root/Astra добавлен controls_clarify для достижимости коррекции из BeforeStart playing

Перечитаны owner/callback routes, открытие управления без pause, успешный/неуспешный seek, все 6 представлений, mixed Scripture, migration note и исходные source/day/context сведения. git diff --check чистый. Фактические размеры и визуальный результат еще должен подтвердить root запуском и native PNG; арифметический layout budget не является приемкой

## Проверки для root

Добавлены 5 содержательных unit cases видимого статуса и 8 UI cases композиции. Обновлены 11 прежних UI suites и общий feed helper; новые ReaderTestControls задают только явные пути по настоящему UI. Целевой прогон - 434 unit (429 прежних + 5 новых) и 127 UI methods в 12 suites

UI suites: ArrivalFlowTest, CompactReaderMatrixTest, ExpandedContentFlowTest, GuideNavigationTest, ManualMomentFlowTest, Published05PlaybackIntegrationTest, ReaderAccessibilityTest, ReaderFeedFlowTest, ReaderStateFlowTest, SavedReadingTest, UnifiedPlayerFlowTest, ReaderCompositionFlowTest

Сохранены проверки offset/date/bookmarks/writes, live pause, failed writes, stale callbacks после recomposition, language anchors и geometry 120dp/48dp. Удаленные постоянные date/track header проверяются через канонические Line/track ID либо детали в уже остановленных сценариях. Запрещенные transports проверяются в открытом controls sheet, а не по отсутствию закрытого popup

До сборки root обнаружил и QA исправил два реальных дефекта тестовой подготовки: неоднозначный single для трех Gospel на 8 ноября и ScrollBy/UserInput вместо программного ScrollToIndex при подготовке stale action над playing reading. Outcomes не ослаблены, добавлен playing witness перед callbacks. Чистый formatter не получил искусственного purity-loop теста

BeforeStart UI case проверяет реальную композицию и callback с pause в Harness; это не полный navigation journey. Перенаправленный ManualMomentFlowTest отдельно проходит настоящий AppNavigation correction route и проверяет сохраненные offset/context

Все тесты и нативные экраны на этом freeze еще NOT_RUN. Два diagnostics аргумента при запуске задает root. Source freeze означает отсутствие дальнейших правок без отдельного разрешения root
