from pathlib import Path
import json, subprocess, sys
repo = Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
run = repo / 'app/build/verification/v0.6/s35-reader-composition-native-r2'
manifest = json.loads((run / 'manifest.json').read_text())
def call(script, *args):
    subprocess.run([sys.executable, '/private/tmp/' + script, *map(str, args)], check=True)
for case_id in sys.argv[1:]:
    case = next(c for c in manifest['cases'] if c['id'] == case_id)
    assert case_id != 'gospel-original-light', 'Gospel is a separate observed UI journey'
    kind = case['conditions']['fixture']
    theme = case['conditions']['theme']
    print('Preparing ' + case_id, flush=True)
    call('feoria-v06-reader-fixture.py', run, kind, theme, 0)
    call('feoria-v06-native.py', 'show', run, case_id)
    arrival = ([{'text': 'Миром Господу помолимся', 'checked': True}, {'content-desc': 'Двигать текст'}]
               if kind == 'meaning' else case['expected'])
    call('feoria-v06-native.py', 'tap', run, case_id,
         json.dumps({'text': 'Сохраненное чтение'}, ensure_ascii=False), json.dumps(arrival, ensure_ascii=False))
    if kind == 'meaning':
        call('feoria-v06-native.py', 'tap', run, case_id,
             json.dumps({'text': 'Смысл'}, ensure_ascii=False), json.dumps(case['expected'], ensure_ascii=False))
    call('feoria-v06-native.py', 'capture', run, case_id)
    print('Captured ' + case_id + '; human review still required', flush=True)
