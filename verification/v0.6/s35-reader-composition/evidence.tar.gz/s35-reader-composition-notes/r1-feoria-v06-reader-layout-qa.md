# QA 3.5: композиция чтения

SOURCE FREEZE. Только unit/androidTest: 15 файлов (3 новых, 12 обновленных, включая FeedTestNodes)

Gradle/adb/коммиты не выполнялись. Это статически проверенная подготовка, а не PASS сборки или UI. Runtime/assets/historical fixtures/harness не менялись

## Новые проверки

- ReaderVisibleStatusTest: 5 содержательных unit. Literal ожидания для paused/playing/Wait/BeforeStart/Meaning/Missing/End, приоритет сохраненного чтения, отсутствие повторения приблизительности, видимый русский fallback только у TEXT. Используются настоящие packaged plan/readings. В 8 ноября ровно 3 Scripture Gospel tracks; выбран первый после явной проверки количества
- ReaderCompositionFlowTest: 8 UI с withCiFailureDiagnostics. Единая reader_surface и 3 режима, шесть состояний без прежних постоянных date/track/notices; Controls open/dismiss без pause/write и без сброса manual viewport; доступные границы фразы/темп/предыдущий этап с материализацией boundary; owner-guard старых callbacks после replacement/recomposition; достижимость migration note в first Header/Meaning/details/empty Continuation; BeforeStart playing с прямой Pause и controls_clarify; normal/landscape Return slot без изменения viewport/primary/control bounds, 120dp/48dp
- ReaderTestControls: маленькие явные UI paths open/read/dismiss controls, menu-to-tracks, details. Нет retries, conditional fallback, прямого player доступа или вычисления ожидаемого статуса production presenter

## Адаптация существующих проверок

- Arrival: точная дата через details и прежние context/start/offset/recreation assertions; расчетное место имеет видимый полный статус
- CompactReaderMatrix: full stage names и caps прежние; полный track title проверяется в реальном feed, после чего возвращается та же selected Line. Captured controls берутся явно из menu/sheet. Approximate/restored теперь reader_status + details
- ExpandedContent: прежний выбор track через явный пункт меню, остальные content/position assertions сохранены
- GuideNavigation: явные controls/menu/details пути, canonical Line/bookmark/lifecycle и видимость сохранены. В narrow landscape реальные пункты sheet доступны вместо старых постоянных иконок
- ManualMoment: full title через details; остановка из controls_clarify проверяется настоящим AppNavigation сценарием correctionStopsPhraseScrollingAndCancelKeepsThePausedPhrase с прежним offset 4936 и restoration/cancel assertions
- Published05: migrationNote helper получает явный container lyrics_list/service_content и прокручивает до заметки. Три resume с устаревшим marker имеют literal restored=true. Preview с wrongMarker(now) и явные order/correction/new reading остаются обычной паузой. Date/fingerprint/offset/writes/bookmarks не менялись
- ReaderAccessibility: clipping/ellipsis/полная видимость/120dp/48dp/overlap прежние. Постоянные targets теперь primary/Уточнить/Управление, пункты sheet проверяются отдельно внутри открытой панели. Actual fontScale/20sp/28sp сохранены до 3.5a
- ReaderFeedFlow: прежние boundary/failed write/stale callback/language shrink/state/offset/writer/geometry проверки сохранены; adjacent callbacks захватываются явно из открытого sheet. Mixed Russian видим в reader_status
- ReaderStateFlow: реальные lifecycle/state guards и primary labels сохранены; noTransport открывает Controls и проверяет отсутствие запрещенных actions там, а не в закрытом sheet
- SavedReading: сохраненная позиция явно подписана в status, после начала новой службы подпись исчезает; прежние bookmarks/normalization/restart остаются
- UnifiedPlayerFlow: live Play сверяет canonical track/Line без открытия details или пользовательской прокрутки; Missing/End запрещают next внутри открытого Controls. Все точные времена и offsets сохранены, статус отражает isApproximate после реального Play/pause

## Самопроверка и исправления до freeze

- Исправлено неверное single Scripture в unit: реальные current assets имеют 3 Gospel tracks. Лишний purity-loop удален по root review, осталось 5 содержательных cases
- В stale Controls setup заменен accessibility ScrollBy-путь на canonical ScrollToIndex. Перед вызовом старых callbacks есть явный live playing witness, иначе подготовка сама бы поставила чтение на паузу
- Убраны ожидания постоянных current_track_title/reading_service_date/topnotice. Их смысл проверяется в details/feed/status; отсутствие старого узла само по себе не считается доказательством содержимого
- Сверены все прямые обращения к previous/next/tempo tags: действия и отрицательные проверки используют открытый Controls. Общий helper не скрывает captures/noTransport
- Pause после Play сохраняет isApproximate; успешный явный seek сбрасывает. Статусы обновлены по этим конкретным переходам, точные player/store assertions не заменены подписью
- BeforeStart новый UI-тест использует callback observer и настоящий ServicePlayerState.pause, это не полный AppNavigation journey. Настоящий маршрут correction проверяется измененным ManualMomentFlowTest

## Набор для root

Статически: 127 UI-методов в 12 затронутых suites, 5 новых unit. Фактическое число/результат подтверждает только root run

| UI suite | Методов |
| --- | --- |
| ArrivalFlowTest | 10 |
| CompactReaderMatrixTest | 9 |
| ExpandedContentFlowTest | 4 |
| GuideNavigationTest | 27 |
| ManualMomentFlowTest | 9 |
| Published05PlaybackIntegrationTest | 11 |
| ReaderAccessibilityTest | 9 |
| ReaderCompositionFlowTest | 8 |
| ReaderFeedFlowTest | 17 |
| ReaderStateFlowTest | 8 |
| SavedReadingTest | 4 |
| UnifiedPlayerFlowTest | 11 |

До реального run остаются проверяемыми рисками: фактические геометрия и font/insets профили, системный ModalBottomSheet и timing. Native PNG review нужен отдельно; эта запись его не заменяет

## Freeze

Manifest: `/private/tmp/feoria-v06-reader-layout-qa-freeze.json`
SHA256 manifest: `136919f27b68e34d44dc148a8156d0af0887ce774f2223c86c5cc13d544679f4`

После freeze никаких test/source изменений без разрешения parent/root

| Файл | SHA256 |
| --- | --- |
| `app/src/androidTest/java/ru/liturgyguide/ui/ArrivalFlowTest.kt` | `bcede1eedee6b27b21057178a79fe1e5563dfd09f759d21f7a2328e61d5c3046` |
| `app/src/androidTest/java/ru/liturgyguide/ui/CompactReaderMatrixTest.kt` | `543e6922e2a2a604002317c60046236aad5ac7348dd137c3e040cdce7bae3333` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ExpandedContentFlowTest.kt` | `00c2ed445ce0340c8096fca5038388b2f20b4bc0a98392b7dda6ba5c5f2c461c` |
| `app/src/androidTest/java/ru/liturgyguide/ui/FeedTestNodes.kt` | `066d8cd76e18605a9c634dbe73c95d13a48e394861a82369c1e2c54a98134c31` |
| `app/src/androidTest/java/ru/liturgyguide/ui/GuideNavigationTest.kt` | `c9aed74d271136c9164b6418c9124d07af48992debdb0e79afe4fd564311b46b` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ManualMomentFlowTest.kt` | `6bf3b7cf980db1e5a27aed153b48b4b57072ea5f7398f61397579fa4bd532fb8` |
| `app/src/androidTest/java/ru/liturgyguide/ui/Published05PlaybackIntegrationTest.kt` | `003b9b14993d7a79b9822a22b016b796e11e7dd08b4b9536fdfd5e90c3ca01e9` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderAccessibilityTest.kt` | `2b128e3562b095ff2967b40b5b7a0633fedfa2b6c23cb74f4fac76419b165732` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderCompositionFlowTest.kt` | `e0cbd13bda7019175aa7c8d7d9485219342430177ad865555829c9a66dbcba99` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderFeedFlowTest.kt` | `7e1964a2c466162ab29abf46098d082b4981ad08189edd5aefbf1dba602cde4e` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderStateFlowTest.kt` | `57fb24a43e41602e4d2d4bba99e66063ce9e74bebfa4268c8cb5b3927b113292` |
| `app/src/androidTest/java/ru/liturgyguide/ui/ReaderTestControls.kt` | `0a971cf8c55c4af73f484ef82a6ca72cd66237fe883882505a835233472515c9` |
| `app/src/androidTest/java/ru/liturgyguide/ui/SavedReadingTest.kt` | `cfdd6e47765bd1a3959cee0c790bdc7e9a08283423acbb9a1878d746981c560a` |
| `app/src/androidTest/java/ru/liturgyguide/ui/UnifiedPlayerFlowTest.kt` | `0fcb419e58beb201c5c01f6bef3b5d7f38050f1aa4ad145ca53a23dff24b5617` |
| `app/src/test/java/ru/liturgyguide/ui/ReaderVisibleStatusTest.kt` | `e7627e5d01946622b2abd81798eed81d20c605bb70cc76ae64d476957cac8d87` |
