# Root correction after 3.5 r2/r3

r1: 434 unit PASS, UI NOT_RUN because the test missed its dp import. r2: 127 UI, 115 PASS, 12 FAIL. r3 diagnosis: both selected failures repeated with unchanged production and unchanged assertions

- Language: reader viewport stayed [42,475,798,1216]px; the browsed phrase was [139,673,735,965] before the switch. The first partly visible Header was restored at its start and became [105,538,735,1170], removing the phrase. Root and Astra personally viewed r2 PNG. The fix prioritizes an actually intersecting prayer Line, with Header fallback when no prayer is visible
- Pause: status height changed from 99px to 43px, reader bottom 1160->1216 while primary/secondary stayed exactly equal. At the end of the list the phrase shifted 31px. The fix reserves measured play/pause status heights; primary labels receive the same protection for narrow landscape. Actual text remains fully scaled at the unchanged 3.5 cap contract; 3.5a is still separate
- Seven checks failed because the unmerged test tree saw the measurement probe Text as a second Уточнить. Semantics are now cleared on the Text itself, without weakening the unique real-label assertion
- One additional compact language case lost its accepted Line, consistent with the same anchor problem
- Two accessibility header setup paths threw SnapshotStateObserver while Compose test output printed semantics during performScrollToNode. The setup now targets exact canonical Header/Line indices, retaining all full-text, clipping, font, position and geometry outcomes

Two existing geometry cases additionally check Play/Pause viewport and button stability, live offset+404, two writes and unchanged context/speed. No playback/storage/content data was changed. Temporary r3 logging was preserved with its exact source then removed from the shipping tests

The r4 source freeze is a candidate. No fix is claimed PASS until actual execution
