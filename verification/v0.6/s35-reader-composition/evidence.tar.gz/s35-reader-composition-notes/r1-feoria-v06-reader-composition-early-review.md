# 3.5 - раннее review композиции

ACCEPT_WITH_CONDITION для продолжения реализации и QA, не финальная приемка. Прочитан runtime diff ServiceScreen.kt и ReaderPresentation.kt относительно 21c284b. Исходники еще меняются, тесты не заморожены, запусков нет

## Открытый конкретный пункт

ServiceScreen.kt:561-564, ReaderSecondarySlot: при BEFORE_START + isPlaying вместо "Уточнить" показывается "Пауза". В этом состоянии Controls содержит только "Порядок службы" (245-275), поэтому прямой вход уточнения исчезает. Остановка примерного перехода нужна и сохранена, но переданный контракт требует direct "Уточнить". Исключение для Text + Return согласовано, для BeforeStart + Pause пока не зафиксировано. Минимальное условие до final review - согласовать этот конкретный вариант либо сохранить прямое уточнение, не убрав возможность остановить переход. Это UX расхождение, не свидетельство потери чтения

## Проверенные участки

- ServiceScreen.kt:543-576: reserve secondary slot равен max натуральных высот Return и Clarify в одинаковых constraints. Return measure совпадает с кнопкой по bodySmall, horizontal padding 8dp, minimum 48dp; Clarify measure использует тот же clarifyDensity, labelLarge, padding 6dp и minimum 48dp. showReturn не меняет величину резерва. Неинтерактивные probes не добавляют скрытые действия. Короткая "Пауза" при нынешнем capped PlayerControlScale укладывается в резерв; после удаления caps в 3.5a этот вывод нужно измерить заново
- ServiceScreen.kt:513-534: normal и landscape используют один и тот же measured secondary slot. В portrait его ширина остается половиной строки, в landscape 144dp. Primary не заменяется Return и имеет отдельный стабильный key(generation). Landscape оставляет 112dp на "Управление" и делит остаток между status и primary. Это конкретная раскладка для измерения, не доказательство 120dp во всех состояниях
- controlsOpen remember(owner), открытие/закрытие Controls не вызывает pause, browse, requestFocus или изменение языка. Tempo entry только закрывает Controls и открывает существующий tempo dialog, сохраняя playing. Выбор фразы идет через прежний owner-aware seekLine, который не изображает успешный фокус при отказе writer
- Root уже обнаружил positional identity риск Text -> Wait внутри прежнего owner. В последнем повторном чтении ServiceScreen.kt:240-270 у всех шести controls items стоят постоянные смысловые keys. Это устраняет переиспользование места предыдущей/следующей фразы под tempo/stage. Сами sheet и opening button имеют key(owner), действия проверяют owner.matches. Дополнительного подтвержденного stale-owner дефекта в перенесенных controls не найдено
- ServiceScreen.kt:662,705: migration note входит в первый Header этапа, либо в существующий Continuation при отсутствии tracks. Новых feed items нет, ReaderFeed не менялся, canonical indices и keys прежние. Граница accepted track внутри этапа не переносит note между Header. Meaning показывает note в своем scroll, а details сохраняет полный текст
- ReaderPresentation.kt:20-26: visibleStatus сохраняет реальный presentation status, добавляет restored либо approximate основание и для TEXT + Original + отсутствующего original у принятого track добавляет "по-русски". В последнем чтении suffix уже ограничен TEXT, поэтому не приписывает этот режим Missing/Meaning. В Scripture-only этапе эффективный Original false и выбран "По-русски", что согласовано с прежней логикой
- Одна reader surface содержит либо feed, либо Meaning. Внутренний Progress стал Column, Meaning sections больше не отдельные карточки. Неактивные строки используют onSurface, выбранная строка сохраняет weight и вертикальный маркер. Store, player engine и правила принятия чтения этой правкой не меняются

## До финальной приемки

Нужны frozen diff/test review, проверки открытия/закрытия Controls без изменения playing/manual viewport, Text -> Wait с открытыми controls и старых callbacks после replacement, Return geometry в normal/landscape, note на границе tracks и реальные PNG. Существующие font caps и pipeline здесь намеренно не исправляются и остаются обязательством 3.5a. Крупный шрифт, точная доступная высота чтения и fit длинных статусов пока NOT VERIFIED. Ни Gradle, ни adb не запускались, repo не редактировался

## Условие BeforeStart закрыто фактическим delta

Root согласовал узкое исключение: при BEFORE_START + playing остановка остается одним прямым действием, как Return в ручном просмотре. В текущем ServiceScreen.kt controls sheet содержит item(key = "clarify") с "Уточнить место", tag controls_clarify. Callback проверяет owner.matches, закрывает controls и вызывает прежний clarify(). Пункт доступен во всех состояниях. Поэтому уточнение доступно за два нажатия через явно подписанное "Управление", без дополнительной строки footer

Прочитан новый UI runningPreparationKeepsPauseDirectAndClarificationReachableInControls: проверяет прямую Pause >=48dp, отсутствие прямого Clarify в этом исключении, открытие Controls и явный выбор "Уточнить место", остановку с offset404 и двумя writes. Пока NOT RUN. Ранее открытое UX условие считаю разрешенным

## Предварительное чтение тестов до freeze

Прочитаны ReaderTestControls, 8 методов ReaderCompositionFlowTest, 5 методов ReaderVisibleStatusTest и diff 12 прежних UI/helper файлов. Новый helper использует реальные entry/menu/sheet actions, проверяет displayed и 48dp, не вызывает player напрямую для UI действий и не добавляет retries. Два выявленных root до build дефекта уже исправлены: actual Gospel scriptures count3 вместо single и ScrollToIndex для playing setup старых controls вместо ScrollBy(UserInput), с отдельным isPlaying свидетельством

Старые проверки даты/track перенесены на явный details/menu/feed путь. Проверки hidden controls выполняются также внутри открытого sheet, поэтому не стали бессодержательными из-за переноса кнопок. 120dp, размеры48dp, clipping/overlap, state/offset/date/speed/write assertions сохранены. Ограничение track title двумя строками снято по согласованному переносу полного названия в scroll, при этом assertReadable остается. Static blockers в прочитанном тестовом delta не найдены. Итоговые SHA и последнее delta требуется сверить после freeze
