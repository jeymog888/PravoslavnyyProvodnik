# R11 Platform selected-row correction

ACCEPT узкой test-only правки перед R12 expectedSystemFontScale2

Лично прочитан R11 UI XML: отказ ReaderPlatformFontTest.kt:69 при assertIsSelected после performClick. Сообщение точно говорит "The node is no longer in the tree", last known tag text_size_2 / "Очень крупный". Последнее Selected=false относится к уже отсутствующему node, не доказывает, что новый размер не принят. Данный отказ сам по себе не устанавливает runtime crash или ошибку сохранения

После клика изменение шрифта закономерно допускает reflow и смену состава LazyColumn. Поэтому завершить click, затем выполнить settings_content.performScrollToNode(hasTestTag(text_size_$setting)), заново получить node и выполнить performScrollTo/assertIsDisplayed/assertIsSelected - корректный setup наблюдения нового UI

Не делать второй click, retry loop, условный skip или подмену UI выбранности чтением preferences. Проверки selected, preference, actual parent/native glyph, reader state/bookmarks/speed и recreation должны остаться. Это не ослабление assertions, а получение актуального элемента после размерного перехода

Текущий R11 остается FAIL. Точная product причинность сверх удаления node не заявляется до результата R12. Runtime не требуется менять. Source не редактировал, Gradle/adb не запускал

## R12 exact freeze

ACCEPT окончательного R12 freeze aggregate 5d49cf660e0f62c5f2aa0975ef1ee9169a92f7cdd9198a85ba457a4090adb1d7. Все 19 SHA/bytes сверены. От R10 изменен только ReaderPlatformFontTest; exact diff с архивом R10 содержит разделение click, parent LazyColumn scroll и fresh node.performScrollTo/assertIsSelected. Второго click или удаления assertions нет, runtime неизменен. Разрешенный scope следующего root запуска - только Platform actual OS2, PASS пока не заявляется
