
�%
�
ReaderPlatformFontTestru.liturgyguide.uiDnativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation2Ľ������:Խ�������
�java.lang.AssertionError: Failed to assert the following: (Selected = 'true')
The node is no longer in the tree, last known semantics:
Node #1804 at (l=63.0, t=1583.0, r=1017.0, b=1742.0)px, Tag: 'text_size_2'
IsTraversalGroup = 'true'
Role = 'RadioButton'
Focused = 'false'
Selected = 'false'
Text = '[Очень крупный]'
Actions = [OnClick, RequestFocus, SetTextSubstitution, ShowTextSubstitution, ClearTextSubstitution, GetTextLayoutResult]
MergeDescendants = 'true'
Has 2 siblings
Original selector: TestTag = 'text_size_2'

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:165)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.AssertionsKt.assert(Assertions.kt:263)
at androidx.compose.ui.test.AssertionsKt.assert$default(Assertions.kt:255)
at androidx.compose.ui.test.AssertionsKt.assertIsSelected(Assertions.kt:84)
at ru.liturgyguide.ui.ReaderPlatformFontTest.nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation$lambda$4(ReaderPlatformFontTest.kt:69)
at ru.liturgyguide.ui.ReaderPlatformFontTest.$r8$lambda$yGuUBUDM_NzpsINDgDhbxFW9EH8(Unknown Source:0)
at ru.liturgyguide.ui.ReaderPlatformFontTest$$ExternalSyntheticLambda0.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderPlatformFontTest.nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation(ReaderPlatformFontTest.kt:55)
java.lang.AssertionError�java.lang.AssertionError: Failed to assert the following: (Selected = 'true')
The node is no longer in the tree, last known semantics:
Node #1804 at (l=63.0, t=1583.0, r=1017.0, b=1742.0)px, Tag: 'text_size_2'
IsTraversalGroup = 'true'
Role = 'RadioButton'
Focused = 'false'
Selected = 'false'
Text = '[Очень крупный]'
Actions = [OnClick, RequestFocus, SetTextSubstitution, ShowTextSubstitution, ClearTextSubstitution, GetTextLayoutResult]
MergeDescendants = 'true'
Has 2 siblings
Original selector: TestTag = 'text_size_2'

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:165)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.AssertionsKt.assert(Assertions.kt:263)
at androidx.compose.ui.test.AssertionsKt.assert$default(Assertions.kt:255)
at androidx.compose.ui.test.AssertionsKt.assertIsSelected(Assertions.kt:84)
at ru.liturgyguide.ui.ReaderPlatformFontTest.nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation$lambda$4(ReaderPlatformFontTest.kt:69)
at ru.liturgyguide.ui.ReaderPlatformFontTest.$r8$lambda$yGuUBUDM_NzpsINDgDhbxFW9EH8(Unknown Source:0)
at ru.liturgyguide.ui.ReaderPlatformFontTest$$ExternalSyntheticLambda0.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderPlatformFontTest.nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation(ReaderPlatformFontTest.kt:55)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderPlatformFontTest-nativeSystemFontCurveSurvivesAppSettingsWindowsAndActivityRecreation.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain