#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35a-font-system200-r11/first-failure-1794203346597.export.txt"
exit "$result"
