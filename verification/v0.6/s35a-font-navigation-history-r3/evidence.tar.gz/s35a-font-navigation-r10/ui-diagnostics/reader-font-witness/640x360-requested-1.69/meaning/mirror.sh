#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/meaning/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
