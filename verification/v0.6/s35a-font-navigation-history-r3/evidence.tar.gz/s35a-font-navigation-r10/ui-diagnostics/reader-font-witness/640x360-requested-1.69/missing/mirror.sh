#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/screen.png" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/s35a-font-navigation-r10/reader-font-witness/640x360-requested-1.69/missing/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
