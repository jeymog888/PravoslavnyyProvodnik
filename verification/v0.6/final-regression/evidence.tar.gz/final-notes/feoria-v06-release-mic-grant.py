from pathlib import Path
import importlib.util,json,time,sys
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('h','scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
a=h.Adb(Path('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb'),'emulator-5554');r=Path('app/build/verification/v0.6/final-upgrade-new');_,record,m=h.load_run(r,a)
out=r/'supplemental'/('real-grant-'+str(time.time_ns()));out.mkdir(parents=True)
allow=[{'package':'com.google.android.apps.nexuslauncher','title':'Taskbar'}];pkg=m['package'];result={'status':'FAIL','apk_sha256':record['apk']['sha256'],'limits':'Real OS grant and platform capability; no speech/audio injected and no acoustic accuracy claim'}
def save(name,v):
 (out/(name+'.xml')).write_bytes(v.xml);(out/(name+'-windows.txt')).write_text(v.windows)
def tap(v,selector):
 x,y=v.target(selector);a.shell('input','tap',str(x),str(y))
try:
 v=a.view(pkg,allow);save('idle',v);tap(v,{'text':'Послушать до 15 секунд'})
 p=h.wait_for(a,'com.google.android.permissioncontroller',[{'resource-id':'com.android.permissioncontroller:id/permission_allow_foreground_only_button'}],allow+[{'package':pkg,'title':'ru.liturgyguide/ru.liturgyguide.ui.MainActivity'}],timeout=20)
 save('permission',p);(out/'permission.png').write_bytes(a.run('exec-out','screencap','-p'));tap(p,{'resource-id':'com.android.permissioncontroller:id/permission_allow_foreground_only_button'})
 v=h.wait_for(a,pkg,[{'text':'Найти момент по звуку'}],allow,timeout=20);save('after-grant',v)
 result['stop_observed']=bool(v.matching({'text':'Стоп'}))
 if result['stop_observed']:
  tap(v,{'text':'Стоп'});v=h.wait_for(a,pkg,[{'text':'Послушать до 15 секунд'}],allow,timeout=20);save('after-stop',v)
 (out/'package.txt').write_text(a.shell('dumpsys','package',pkg))
 result['visible_text']=[n.get('text') for n in v.nodes if n.get('text')];h.verify_installed(a,pkg,record['apk']['sha256']);result['status']='PASS'
except Exception as e:result['error']=repr(e);raise
finally:(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
