# Независимое review ограниченного release scope

ACCEPT исходников и документов подготовки выпуска. Блокеров в проверенном diff не найдено. Это не финальный release PASS: полный UI, подписанный upgrade и проверка опубликованного SHA остаются PENDING

После db44cc3 git diff содержит ровно три файла: versionCode 5 -> 6, versionName 0.5.0-guide -> 0.6.0-guide; Settings "Феория · 0.6"; User-Agent Feoria/0.6. Application ID ru.liturgyguide, minSdk26/target35, исторические assets и migration contracts не меняются. Версионная правка не меняет чтение, permission или сеть

Прочитаны README, секция 0.6 CHANGELOG, VERIFICATION-0.6 и исторический VERIFICATION.md. README ясно называет APK неподтвержденным до окончания выпуска, объясняет отдельную release подпись и отличие CI debug artifact. Документы не обещают полное последование/календарь, реальную синхронизацию с хором, доступность публичных серверов или проверку физических условий. Перенос через read-only candidate не объявлен уже выполненным финальным signed0.6 upgrade. Локальные ссылки этих трех текущих документов существуют

Основные договоренности согласованы с принятыми review: одна лента этапа, explicit Play/accept, пауза после возврата, сохранение date/mode/speed при CORRECTION, direct Mic с ограниченной попыткой, безопасный ручной путь, screen awake только для активного видимого Text/Wait. Доказательства разных revisions не названы одним общим тестовым прогоном

Неблокирующая редакционная поправка перед окончательной публикацией: последний абзац секции 0.6 CHANGELOG еще включает "приемка микрофона" в PENDING, хотя VERIFICATION-0.6 и s4 report уже принимают ограниченный stage4. Убрать этот устаревший элемент при итоговом заполнении статусов; это не основание менять runtime или повторять stage4

Остаются только уже согласованные release gates: результат текущего final-core, полный финальный UI и имеющиеся host checks, подписанный release с прежним совместимым сертификатом, actual published0.5 -> code6 update без очистки, чистый RELEASE commit и сверка скачанного публичного APK с опубликованным SHA. На момент этого review они не присвоены как выполненные

Физический телефон/свет/TalkBack/акустика/сеть пользователя остаются NOT TESTED. Continuous NO-GO. Косметика больших заголовков отложена после 0.6 по явному приоритету, новых требований или матриц не добавляю

Точные прочитанные SHA:

app/build.gradle.kts: 1f8fdea3ae93afe4c74accf71bb231dd66bb7a1231559fd89f65e44ee3a14957
app/src/main/java/ru/liturgyguide/ui/SettingsScreen.kt: fba2b038dd3537c899131c7242452860d82ff4fb5cd08f0218aedc7f4f77c71e
app/src/main/java/ru/liturgyguide/service/discovery/DiscoveryTransport.kt: 83f868223b9193f595a8974e33b94a745eb9fe2eb5119ef1fa859ce1ad87a665
README.md: 5b359afa4e4ccf2b8498bbca6f193a45ba34515a3a9833074d3f7c96821f2bd8
CHANGELOG.md: 5fbceeda81e061d7dcbcb642d974ed0ddabc2a19803b5bdd41c63719ac4d5a2b
VERIFICATION-0.6.md: 1a4876c863747c5d04041654a574a7964ffa6c820f854925ed390bc9d4af7258

Reviewer не запускал Gradle/adb и не менял репозиторий

## Final-core API33 correction

ACCEPT узкого diff SpeechBackend. RecognitionSupportCallback, RecognitionSupport и три API33 getter теперь находятся в отдельном private @RequiresApi(TIRAMISU) object SpeechSupportApi33. Его единственный вызов следует после прежнего SDK_INT <33 early return. Тот же recognizer, intent, mainExecutor и success/error callbacks передаются без изменений; on-device factory, permission, timeout/token/cleanup не затронуты. Блокеров по статическому review нет

Первый final-core имеет 460 unit PASS, но lint FAIL с 4 NewApi errors по сообщению root; он не является успешным финальным core. Предыдущее lint0 относится к более ранней ревизии и не переносится на финальный backend. Повтор lint/unit еще PENDING, никакого обхода NewApi suppression не добавлено

Прочитанный SpeechBackend SHA: 7673e4f6d94a4020d008611dceae209d139b180addc062ef670067cd33b6309a

## Full UI: предварительная проверка Gospel status oracle

По коду гипотеза подтверждается: ExhaustedServiceEntryTest seed сохраняет lyric_original=true, поиск "Лазарь" выбирает русское чтение Лк 16:19-31; PrayerTrackFactory создает Scripture lines с original=null. ReaderPresentation.kt:25 для такого TEXT с global Original добавляет " · по-русски" к "На паузе". Это честная уже принятая подпись fallback, а не новая ошибка player

Минимальная корректировка после окончания текущего прогона и сверки actual XML: helper assertAccepted(value, stageId, expectedStatus: String = "На паузе"); прежний assertTextEquals(expectedStatus). Только вызов в aSearchAfterMidnightRestoresAndFindsTheChosenDaysScripture передает expectedStatus = "На паузе · по-русски". Остальные calls/default и проверки date/speed/offset/session/paused/bookmarks остаются прежними. Не использовать contains, не вычислять expectation через production helper

Это статический preflight исправления oracle. Actual failure XML/PNG еще не получены, окончательная причина и результат повторного теста здесь не присвоены. Во время Gradle файлы не менялись reviewer

## Final UI exact-oracle correction

ACCEPT test-only diff ExhaustedServiceEntryTest/SavedReadingTest. Actual final-ui XML personally read: 217 tests, failures=2, errors=0, skipped=1. Gospel actual Text and StateDescription are exactly "На паузе · по-русски". Legacy stale reading actual Text and StateDescription are exactly "На паузе · сохраненное чтение · примерное место". Both agree with existing runtime semantics and the previously examined fixtures

Gospel uses one explicit expectedStatus override with the old default for every other helper call. SavedReading changes only two exact strings in the affected method. No action, fixture, date/offset/phrase/bookmark assertion or tolerance is removed. No production correction is needed for these failures

Original full UI remains FAIL with 214 PASS, 2 FAIL, 1 SKIP. If both targeted classes pass, latest distinct coverage becomes 216 PASS + 1 opt-in SKIP; it must not be represented as a single green full run. Targeted result is still pending at this addendum. No failure PNG was exported, and reviewer makes no claim of viewing one. Source/test edits and Gradle/adb were performed only by root
