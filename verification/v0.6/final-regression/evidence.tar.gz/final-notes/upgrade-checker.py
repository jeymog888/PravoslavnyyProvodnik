from pathlib import Path
import importlib.util,json,hashlib,subprocess,sys,time,re,os,xml.etree.ElementTree as E
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
tool=Path('/private/tmp/liturgy-android-toolchain')
os.environ['JAVA_HOME']=str(tool/'jdk-17.0.21+9/Contents/Home')
sys.dont_write_bytecode=True
s=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py');h=importlib.util.module_from_spec(s);s.loader.exec_module(h)
a=h.Adb(tool/'sdk/platform-tools/adb','emulator-5554')
phase=sys.argv[1];assert phase in ['before','installed','preview','accepted','cold']
base=repo/'app/build/verification/v0.6/final-release-upgrade-checkpoints';base.mkdir(exist_ok=True)
out=base/phase;assert not out.exists();out.mkdir()
oldsha='de1634752bf2c9512e022be6dc04d07d60d7058c8632dbacdf492c860aaa1e71'
cert='bb0ea3162b2129b7411ed3a15956c6f2065c685574c1caa24fb260e452ef5247'
buildpath=repo/'app/build/verification/v0.6/final-release-candidate/build.json'
b=json.loads(buildpath.read_text());h.validate_build(b,buildpath.with_name('build.log'),Path(b['apk']['path']))
record={'status':'FAIL','phase':phase,'started_ns':time.time_ns(),'script_sha256':h.sha(__file__),'build_sha256':h.sha(buildpath),'new_apk':b['apk'],'limits':'Published signed 0.5 release to signed 0.6 release, code 5 to 6, state prepared through old native UI. su 0 is used only for reading this own emulator app preferences; UI and install stay under normal adb shell.'}
def raw(name,args,expected=0):
 p=subprocess.run([a.executable,'-s',a.serial,*args],capture_output=True,timeout=30)
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==expected,(name,p.returncode,p.stderr.decode())
 return p.stdout
try:
 assert a.shell('getprop','ro.kernel.qemu')=='1' and a.shell('getprop','ro.build.version.sdk')=='35'
 assert a.shell('am','get-current-user')=='0' and a.shell('id','-u')=='2000'
 installed=h.verify_installed(a,'ru.liturgyguide',oldsha if phase=='before' else b['apk']['sha256'])
 assert b['apk']['certificate_sha256']==cert and b['apk']['version_code']=='6' and b['apk']['version_name']=='0.6.0-guide' and b['apk']['debuggable'] is False
 prefs=raw('preferences',['exec-out','su','0','cat','/data/user/0/ru.liturgyguide/shared_prefs/guide_preferences.xml'])
 (out/'preferences.xml').write_bytes(prefs)
 package=raw('package',['shell','dumpsys','package','ru.liturgyguide']).decode()
 ident={}
 for key,pattern in [('id',r'^\s*(?:appId|userId)=(\d+)\b'),('first',r'^\s*firstInstallTime=([^\n]+)'),('code',r'^\s*versionCode=(\d+)\b'),('version',r'^\s*versionName=([^\n]+)')]:
  values=list(set(re.findall(pattern,package,re.M)));assert len(values)==1,(key,values);ident[key]=values[0].strip()
 assert ident['code']==('5' if phase=='before' else '6') and ident['version']==('0.5.0-guide' if phase=='before' else '0.6.0-guide')
 nodes=list(E.fromstring(prefs));values={n.get('name'):(n.text if n.tag=='string' else n.get('value')) for n in nodes};assert len(nodes)==len(values)
 stored=json.loads(values['service_playback_v1']);context=json.loads(stored['context'])
 assert json.loads(values['reading_context_v1'])==context
 oldtables=json.loads((repo/'app/src/test/resources/published_0_5/published-plans.json').read_text())
 old=next(p for p in oldtables if p['serviceDate']==context['serviceDate'])
 if phase=='before':
  raw('pid',['shell','pidof','ru.liturgyguide'],1)
  assert stored['planFingerprint']==old['fingerprint'] and stored['speed']=='SLOW'
  segment=old['segments'][stored['segmentIndex']]
  assert segment['type']=='Wait' and segment['stageId']=='great_litany' and stored['elapsedQuarterMillis']>0
  prior=next(p for p in reversed(old['segments'][:stored['segmentIndex']]) if p['type']=='Text' and p['stageId']=='great_litany')
  assert values['church_id']=='vsetsaritsa_nakhabino' and context['parishId']==values['church_id']
  assert values['dark']=='true' and values['text_size']=='1' and values['lyric_original']=='true'
  record['old_retained_text']=prior
 else:
  before=json.loads((base/'before/result.json').read_text());assert before['status']=='PASS'
  assert before['script_sha256']==record['script_sha256'] and before['build_sha256']==record['build_sha256']
  assert ident['id']==before['package']['id'] and ident['first']==before['package']['first']
  beforeprefs=(base/'before/preferences.xml').read_bytes()
  beforevalues=before['preferences'];assert context==before['context']
  if phase in ['installed','preview']:
   assert prefs==beforeprefs,'Preference bytes changed before explicit acceptance'
   if phase=='installed':raw('pid',['shell','pidof','ru.liturgyguide'],1)
   else:assert raw('pid',['shell','pidof','ru.liturgyguide']).strip()
  else:
   tables=json.loads((repo/'app/build/verification/v0.6/s32-current-plans/published-plans.json').read_text())
   current=next(p for p in tables if p['serviceDate']==context['serviceDate'])
   expected=next(p for p in current['segments'] if p.get('lineId')==before['old_retained_text']['lineId'] and p.get('trackId')==before['old_retained_text']['trackId'])
   assert stored['planFingerprint']==current['fingerprint'] and stored['segmentIndex']==expected['index']
   assert stored['speed']==before['stored']['speed']=='SLOW' and stored['elapsedQuarterMillis']==0
   for key in ['church_id','dark','text_size','lyric_original']:
    assert values[key]==beforevalues[key]
   if phase=='cold':assert prefs==(base/'accepted/preferences.xml').read_bytes()
   record['accepted_segment']=expected
 record.update(status='PASS',installed_sha256=installed,package=ident,preferences_sha256=h.digest(prefs),preferences=values,context=context,stored=stored)
except Exception as e:
 record['error']=repr(e);raise
finally:
 record['finished_ns']=time.time_ns();(out/'result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
 print(json.dumps({k:record.get(k) for k in ['status','phase','installed_sha256','preferences_sha256','error']},ensure_ascii=False))
