#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/screen.png" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/640x360-requested-1.69/end/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
