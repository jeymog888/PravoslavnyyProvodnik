#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/screen.png" && test -s "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/bounds.json" &&
    mkdir -p "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/screen.png" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/screen.png" &&
    cmp "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/bounds.json" "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/bounds.json" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/.complete" && test -s "/data/local/tmp/feoria-ci-diagnostics/v06-final-ui/reader-font-witness/400x800-requested-2.6/meaning/.complete"
)
result=$?
printf 'MIRROR_EXIT=%s\n' "$result"
exit "$result"
