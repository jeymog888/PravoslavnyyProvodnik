#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic/first-failure-1794178417952" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s24-diagnostic/first-failure-1794178417952" "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic/first-failure-1794178417952" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic/first-failure-1794178417952/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic/first-failure-1794178417952.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s24-diagnostic/first-failure-1794178417952.export.txt"
exit "$result"
