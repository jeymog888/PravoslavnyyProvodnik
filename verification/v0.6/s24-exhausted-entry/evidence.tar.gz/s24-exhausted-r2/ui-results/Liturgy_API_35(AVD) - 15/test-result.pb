
�	
�
ExhaustedServiceEntryTestru.liturgyguide.uiJlostOrCorruptDraftsReturnSafelyFromManualArrivalAndBothScopedSearchOrigins2��������:������Æ"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ExhaustedServiceEntryTest-lostOrCorruptDraftsReturnSafelyFromManualArrivalAndBothScopedSearchOrigins.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�	
�
MainScheduleOverviewTestru.liturgyguide.ui>exhaustedEstimateKeepsBothOccurrencesAndHasOneScopedFindAction2������:������þ"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.MainScheduleOverviewTest-exhaustedEstimateKeepsBothOccurrencesAndHasOneScopedFindAction.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
~
ManualMomentFlowTestru.liturgyguide.ui7choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation2��������:�������L�
�
java.lang.AssertionError: Failed: performScrollToNode(TestTag = 'manual_little_entrance')
Reason: Expected exactly '1' node but could not find any node that satisfies: (TestTag = 'manual_content')

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:178)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.ActionsKt.scrollToMatchingDescendantOrReturnScrollable(Actions.kt:285)
at androidx.compose.ui.test.ActionsKt.performScrollToNode(Actions.kt:243)
at ru.liturgyguide.ui.ManualMomentFlowTest.landmark(ManualMomentFlowTest.kt:344)
at ru.liturgyguide.ui.ManualMomentFlowTest.choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation$lambda$6(ManualMomentFlowTest.kt:118)
at ru.liturgyguide.ui.ManualMomentFlowTest.$r8$lambda$QJ6CtIL_YYy9OKAA2akCqjEKeiI(Unknown Source:0)
at ru.liturgyguide.ui.ManualMomentFlowTest$$ExternalSyntheticLambda5.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.ManualMomentFlowTest.choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation(ManualMomentFlowTest.kt:97)
java.lang.AssertionError�
java.lang.AssertionError: Failed: performScrollToNode(TestTag = 'manual_little_entrance')
Reason: Expected exactly '1' node but could not find any node that satisfies: (TestTag = 'manual_content')

at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow(SemanticsNodeInteraction.kt:178)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchOneOrThrow$default(SemanticsNodeInteraction.kt:150)
at androidx.compose.ui.test.SemanticsNodeInteraction.fetchSemanticsNode(SemanticsNodeInteraction.kt:84)
at androidx.compose.ui.test.ActionsKt.scrollToMatchingDescendantOrReturnScrollable(Actions.kt:285)
at androidx.compose.ui.test.ActionsKt.performScrollToNode(Actions.kt:243)
at ru.liturgyguide.ui.ManualMomentFlowTest.landmark(ManualMomentFlowTest.kt:344)
at ru.liturgyguide.ui.ManualMomentFlowTest.choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation$lambda$6(ManualMomentFlowTest.kt:118)
at ru.liturgyguide.ui.ManualMomentFlowTest.$r8$lambda$QJ6CtIL_YYy9OKAA2akCqjEKeiI(Unknown Source:0)
at ru.liturgyguide.ui.ManualMomentFlowTest$$ExternalSyntheticLambda5.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.ManualMomentFlowTest.choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation(ManualMomentFlowTest.kt:97)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ManualMomentFlowTest-choosingAnotherLandmarkShowsItsNewCueBeforeConfirmation.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain