ACCEPT ограниченного свидетельства Text/Pause, не всего native run

Сборка s36-awake-r1: build.json PASS/exit 0, inputs_before == inputs_after, SHA build.log совпал. Независимый подсчет XML: 440 unit и 9 UI, failures/errors/skipped = 0. APK 39cdad85d5d4f71a0fe1df6ca3c7d2f06df245951a9b3fd85923f8eb2b829ac6

R2: сохраненный root-driver.py вызывает time.sleep(21) перед каждым power dump. После успешного Play text-active-power.txt содержит mWakefulness=Awake; после успешной Паузы text-paused-power.txt содержит mWakefulness=Asleep. Оба dump подтверждают mStayOn=false, mScreenOffTimeoutSetting=15000, mStayOnWhilePluggedInSetting=0. Нужные action receipts PASS. Это реальный timeout на эмуляторе с явно подготовленным Text fixture, не физический телефон

Readback до проверки: stay_on_while_plugged_in=0, armed-timeout-text=15000. После остановки независимо прочитаны restored-stay_on_while_plugged_in=3 и restored-screen_off_timeout=2147483647, равные original-settings.json. observation-4 cleanup PASS, errors=[]

R2 в целом FAIL: observation-3 фиксирует unexpected visible overlay com.google.android.apps.nexuslauncher/Taskbar уже после обоих power observations. Wait/Home/Recents/lock этим run не доказаны. Ошибка драйвера не превращает run в PASS и не является доказательством дефекта приложения. R1 подготовительная ошибка остается отдельной сохраненной неудачей

Проверка только сохраненных файлов, без adb/Gradle/изменений исходников. Новые R3 результаты и PNG здесь еще не оценены
