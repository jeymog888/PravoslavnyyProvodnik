# 3.6 production draft review

ACCEPT production draft для перехода к чтению готовых тестов. Это не приемка полного этапа или runtime PASS

Прочитаны ReaderScreenAwake.kt, весь MainActivity delta и существующий ActivityForegroundState. Второго конкурирующего bind нет: прежние lifecycle и foreground pause paths перенесены в одну rememberReaderScreenAwakeBinding. MainActivity владеет одним window owner, отдельно от adaptive reader/sheet

Predicate соответствует контракту: visible SERVICE, актуальный RESUMED, top-resumed при наличии API29 owner, принятый playing и segment Text/Wait. BeforeStart Wait не исключен искусственно; paused BeforeStart не удерживается. Tempo остается частью SERVICE и не получает новую паузу при открытии

Binding.pause сначала синхронно снимает flag и затем вызывает прежний player.pause. Lifecycle loss, top loss, явная navigate и dispose используют этот путь; отказ writer не препятствует уже выполненному снятию флага при потере foreground. SideEffect повторно проверяет живые lifecycle/top/player перед включением, поэтому старый requested=true не перекрывает уже наступившую потерю foreground

Identity защищена: update/pause старого binding игнорируются, close старого binding не снимает flag и не паузит replacement. Новый attach начинает с выключенного flag; close текущего снимает flag до pause. Старый foreground unbind также identity-guarded существующим ActivityForegroundState. Disposal не зависит от layout kind или открытия controls

Используется только FLAG_KEEP_SCREEN_ON текущего Activity Window, без wake lock/service/settings. Test host без owner получает no-op window writer, сохраняя прежнее lifecycle pause поведение. Реальные flag проверки должны явно предоставить owner/window либо production MainActivity

Статических blockers в production draft не нашел. Далее достаточно уже согласованных unit/UI: predicate/BeforeWait, owner replacement, actual flag и synchronous release-before-pause, затем native timeout без emulator stayawake. Новых требований/матриц не предлагаю

Прочитанная версия: MainActivity.kt SHA 37a35a5ab1422e6d9e04fff3c1b26dc58f658660c3e08c5ba93ff4f7f603716e; ReaderScreenAwake.kt SHA 0179895fba122f3f548d08cedcc4c6a7b82e72b11b1c3e0caff553df3e6e3739. Source не редактировал, Gradle/adb не запускал

## Final owner delta and five unit tests

ACCEPT прочитанной финальной owner initialization: enabled: Boolean? = null гарантирует первый clear даже при унаследованном Window flag, затем прежняя дедупликация сохраняется. ReaderScreenAwake.kt SHA 0179895fba122f3f548d08cedcc4c6a7b82e72b11b1c3e0caff553df3e6e3739

ReaderScreenAwakeTest.kt прочитан целиком, SHA 54ab5db8a148b973c8efc5b4f81763283f8795843442ba1421e752c724215396. Пять тестов содержательны: все комбинации foreground predicate/paused/null, активный BeforeStart Wait и restored paused/барьеры, очистка inherited flag и дедупликация, строгий порядок release-before-pause и запрет closed reacquire, stale update/pause/close после нового owner. Tests используют реальные engine/plan для accepted state, не подменяют predicate отдельным fake playing boolean

Новых статических blockers не найдено. Unit пока NOT_RUN, actualWindow UI еще ожидает чтения

## Six actual-window UI tests, early read

Прочитан целиком ReaderScreenAwakeFlowTest.kt. Новых blockers сверх уже переданных root замен "Примерный темп" -> "Темп текста" и возврата из SERVICE Settings через Back не найдено. Окончательный SHA ожидается после этих двух fixes

Тесты используют настоящее Activity Window, проверяют flag до writer в синхронных top-loss/lifecycle callbacks, фиксируют writes вместо assertions внутри writer (который ловит исключения), сохраняют offset/context/bookmarks и темп. Top loss/gain проверяются в одном callback до Compose frame, lifecycle через ActivityScenario. Реальные failure writer/отказ Play, BeforeStart Wait, Missing/End, stale owner update/pause/close и disposal проверяются независимо. Первый тест включает production AppNavigation и tempo/Meaning/Settings

Покрытие соответствует принятой карте без новых требований. Выполнение еще NOT_RUN; финальная приемка исходников после freeze/hash

## Final four-file freeze

ACCEPT точного freeze aggregate df57cdc672186d65bafc55c0986f9befff7661bc1f076d7a1e7caa031c4f15b4. Все четыре файла сверены по SHA/bytes. ReaderScreenAwakeFlowTest SHA 2d4333f7a768aeff136eebafcd58d9b51906287a3fc7b953e4adc8b8db4bacfc; лично подтверждены "Темп текста" и возврат из Settings по "Назад" напрямую в reader. Прежние проверки состояния/окна сохранены. Это final source review, не результат уже запущенной root сборки или native timeout
