# 3.6: удержание экрана

Реализован только FLAG_KEEP_SCREEN_ON главного Activity window во время видимого принятого Text/Wait playback. BeforeStart на Wait включен в общий предикат. Tempo и controls сохраняют текущий playback, Meaning/обычная пауза/уход выключают удержание

Production: ReaderScreenAwakeOwner с identity-guarded Binding, один lifecycle/top-resumed binding вместо прежних двух эффектов. Потеря foreground/lifecycle и disposal снимают флаг до player.pause/writer. Центральный navigate также снимает флаг перед своей паузой. Late update/pause/close старого binding не влияют на replacement. Повторные elapsed ticks не записывают одинаковое значение Window flag. Первое attach явно устанавливает false

MainActivity создает Activity-owned adapter для настоящего Window; AppNavigation получает его последним optional параметром. Изолированные прежние UI harness без adapter сохраняют прежнюю lifecycle-паузу, новые actual-window проверки явно подключают production adapter. ServiceScreen, player, engine, store, assets, шрифты и временная формула не изменены

Self-review: в первом draft enabled=false ошибочно предполагал, что фактический Window уже очищен. Исправлено на nullable initial state: первый attach обязательно пишет false даже при ранее установленном флаге. Проверены ownership replacement/stale disposal, release-before-writer, живой foreground predicate и отсутствие нового autoplay. Root и независимый reviewer приняли production draft в /private/tmp/feoria-v06-awake-production-draft-review.md

Сборка и тесты исполнителем не запускались. Native timeout proof не заявлен; его отдельно выполняет root с временно отключенным stay-on и восстановлением настроек. Полный regression suite остается на release QA

Focused QA: новый ReaderScreenAwakeTest - 5 unit методов; ReaderScreenAwakeFlowTest - 6 UI методов. Actual Window проверяется на AppNavigation Play/Pause/tempo/Meaning/Settings, top loss+gain до следующего кадра, lifecycle, preparation/обычный Wait, Missing/End, rejected Play/failed mandatory pause, replacement/stale cleanup/disposal. Реальная Activity recreation не заявлена. Существующие regression tests не редактировались

Root prebuild review исправил две реальные ошибки новых UI selectors: актуальный заголовок tempo "Темп текста" и возврат из Settings через "Назад" непосредственно к reader. Все state/offset/bookmark/flag assertions сохранены

SOURCE FREEZE: все 4 затронутых файла. Дополнительные target UI: UnifiedPlayerFlowTest.losingResumedStatePausesAndDoesNotConsumeTimeBeforeReturning; losingTopResumedPausesSynchronouslyEvenWhenLifecycleStaysResumed; changingSpeedCapturesTheOldMultiplierWithoutMovingToAnotherPhrase. Полный unit и запуск UI выполняет только root
