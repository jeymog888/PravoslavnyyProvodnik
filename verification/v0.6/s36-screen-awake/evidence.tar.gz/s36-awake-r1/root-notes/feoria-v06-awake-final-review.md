ACCEPT этапа 3.6 в проверенном объеме

Производственный код и финальный freeze четырех файлов приняты ранее. s36-awake-r1: 440 unit + 9 UI PASS без skipped/failures/errors; inputs_before == inputs_after. APK 39cdad85d5d4f71a0fe1df6ca3c7d2f06df245951a9b3fd85923f8eb2b829ac6

Независимо просмотрены оба новых PNG R3. recents.png действительно показывает системный обзор приложений и карточку Феории с остановленным переходом. cases/paused-return/screen.png показывает Wait после возврата из блокировки: "Примерный переход остановлен", видимое "Продолжить по времени", доступные "Уточнить" и "Управление". Фиксированные действия не обрезаны. Частичная предыдущая строка сверху относится к краю прокрученной ленты

Сверены SHA/bytes всех case artifacts и SHA manifest. Run aebb4306e0c748bab10c23dcedaa679d, APK совпадает со сборкой. R3 наблюдения: Wait Awake после 21 секунды, Home Asleep после 21 секунды; dumpsys подтверждает timeout=15000, stay-on setting=0, mStayOn=false. После Recents и ручной блокировки проверяется paused action, без автоматического возобновления. return-from-recents.txt подтверждает доставку intent существующему top-most instance, не новый cold launch

Text Awake и Pause Asleep после 21 секунды доказаны отдельно сохраненными наблюдениями R2 на том же APK. R2 целиком остается FAIL из-за root driver Taskbar allowlist; R1 подготовительная ошибка также не переименована в PASS. R3 выполнял только оставшиеся сценарии и завершился PASS_PENDING_VISUAL_REVIEW; настоящим отчетом визуальное условие принято, без подмены машинного gate

R3 cleanup PASS/errors=[], оба readback восстановили исходные stay_on_while_plugged_in=3 и screen_off_timeout=2147483647. Это эмулятор API 35 и явно подготовленные Text/Wait fixtures, не физическое устройство, акустика или естественное прибытие на службу

Блокеров для закрытия 3.6 не найдено. Новые проверки, изменения исходников, adb и Gradle со стороны reviewer не выполнялись
