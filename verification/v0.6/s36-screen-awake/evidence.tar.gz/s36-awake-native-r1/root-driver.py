# coding: utf-8
"""Root-only timeout observation on the own emulator; no acoustic/upgrade claims."""
from pathlib import Path
import importlib.util, json, subprocess, sys, time, re
sys.dont_write_bytecode = True
repo = Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
spec = importlib.util.spec_from_file_location('h', repo/'scripts/harness/feoria_harness.py')
h = importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
a = h.Adb(Path('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb'), 'emulator-5554')
run = repo/'app/build/verification/v0.6'/sys.argv[1]
build = repo/'app/build/verification/v0.6'/sys.argv[2]/'build.json'
manifest = run.parent/(run.name+'-manifest.json')
manifest.write_text(json.dumps({'schema':1, 'package':'ru.liturgyguide', 'build_type':'debug',
    'conditions':{'data_source':'Explicit own paused text and wait fixtures; actual device monotonic time',
                  'network_source':'No network assertion', 'clock_source':'Real elapsed time, saved service date fixture'},
    'cases':[{'id':'paused-return','mode':'static', 'human_review_required':True,
       'observed_requirements':{'sdk':'35','font_scale':'1.0','timezone':'Europe/Moscow'},
       'allowed_windows':[{'package':'com.google.android.apps.nexuslauncher','title':'Taskbar'}],
       'conditions':{'scenario':'Returned after explicit manual lock, remains paused'},
       'expected':[{'content-desc':'Продолжить по времени'}]}]},ensure_ascii=False,indent=2))
h.begin_run(manifest, build, run, a)
events=[]
def command(label, *args):
    result=a.run(*args, timeout=30)
    (run/(label+'.txt')).write_bytes(result)
    return result.decode(errors='replace').strip()
def record(label, **values):
    events.append(dict(label=label, monotonic=time.monotonic(), **values))
    h.write_json(run/'observations.json',events)
    print(label,values,flush=True)
def power(label, wanted):
    value=command(label+'-power','shell','dumpsys','power')
    matches=re.findall(r'^\s*mWakefulness=(\w+)\s*$',value,re.M)
    assert matches==[wanted], (label,matches)
    command(label+'-windows','shell','dumpsys','window','windows')
    record(label,wakefulness=wanted)
def tap(label, expected):
    h.tap(run,a,'paused-return',{'content-desc':label},[{'content-desc':expected}],timeout=20)
def wait_timeout(label,wanted):
    print('Waiting for actual timeout: '+label,flush=True)
    time.sleep(21)
    power(label,wanted)
def wake(label):
    command(label+'-wake','shell','input','keyevent','224')
    command(label+'-unlock','shell','wm','dismiss-keyguard')
    h.wait_for(a,'ru.liturgyguide',[{'content-desc':'Продолжить по времени'}],timeout=20)
def fixture(kind):
    command('arrange-timeout-'+kind,'shell','settings','put','system','screen_off_timeout','2147483647')
    p=subprocess.run(['python3','/private/tmp/feoria-v06-reader-fixture.py',str(run),kind,'light','0'],capture_output=True,text=True)
    (run/('fixture-'+kind+'.log')).write_text(p.stdout+p.stderr);p.check_returncode()
    allowed=[{'package':'com.google.android.apps.nexuslauncher','title':'Taskbar'}]
    for attempt in range(3):
        view=a.view('ru.liturgyguide',allowed)
        (run/(kind+'-home-'+str(attempt)+'.xml')).write_bytes(view.xml)
        if any(n.get('text')=='Сохраненное чтение' for n in view.nodes):
            break
        panes=[h.bounds(n,view.size) for n in view.nodes if n.get('scrollable')=='true']
        assert len(panes)==1
        x1,y1,x2,y2=panes[0]
        a.shell('input','swipe',str((x1+x2)//2),str(y1+(y2-y1)*3//4),str((x1+x2)//2),str(y1+(y2-y1)//4),'350')
    h.tap(run,a,'paused-return',{'text':'Сохраненное чтение'},
        [{'content-desc':'Двигать текст' if kind=='text' else 'Продолжить по времени'}],timeout=20)
    command('arm-timeout-'+kind,'shell','settings','put','system','screen_off_timeout','15000')
    assert command('armed-timeout-'+kind,'shell','settings','get','system','screen_off_timeout')=='15000'
settings=[('global','stay_on_while_plugged_in'),('system','screen_off_timeout')]
original={key:command('before-'+key,'shell','settings','get',namespace,key) for namespace,key in settings}
h.write_json(run/'original-settings.json',original)
try:
    for namespace,key in settings:
        value='0' if key=='stay_on_while_plugged_in' else '15000'
        command('set-'+key,'shell','settings','put',namespace,key,value)
        assert command('effective-'+key,'shell','settings','get',namespace,key)==value
    fixture('text')
    tap('Двигать текст','Пауза')
    wait_timeout('text-active','Awake')
    tap('Пауза','Двигать текст')
    wait_timeout('text-paused','Asleep')
    command('text-wake','shell','input','keyevent','224')
    command('text-unlock','shell','wm','dismiss-keyguard')
    h.wait_for(a,'ru.liturgyguide',[{'content-desc':'Двигать текст'}],timeout=20)
    fixture('wait')
    tap('Продолжить по времени','Пауза')
    wait_timeout('wait-active','Awake')
    command('home','shell','input','keyevent','3')
    wait_timeout('background','Asleep')
    command('background-wake','shell','input','keyevent','224')
    command('background-unlock','shell','wm','dismiss-keyguard')
    command('return-from-home','shell','am','start','-W','-n','ru.liturgyguide/.ui.MainActivity')
    h.wait_for(a,'ru.liturgyguide',[{'content-desc':'Продолжить по времени'}],timeout=20)
    tap('Продолжить по времени','Пауза')
    command('recents','shell','input','keyevent','187')
    time.sleep(1)
    command('recents-windows','shell','dumpsys','window','windows')
    (run/'recents.png').write_bytes(a.run('exec-out','screencap','-p'))
    command('return-from-recents','shell','am','start','-W','-n','ru.liturgyguide/.ui.MainActivity')
    h.wait_for(a,'ru.liturgyguide',[{'content-desc':'Продолжить по времени'}],timeout=20)
    record('recents-return-paused')
    tap('Продолжить по времени','Пауза')
    command('manual-lock','shell','input','keyevent','223')
    time.sleep(1)
    power('manual-lock','Asleep')
    wake('manual-lock')
    record('manual-lock-return-paused')
    h.capture_case(run,a,'paused-return',timeout=20)
    record('result',status='PASS_PENDING_VISUAL_REVIEW')
except Exception as error:
    record('result',status='FAIL',error=repr(error))
    raise
finally:
    restore_errors=[]
    for namespace,key in settings:
        try:
            value=original[key]
            args=('delete',namespace,key) if value=='null' else ('put',namespace,key,value)
            command('restore-'+key,'shell','settings',*args)
            assert command('restored-'+key,'shell','settings','get',namespace,key)==value
        except Exception as error:
            restore_errors.append({'setting':key,'error':repr(error)})
    try:
        command('final-wake','shell','input','keyevent','224')
        command('final-unlock','shell','wm','dismiss-keyguard')
        h.verify_installed(a,'ru.liturgyguide',json.loads((run/'run.json').read_text())['apk']['sha256'])
    except Exception as error:
        restore_errors.append({'setting':'final-wake-and-identity','error':repr(error)})
    record('cleanup',status='FAIL' if restore_errors else 'PASS',errors=restore_errors)
    if restore_errors and sys.exc_info()[0] is None:
        raise RuntimeError('Cleanup failed: '+repr(restore_errors))
