# R20 essential tempo correction

ACCEPT для двух предложенных целевых UI и одного native case. NOT_RUN этим reviewer

Все 20 SHA/bytes совпали с freeze aggregate e175542e25bd1bce28c1d549151656730b5108e3663b741b47ab72f69e5c21f8. Сравнение с R19 source-freeze подтвердило ровно два измененных файла: ServiceScreen tempo section и новый ReaderAccessibility focused test

Runtime delta ограничен принятым решением: title "Темп текста", варианты скорости до пояснений, краткое объяснение, visible "Пауза" с полным contentDescription "Поставить на паузу". Старое дополнительное объяснение поведения после фрагмента сохранено ниже. pause(generation), changeSpeed, закрытие/Done и native density не изменены; добавлен только tempo_done tag

Тест проверяет полные fixed action bounds и glyph, >=48dp height, точные native2.6 raw bits, visible/accessible Pause labels, достижимость всех трех speed rows реальной прокруткой, selected Fast и сохраненную паузу после Done. Существующий active pause test дополняет это реальным остановленным playback через прежний manual_reading tag. Очевидных compile/selector blockers не найдено

Новый native кадр обязателен для подтверждения исправления фактически наблюденного clipping. Расширенная матрица не требуется. Ни runtime font cap, ни tolerance weakening, ни новые функции не внесены. Прежний large-tempo REJECT сохраняется

Reviewer source не менял, Gradle/adb не запускал
