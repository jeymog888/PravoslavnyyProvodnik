
�

GuideNavigationTestru.liturgyguide.ui8choosingManualReadingFromTempoOptionsStopsAnActiveScroll2��������:�����ۍ�"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.GuideNavigationTest-choosingManualReadingFromTempoOptionsStopsAnActiveScroll.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderAccessibilityTestru.liturgyguide.ui9tempoOptionsAndFixedActionsStayReachableWithVeryLargeText2��������:��������"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderAccessibilityTest-tempoOptionsAndFixedActionsStayReachableWithVeryLargeText.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain