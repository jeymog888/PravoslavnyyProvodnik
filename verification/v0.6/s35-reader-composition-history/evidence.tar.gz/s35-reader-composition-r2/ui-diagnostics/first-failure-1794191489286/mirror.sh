#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286" "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r2/first-failure-1794191489286.export.txt"
exit "$result"
