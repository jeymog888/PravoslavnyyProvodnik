
�
|
ReaderFeedFlowTestru.liturgyguide.ui6browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning2�����Ӹ�:��������
�java.lang.AssertionError: Assert failed: The component is not displayed!
at androidx.compose.ui.test.AssertionsKt.assertIsDisplayed(Assertions.kt:34)
at ru.liturgyguide.ui.ReaderFeedFlowTest.browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning$lambda$2(ReaderFeedFlowTest.kt:47)
at ru.liturgyguide.ui.ReaderFeedFlowTest.$r8$lambda$HwyMr2TWLA_MVYbJlgYjviF4sKY(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFeedFlowTest$$ExternalSyntheticLambda8.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFeedFlowTest.browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning(ReaderFeedFlowTest.kt:35)
java.lang.AssertionError�java.lang.AssertionError: Assert failed: The component is not displayed!
at androidx.compose.ui.test.AssertionsKt.assertIsDisplayed(Assertions.kt:34)
at ru.liturgyguide.ui.ReaderFeedFlowTest.browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning$lambda$2(ReaderFeedFlowTest.kt:47)
at ru.liturgyguide.ui.ReaderFeedFlowTest.$r8$lambda$HwyMr2TWLA_MVYbJlgYjviF4sKY(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFeedFlowTest$$ExternalSyntheticLambda8.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFeedFlowTest.browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning(ReaderFeedFlowTest.kt:35)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderFeedFlowTest-browsingAnotherHeaderDoesNotAcceptItOrChangeTheMeaning.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderFeedFlowTestru.liturgyguide.ui=aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus2��������:���������
�java.lang.AssertionError: expected:<DpRect(left=52.95238.dp, top=229.33333.dp, right=280.0.dp, bottom=301.33334.dp)> but was:<DpRect(left=52.95238.dp, top=241.14285.dp, right=280.0.dp, bottom=313.14285.dp)>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:120)
at org.junit.Assert.assertEquals(Assert.java:146)
at ru.liturgyguide.ui.ReaderFeedFlowTest.aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus$lambda$20(ReaderFeedFlowTest.kt:189)
at ru.liturgyguide.ui.ReaderFeedFlowTest.$r8$lambda$JX0rCWD2VzFSod9rNsW66xQpELI(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFeedFlowTest$$ExternalSyntheticLambda20.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFeedFlowTest.aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus(ReaderFeedFlowTest.kt:171)
java.lang.AssertionError�java.lang.AssertionError: expected:<DpRect(left=52.95238.dp, top=229.33333.dp, right=280.0.dp, bottom=301.33334.dp)> but was:<DpRect(left=52.95238.dp, top=241.14285.dp, right=280.0.dp, bottom=313.14285.dp)>
at org.junit.Assert.fail(Assert.java:89)
at org.junit.Assert.failNotEquals(Assert.java:835)
at org.junit.Assert.assertEquals(Assert.java:120)
at org.junit.Assert.assertEquals(Assert.java:146)
at ru.liturgyguide.ui.ReaderFeedFlowTest.aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus$lambda$20(ReaderFeedFlowTest.kt:189)
at ru.liturgyguide.ui.ReaderFeedFlowTest.$r8$lambda$JX0rCWD2VzFSod9rNsW66xQpELI(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFeedFlowTest$$ExternalSyntheticLambda20.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFeedFlowTest.aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus(ReaderFeedFlowTest.kt:171)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderFeedFlowTest-aRejectedLineChoiceCannotTurnBoundaryPauseIntoSuccessfulFocus.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain