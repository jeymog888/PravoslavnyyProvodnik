#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156" "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35-reader-composition-r3-diagnostic/first-failure-1794192050156.export.txt"
exit "$result"
