# coding: utf-8
from pathlib import Path
import importlib.util,json,sys,time
sys.dont_write_bytecode=True
repo=Path('/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik')
spec=importlib.util.spec_from_file_location('h',repo/'scripts/harness/feoria_harness.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
a=h.Adb(Path('/private/tmp/liturgy-android-toolchain/sdk/platform-tools/adb'),'emulator-5554')
run=Path(sys.argv[1]);origin,target=sys.argv[2:4];selector=json.loads(sys.argv[4])
_,receipt,manifest=h.load_run(run,a)
first=h.case_by_id(manifest,origin);last=h.case_by_id(manifest,target)
out=run/'supplemental'/('window-transition-'+str(time.time_ns()));out.mkdir(parents=True)
result={'status':'FAIL','origin':origin,'target':target,'selector':selector,'apk_sha256':receipt['apk']['sha256']}
try:
 before=a.view(first.get('window_package',manifest['package']),first.get('allowed_windows',[]))
 (out/'before.xml').write_bytes(before.xml);(out/'before-windows.txt').write_text(before.windows)
 x,y=before.target(selector);result['coordinates']=[x,y]
 a.shell('input','tap',str(x),str(y))
 after=h.wait_for(a,last.get('window_package',manifest['package']),last['expected'],last.get('allowed_windows',[]),timeout=20)
 (out/'after.xml').write_bytes(after.xml);(out/'after-windows.txt').write_text(after.windows)
 h.verify_installed(a,manifest['package'],receipt['apk']['sha256'])
 result['status']='PASS'
except Exception as error:
 result['error']=repr(error);raise
finally:
 h.write_json(out/'result.json',result)
 print(json.dumps(result,ensure_ascii=False))
