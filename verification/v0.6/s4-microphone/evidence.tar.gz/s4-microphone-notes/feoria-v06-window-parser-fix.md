# Граница inventory в dumpsys window

Исправлены только scripts/harness/feoria_harness.py и scripts/harness/tests/test_harness.py. В реальном dump после последнего Window #11 идет sibling section "  Hiding System Alert Windows:", где повторяется подробное описание permission window. Старый split по Window # ошибочно присоединял его owner/visibility к последнему inventory entry

Минимальная правка: текущий block обрезается на точной top-level строке этого раздела, с сохранением прежнего обхода всех Window #. Owner, identity, visibility, foreground и overlays проверки не изменены. Не используется первый найденный owner вместо строгого требования единственной строки

Добавлены две регрессии на сокращенных строках реального dump: permission summary после скрытого wallpaper успешно разбирается; настоящий второй owner внутри wallpaper перед summary по-прежнему отклоняется. Тест сохраняет видимость и identity permission/app окон, скрытый wallpaper не попадает в visible inventory

Саморевью: граница привязана к началу строки и ровно двум пробелам; содержимое window title не используется как разрешение overlay. Все Window # по-прежнему проходят цикл, обрезание текущего block не скрывает последующие inventory headers. Дубликаты внутри block остаются ошибкой

Host команда: PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s scripts/harness/tests -v
Результат: 63 tests, OK. Лог: /private/tmp/feoria-v06-window-parser-tests.log. git diff --check PASS. Gradle/adb не запускались, commit не создавался

Raw evidence: /Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/verification/v0.6/s4-microphone-native-r1/supplemental/1794211564810337000/stdout
SHA256 raw: a17bf6879de6f193a7f351f4b6ed0880148d0399452211bc7e01d66826d5be67

Diff: /private/tmp/feoria-v06-window-parser-fix.diff
