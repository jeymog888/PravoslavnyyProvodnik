ACCEPT раннего service draft, без утверждения выполнения тестов

Прочитаны целиком только service/SpeechGuide.kt и SpeechBackend.kt. Статических блокеров в заданном объеме не найдено

SpeechGuide.kt SHA b31df3772d556d353e7c8a75f4c64f77604fe8760a73b369bd9289deab6dd6f7, 11626 bytes
SpeechBackend.kt SHA 6b85185059308b6b7d05265b67806752dc729ee3a189fc0c13fd1beb0d169bc4, 4899 bytes

- Backend:56 использует только createOnDeviceSpeechRecognizer. EXTRA_PREFER_OFFLINE не является единственной защитой; online factory и автоматической загрузки модели нет. Один ru-RU Intent применяется к support и capture
- Guide:63-98 ограничивает support 5 секундами и capture 15 секундами, Guide:152-155 дает final transcript еще максимум 5 секунд. Повторные ready/end/partial не продлевают активный capture или final deadline
- Guide:84-90 различает installed, pending и supported. Лишь installed запускает capture. Неизвестный support дает отдельную явную возможность попробовать без проверки; отрицательный known result не начинает слушать автоматически
- Guide:143-149 принимает только итоговый результат текущей попытки. Partial не превращается в RESULT при timeout/error. RESULT защищен от refreshAvailability и повторного start; явный stop намеренно очищает его
- Guide:190-197 сначала инвалидирует owner/deadline token, затем cancel/destroy. Старые callbacks, повторный deadline и повторный stop не могут оживить попытку. Проверки current после уведомлений также защищают от синхронного ухода UI во время callback
- Backend:93-96 отдельно пытается cancel и destroy, даже если первая операция бросила исключение. SecurityException и runtime failures основных операций переводятся в конечное состояние с выключением попытки

Это не приемка permission/navigation/foreground слоя: parent проверяет его отдельно. В нем по-прежнему важно не вызывать stop при сохранении RESULT для повторного подтверждения после отказа writer и разрешать bypass support только явным действием пользователя. Новых требований к объему нет

JVM tests еще дописываются, здесь не прочитаны и не запускались. Gradle/adb/source edits не выполнялись
