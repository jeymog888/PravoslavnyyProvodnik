ACCEPT статического QA freeze, NOT_RUN

Все 13 файлов /private/tmp/feoria-v06-listening-qa-freeze.json независимо сверены по SHA и bytes. ListeningNavigationTest SHA 3a82b4f2a8f0b1324c201d4e66b93c5f81dd68e1fbf207230cfcfa187b8b5afe

Прочитаны полностью 4 ListeningNavigationTest и 8 ListeningRequestOwnerTest, а также весь listening-ui-adaptation.diff для 11 прежних suites. Конкретных блокеров не найдено

Новые UI scenarios проверяют вход без capture, возврат к непустому поиску с той же геометрией результата, отсутствие записи кандидата до acceptance, сохранение Meaning/date/speed/bookmarks, повторное подтверждение после onSelect=false. Old candidate callback вызывается после повторного идентичного транскрипта и recomposition; identity key и referential state не позволяют принять прошлую попытку. Проверки не подменены сравнением разных текстов

Адаптации отражают реальное перемещение ручного Уточнить в controls и прямой Микрофон. Сохранились 48/120 dp, native font/glyph metrics, no-overlap, стабильность viewport/Return, accepted phrase/date/bookmarks и stale actions. Изменение expectation Meaning соответствует принятому CORRECTION контракту; далее явное переключение к тексту по-прежнему проверяет выбранную фразу. Нового условного skip/ослабления tolerances не добавлено

Дополнительно перечитан узкий runtime delta ListeningCard/ReaderScreenAwake: speech живет по context, фиксированный Stop имеет 48 dp и route guard, RESULT CTA keyed referential identity, refresh предшествует pending consume. Foreground callback вызывается внутри живой Binding.pause после снятия Window flag и до pause writer

Ограничения честные: injected real SpeechGuide + fake backend не доказывает реальную Android permission UI или акустику; onSelect=false не является сбоем SharedPreferences disk write. Отдельные owner unit cases проверяют grant/deny/late token, ON_STOP-style invalidation и stale unbind. Сборка и UI не запускались reviewer, общего runtime freeze здесь еще нет

Final stage4 freeze: ACCEPT. Manifest SHA 192ded4d7857c594cfa8d9a61e6e7ef0008db94bfbc5949019896da033c72d5b совпал, все 23 source/test SHA и bytes сверены. SpeechBackend использует явные SDK_INT >= S для availability, < S rejection до createOnDevice и < TIRAMISU возврат ERROR_CANNOT_CHECK_SUPPORT до API33 call. MissingPermission suppression ограничен create, непосредственная coordinator permission check и обработка SecurityException сохранены. Статических блокеров delta не найдено. Уже запущенная root сборка этим отчетом не объявлена PASS

R2 test-only correction: ACCEPT. Лично прочитан R1 failure XML: 26 UI/2 failures, первый actual содержит полный текст "Распознано: ...", второй actual и StateDescription содержат одновременно сохраненное чтение и примерное место. В ManualMomentFlowTest seed явно anchorIsApproximate=true. Обе новые точные assertTextEquals соответствуют продуктовым данным; проверки не ослаблены. Обратная замена ровно каждой из двух строк восстановила исходный R1 SHA respective файла, остальные 21 файл совпали с R1 freeze. Хвост retry/stale еще должен фактически выполниться в R2; старые FAIL остаются сохраненными
