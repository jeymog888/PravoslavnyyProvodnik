ACCEPT узкой правки parser

Прочитан diff двух файлов и raw permission-raw/windows.txt из s4-microphone-native-r1. Раздел "  Hiding System Alert Windows:" действительно расположен после последнего inventory Window и содержит повторное подробное описание permission dialog. Оно не является вторым owner последнего wallpaper

Исправление отрезает только этот точный заголовок sibling section перед разбором отдельного inventory block. Проверки уникального focused identity, полного owner line, единственного isOnScreen, inventory tokens, ожидаемого пакета и разрешенных overlay сохранены. Нового wildcard allowlist или принятия неоднозначного owner нет

Два новых теста проверяют извлечение настоящих видимых permission/activity окон и сохранение отказа при реальном втором owner внутри Window до указанной границы. Блокеров не найдено. 63/63 PASS сообщил root; reviewer не запускал тесты/adb/Gradle

Исходный native r1 остается partial/FAIL по harness, не приемкой приложения. Новый r2 нужен из-за неизменяемой provenance; результаты старого run не переписаны

Прочитанные SHA:
scripts/harness/feoria_harness.py 87705fc09b60faf235a8e8299759edbcbcc199c56beecc2b875006d3d649180c
scripts/harness/tests/test_harness.py e8f5dfc6120c2756be143d86ff2c1c20577125ccc9c669bc7f7bd946bb8caff4
