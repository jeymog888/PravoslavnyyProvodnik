ACCEPT текущего runtime draft и прочитанных service tests, без заявления выполненного прогона

Прочитаны SpeechGuide/SpeechBackend, весь SpeechGuideTest, ListeningRequestOwner/ListeningInterrupt, ListeningCard и diff MainActivity/ReaderScreenAwake/ServiceScreen. Дополнительно прочитаны небольшие изменения входов ManualMomentScreen и StageSelector

Locale.Builder отвергает malformed ru-?? и ru-RU-?? вместо молчаливого усечения. Поддержка ru/ru-RU и нормализация регистра/подчеркивания сохраняются. В текущем файле 12 @Test, не 11: покрыты API 26-35, разрешение, installed/pending/supported, stale deadlines/callbacks, конечный RESULT, ранний end, dispose, ошибки и синхронный final при stopListening. Это содержательные tests с управляемыми clock/backend, не доказательство акустического качества

Permission launcher расположен внутри key(token), callback захватывает именно token и не подставляет latest pending. ListeningRequestOwner дополнительно сверяет pending token, route identity и live foreground перед запуском. Собственный permission pause может ожидать resume; ON_STOP/DESTROY, Back/navigation и disposal инвалидируют запрос. Old unbind в ListeningInterrupt сравнивает конкретный Binding, поэтому не снимает новую регистрацию того же owner

MainActivity сохраняет исходные context/date/speed/generation и непринятый draft в ListeningRoute. До onSelect accepted reading не заменяется. Failed beginReading не меняет generation и не вызывает navigate/stop, RESULT и найденный этап остаются для повторного подтверждения. Успех навигирует только после commit. CORRECTION сохраняет reader UI/Meaning и bookmarks; NEW_SERVICE сохраняет прежний reset. При recreation transient route не восстановится в live microphone и безопасно возвращается к допустимому исходному экрану

ReaderScreenAwake сохраняет единственный ActivityForegroundState.bind; дополнительный callback отключает попытку через уже существующий путь foreground loss. Прямой подписанный Микрофон заменяет заранее измеренный secondary slot, owner key/guard сохранены, ручное Уточнить остается в controls. Переход в microphone сначала останавливает чтение

Статических блокеров не найдено. Финальные UI tests и freeze еще ожидаются; runtime draft может измениться. Никаких Gradle/adb/source edits

Точные прочитанные версии:

app/src/main/java/ru/liturgyguide/service/SpeechGuide.kt: 94b432d440dc4d5a90aa75a5534dea48f2a7a15322623b46885b194d816882d7 (11704 bytes)
app/src/main/java/ru/liturgyguide/service/SpeechBackend.kt: 6b85185059308b6b7d05265b67806752dc729ee3a189fc0c13fd1beb0d169bc4 (4899 bytes)
app/src/test/java/ru/liturgyguide/service/SpeechGuideTest.kt: 5b884c793570791f33856fbba7886496a9ef47a6c63f6a41fffb332b413cd4eb (16042 bytes)
app/src/main/java/ru/liturgyguide/ui/ListeningRequestOwner.kt: cbc92095a015ba4e0f0a5d8ebf9ffab33c97d2b62b02f90a05763112e586411f (2622 bytes)
app/src/main/java/ru/liturgyguide/ui/ListeningCard.kt: 006011530810daf8fc4c3c64cd3828c39fb566b08acd1abde66f29d40b515acb (10115 bytes)
app/src/main/java/ru/liturgyguide/ui/MainActivity.kt: 582a46c54d338d579da3c6be42627e35acc77d2c987dbc1efc767ed586c21960 (47607 bytes)
app/src/main/java/ru/liturgyguide/ui/ReaderScreenAwake.kt: 66e05ae55d964ceb018d84c6427f497cbab20b8d4abed00c726864bcf25927c4 (4380 bytes)
app/src/main/java/ru/liturgyguide/ui/ServiceScreen.kt: bd1be3511dd93fca176d5bf75b4f2c47ba52884f587aaaecb013389e7852bad5 (63023 bytes)
app/src/main/java/ru/liturgyguide/ui/ManualMomentScreen.kt: 947a99dfd510a3608c35e88e596c58a488996eb0b511fe921557b1a1c6e30c7b (4700 bytes)
app/src/main/java/ru/liturgyguide/ui/StageSelector.kt: 807a355acaa13142cac6f29f6101c4c0fcffa6b498f9f401894eb657e017a48a (8984 bytes)
