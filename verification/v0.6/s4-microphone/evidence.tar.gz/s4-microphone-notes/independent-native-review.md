Итог: ACCEPT пяти лично просмотренных кадров из двух runs; r3 partial/FAIL, r4 gate PASS

Run 36fb1ad5694348eda36c8ae51e1fc005, APK 28ffdc53ebd78557a64a4db4c116460861c7a5ee6349e860b91aa5a764e8e544, manifest f490b5836105d7a31f7af592f35e0b0b13456fb7eba2d85898d997bf90a23f7c

reader-entry - ACCEPT. В выбранном Original видны текущая фраза с маркером, пауза, один primary "Двигать текст" и прямой подписанный "Микрофон". Фиксированные кнопки не обрезаны

listening-idle - ACCEPT. Ясный отдельный экран, один явный запуск "Послушать до 15 секунд", видимый ручной путь и честное ограничение локального распознавания/хора/эха. Нет утверждения непрерывного слежения. Все действия и пояснения читаемы, capture receipt содержит RECORD_AUDIO=false

Для обоих case проверены все artifact SHA/bytes, единые run/APK/manifest и capture PASS. Это собственный debug fixture, не акустическая проверка. permission-dialog/permission-denied/reader-return еще не просмотрены; aggregate не принят. Старые r1 parser FAIL и r2 preparation FAIL остаются сохраненными

## Завершение: три кадра r4

Run d82c05bcf1bc44ec94070fda03365a53, тот же APK, manifest 730b2fdcb22b84e96a9ad6e0a47dfd90fc8b6cd66e9764e6433d453883326ff2. Все три capture PASS, фактические SHA/bytes артефактов сверены. Gate PASS required/passed 3/3 прочитан, это отдельный three-case run

permission-dialog - ACCEPT. Лично виден настоящий Android запрос разрешения с тремя читаемыми вариантами, включая отказ. Под ним приложение показывает ожидание и фиксированный Stop. Английский системный диалог соответствует locale эмулятора, это не поддельный app dialog

permission-denied - ACCEPT. Прямо сообщается об отказе доступа, видны "Разрешения приложения", повторная явная попытка и "Выбрать вручную". Один primary, тупика и обрезания действий не видно

reader-return - ACCEPT. Вернулись к той же выделенной фразе "Миром Господу помолимся", Original, паузе и прежнему viewport. Primary "Двигать текст" не выглядит запущенным; прямой Микрофон остается доступным

Preferences до r3 и после r4 лично сравнены побайтно, равны; SHA 52e1b8acc688a9f65753997e2f648493784b885860b2fe0d706ad045c9536812. Оба manifest SHA также сверены с bytes. Это доказывает отсутствие изменения сохраненных данных между контрольными точками

R3 первые два кадра приняты, но весь run остается partial/FAIL из-за ошибочного expected resource-id permission button. R1 parser FAIL и r2 ошибка подготовки системного окна сохранены. Их не считаем дефектами приложения или успешными runs

Приемка ограничена прямым входом, idle, реальным permission dialog/отказом, доступным ручным выходом и возвратом без изменения чтения. Успешное разрешение с реальным распознаванием, native active Stop после grant и акустическое качество этими пятью PNG не доказаны; bounded cleanup/Stop/token подтверждаются отдельно кодом и tests. Continuous NO-GO, физический телефон/TalkBack/свет NOT TESTED
