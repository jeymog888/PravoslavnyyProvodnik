#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1/first-failure-1794210776551" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s4-microphone-r1/first-failure-1794210776551" "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1/first-failure-1794210776551" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1/first-failure-1794210776551/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1/first-failure-1794210776551.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s4-microphone-r1/first-failure-1794210776551.export.txt"
exit "$result"
