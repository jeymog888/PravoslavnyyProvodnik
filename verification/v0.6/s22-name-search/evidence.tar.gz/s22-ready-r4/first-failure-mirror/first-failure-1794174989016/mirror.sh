#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4/first-failure-1794174989016" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/v06-s22-r4/first-failure-1794174989016" "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4/first-failure-1794174989016" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4/first-failure-1794174989016/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4/first-failure-1794174989016.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/v06-s22-r4/first-failure-1794174989016.export.txt"
exit "$result"
