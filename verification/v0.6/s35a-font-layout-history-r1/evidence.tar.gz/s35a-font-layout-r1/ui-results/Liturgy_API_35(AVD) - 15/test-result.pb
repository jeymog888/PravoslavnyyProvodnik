
�
�
ReaderFontLayoutWitnessTestru.liturgyguide.ui5landscape640By360AtLinear169KeepsAllSixStatesReadable2����ϗ�:��������
�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.landscape640By360AtLinear169KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:50)
java.lang.AssertionError�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.landscape640By360AtLinear169KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:50)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderFontLayoutWitnessTest-landscape640By360AtLinear169KeepsAllSixStatesReadable.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderFontLayoutWitnessTestru.liturgyguide.ui:narrowPortrait320By640AtLinear260KeepsAllSixStatesReadable2�������:���������
�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.narrowPortrait320By640AtLinear260KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:44)
java.lang.AssertionError�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.narrowPortrait320By640AtLinear260KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:44)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderFontLayoutWitnessTest-narrowPortrait320By640AtLinear260KeepsAllSixStatesReadable.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo�
�
ReaderFontLayoutWitnessTestru.liturgyguide.ui4portrait400By800AtLinear260KeepsAllSixStatesReadable2��������:�����ᔧ�
�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.portrait400By800AtLinear260KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:47)
java.lang.AssertionError�java.lang.AssertionError: 6/6 font layout cases failed; all cases were attempted
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile$lambda$1(ReaderFontLayoutWitnessTest.kt:84)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.$r8$lambda$7KWGdGTt2yTxVlC3it3jF3joJfQ(Unknown Source:0)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest$$ExternalSyntheticLambda3.invoke(D8$$SyntheticClass:0)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics(CiFailureDiagnostics.kt:26)
at ru.liturgyguide.ui.CiFailureDiagnosticsKt.withCiFailureDiagnostics$default(CiFailureDiagnostics.kt:21)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.profile(ReaderFontLayoutWitnessTest.kt:55)
at ru.liturgyguide.ui.ReaderFontLayoutWitnessTest.portrait400By800AtLinear260KeepsAllSixStatesReadable(ReaderFontLayoutWitnessTest.kt:47)
"�

logcatandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/logcat-ru.liturgyguide.ui.ReaderFontLayoutWitnessTest-portrait400By800AtLinear260KeepsAllSixStatesReadable.txt"�

device-infoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/device-info.pb"�

device-info.meminfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/meminfo"�

device-info.cpuinfoandroid�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/Users/dmitriymoguschiy/Documents/Spectrion Projects/Новый-чат-21AE5054/PravoslavnyyProvodnik/app/build/outputs/androidTest-results/connected/debug/Liturgy_API_35(AVD) - 15/testlog/test-results.log 2
text/plain