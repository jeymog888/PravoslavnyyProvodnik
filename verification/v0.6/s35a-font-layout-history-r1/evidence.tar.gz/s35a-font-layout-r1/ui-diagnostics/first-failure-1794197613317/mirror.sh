#!/system/bin/sh
(
    test -d "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1" && test ! -e "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317" &&
    cp -R "/storage/emulated/0/Android/data/ru.liturgyguide/files/ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317" "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317" &&
    printf 'COMPLETE\n' > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317/.complete"
    result=$?
    printf 'MIRROR_EXIT=%s\n' "$result"
    exit "$result"
) > "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317.export.txt" 2>&1
result=$?
cat "/data/local/tmp/feoria-ci-diagnostics/s35a-font-layout-r1/first-failure-1794197613317.export.txt"
exit "$result"
